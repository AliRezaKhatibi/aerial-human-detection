export type JobStatus = "queued" | "running" | "paused" | "completed" | "failed" | "cancelled";

export interface HealthResponse {
  status: string;
  service: string;
  version: string;
  mock_mode: boolean;
}

export interface SystemStatus {
  platform: string;
  cpu_percent: number;
  memory_percent: number;
  gpu_name: string | null;
  gpu_usage_percent: number | null;
  vram_used_mb: number | null;
  vram_total_mb: number | null;
  model_loaded: boolean;
  inference_backend: string;
}

export interface InferenceProfile {
  id: "fast" | "balanced" | "accuracy";
  title: string;
  subtitle: string;
  enable_tiling: boolean;
  max_tiles: number;
  refresh_interval: number | null;
  full_imgsz: number;
  tile_imgsz: number;
  recommended: boolean;
}

export interface Job {
  id: string;
  status: JobStatus;
  source_type: string;
  source_path: string;
  profile: string;
  progress: number;
  frame: number;
  total_frames: number;
  fps: number;
  active_tracks: number;
  unique_tracks: number;
  mean_confidence: number;
  tiling_active: boolean;
  created_at: string;
  updated_at: string;
}
