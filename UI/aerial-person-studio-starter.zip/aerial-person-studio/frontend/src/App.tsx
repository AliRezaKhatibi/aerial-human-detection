import { Navigate, Route, Routes } from "react-router-dom";
import { AppShell } from "@/components/layout/AppShell";
import { DashboardPage } from "@/pages/DashboardPage";
import { NewAnalysisPage } from "@/pages/NewAnalysisPage";
import { ProcessingPage } from "@/pages/ProcessingPage";
import { ResultsPage } from "@/pages/ResultsPage";
import { ProfilesPage } from "@/pages/ProfilesPage";
import { SettingsPage } from "@/pages/SettingsPage";
import { SystemPage } from "@/pages/SystemPage";
import { useAppStore } from "@/stores/app-store";

export default function App() {
  const locale = useAppStore((state) => state.locale);
  const theme = useAppStore((state) => state.theme);

  document.documentElement.dir = locale === "fa" ? "rtl" : "ltr";
  document.documentElement.lang = locale;
  document.documentElement.classList.toggle("dark", theme === "dark");

  return (
    <Routes>
      <Route element={<AppShell />}>
        <Route path="/" element={<DashboardPage />} />
        <Route path="/analysis/new" element={<NewAnalysisPage />} />
        <Route path="/processing/:jobId?" element={<ProcessingPage />} />
        <Route path="/results" element={<ResultsPage />} />
        <Route path="/profiles" element={<ProfilesPage />} />
        <Route path="/settings" element={<SettingsPage />} />
        <Route path="/system" element={<SystemPage />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
