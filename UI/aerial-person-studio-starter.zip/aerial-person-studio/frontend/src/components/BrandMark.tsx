export function BrandMark({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-3">
      <div className="relative grid h-10 w-10 place-items-center overflow-hidden rounded-xl border border-[#35d0ba]/30 bg-[#35d0ba]/10 shadow-[0_0_30px_rgba(53,208,186,.15)]">
        <div className="h-4 w-4 rotate-45 rounded-[3px] border-2 border-[#5ee2cf]" />
        <div className="absolute h-1.5 w-1.5 rounded-full bg-[#7c8cff]" />
      </div>
      {!compact && (
        <div>
          <div className="text-sm font-extrabold tracking-tight text-white">Aerial Person Studio</div>
          <div className="text-[10px] font-semibold uppercase tracking-[.22em] text-[#65758d]">Vision Intelligence</div>
        </div>
      )}
    </div>
  );
}
