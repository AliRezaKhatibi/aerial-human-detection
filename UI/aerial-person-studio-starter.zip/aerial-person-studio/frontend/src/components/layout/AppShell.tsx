import { Outlet } from "react-router-dom";
import { Sidebar } from "./Sidebar";
import { Topbar } from "./Topbar";
import { useAppStore } from "@/stores/app-store";
import { cn } from "@/lib/cn";

export function AppShell() {
  const collapsed = useAppStore((state) => state.sidebarCollapsed);
  return (
    <div className="min-h-screen text-white">
      <Sidebar />
      <div className={cn("transition-all", collapsed ? "mr-[84px]" : "mr-[260px]")}> 
        <Topbar />
        <main className="p-6"><Outlet /></main>
      </div>
    </div>
  );
}
