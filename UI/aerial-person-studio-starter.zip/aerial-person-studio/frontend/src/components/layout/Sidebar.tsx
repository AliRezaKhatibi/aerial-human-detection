import { BarChart3, Cpu, FileVideo2, Gauge, LayoutDashboard, Settings, SlidersHorizontal, Sparkles } from "lucide-react";
import { NavLink } from "react-router-dom";
import { BrandMark } from "@/components/BrandMark";
import { cn } from "@/lib/cn";
import { useAppStore } from "@/stores/app-store";

const navItems = [
  { to: "/", label: "داشبورد", icon: LayoutDashboard },
  { to: "/analysis/new", label: "تحلیل جدید", icon: FileVideo2 },
  { to: "/processing", label: "پردازش زنده", icon: Gauge },
  { to: "/results", label: "نتایج و گزارش‌ها", icon: BarChart3 },
  { to: "/profiles", label: "پروفایل‌های مدل", icon: SlidersHorizontal },
  { to: "/settings", label: "تنظیمات", icon: Settings },
  { to: "/system", label: "وضعیت سیستم", icon: Cpu },
];

export function Sidebar() {
  const collapsed = useAppStore((state) => state.sidebarCollapsed);
  return (
    <aside className={cn("fixed inset-y-0 right-0 z-30 border-l border-white/[.06] bg-[#090f19]/92 px-3 py-4 backdrop-blur-xl transition-all", collapsed ? "w-[84px]" : "w-[260px]")}> 
      <div className="px-2"><BrandMark compact={collapsed} /></div>
      <nav className="mt-8 space-y-1.5">
        {navItems.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            end={to === "/"}
            className={({ isActive }) => cn(
              "group flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold transition",
              isActive ? "bg-[#35d0ba]/12 text-[#62dfce] ring-1 ring-[#35d0ba]/15" : "text-[#8392a9] hover:bg-white/[.045] hover:text-white",
            )}
          >
            <Icon size={19} strokeWidth={1.8} />
            {!collapsed && <span>{label}</span>}
          </NavLink>
        ))}
      </nav>
      <div className="absolute bottom-4 left-3 right-3 rounded-2xl border border-[#7c8cff]/15 bg-gradient-to-br from-[#7c8cff]/10 to-[#35d0ba]/5 p-3">
        <div className="flex items-center gap-2 text-xs font-bold text-white"><Sparkles size={15} className="text-[#8e9aff]" /> {!collapsed && "YOLO26m-P2 Ready"}</div>
        {!collapsed && <div className="mt-1 text-[11px] leading-5 text-[#7888a1]">حالت توسعه بدون مدل فعال است.</div>}
      </div>
    </aside>
  );
}
