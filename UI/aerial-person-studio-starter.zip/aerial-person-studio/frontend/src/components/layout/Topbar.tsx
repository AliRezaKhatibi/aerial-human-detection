import { Bell, ChevronLeft, Languages, Menu, Moon, Search } from "lucide-react";
import { useLocation } from "react-router-dom";
import { Button } from "@/components/ui/Button";
import { useAppStore } from "@/stores/app-store";

const titles: Record<string, string> = {
  "/": "داشبورد عملیات",
  "/analysis/new": "تحلیل جدید",
  "/processing": "پردازش زنده",
  "/results": "نتایج و گزارش‌ها",
  "/profiles": "پروفایل‌های استنتاج",
  "/settings": "تنظیمات برنامه",
  "/system": "وضعیت سیستم",
};

export function Topbar() {
  const location = useLocation();
  const toggleSidebar = useAppStore((s) => s.toggleSidebar);
  const toggleTheme = useAppStore((s) => s.toggleTheme);
  const locale = useAppStore((s) => s.locale);
  const setLocale = useAppStore((s) => s.setLocale);
  const current = Object.entries(titles).find(([path]) => path === "/" ? location.pathname === path : location.pathname.startsWith(path))?.[1] ?? "Aerial Person Studio";
  return (
    <header className="sticky top-0 z-20 flex h-[74px] items-center justify-between border-b border-white/[.06] bg-[#080d16]/75 px-6 backdrop-blur-xl">
      <div className="flex items-center gap-3">
        <Button variant="ghost" className="h-10 w-10 p-0" onClick={toggleSidebar}><Menu size={19} /></Button>
        <div>
          <h1 className="text-base font-extrabold text-white">{current}</h1>
          <div className="mt-0.5 flex items-center gap-1 text-[11px] text-[#66758c]">استودیو <ChevronLeft size={12} /> عملیات بینایی ماشین</div>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <div className="hidden items-center gap-2 rounded-xl border border-white/[.07] bg-white/[.035] px-3 py-2 xl:flex">
          <Search size={16} className="text-[#67778f]" />
          <input className="w-44 bg-transparent text-xs text-white outline-none placeholder:text-[#56657a]" placeholder="جست‌وجوی پروژه یا گزارش..." />
        </div>
        <Button variant="ghost" className="h-10 w-10 p-0" onClick={() => setLocale(locale === "fa" ? "en" : "fa")}><Languages size={18} /></Button>
        <Button variant="ghost" className="h-10 w-10 p-0" onClick={toggleTheme}><Moon size={18} /></Button>
        <Button variant="ghost" className="relative h-10 w-10 p-0"><Bell size={18} /><span className="absolute left-2 top-2 h-1.5 w-1.5 rounded-full bg-[#ff6c80]" /></Button>
        <div className="mr-2 h-9 w-9 rounded-xl bg-gradient-to-br from-[#35d0ba] to-[#687dff] p-[1px]"><div className="grid h-full w-full place-items-center rounded-[11px] bg-[#111a29] text-xs font-black">AP</div></div>
      </div>
    </header>
  );
}
