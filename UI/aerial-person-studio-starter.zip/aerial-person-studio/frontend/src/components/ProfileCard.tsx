import { Check, Gauge, ScanSearch, Zap } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { cn } from "@/lib/cn";

const details = {
  fast: { icon: Zap, tone: "text-[#57dec9]", title: "Fast", subtitle: "بیشترین سرعت", body: "پردازش Full-frame بدون برش تطبیقی", tags: ["No tiling", "Max FPS"] },
  balanced: { icon: Gauge, tone: "text-[#9aa7ff]", title: "Balanced", subtitle: "پیشنهادشده", body: "Full-frame همراه برش تطبیقی و کم‌هزینه", tags: ["Adaptive", "Recommended"] },
  accuracy: { icon: ScanSearch, tone: "text-[#f7ca75]", title: "Accuracy", subtitle: "بیشترین Recall", body: "برش‌های گسترده برای اهداف بسیار کوچک", tags: ["Extensive tiling", "Max recall"] },
};

export function ProfileCard({ kind, selected, onClick }: { kind: keyof typeof details; selected?: boolean; onClick?: () => void }) {
  const item = details[kind]; const Icon = item.icon;
  return (
    <Card onClick={onClick} className={cn("panel-hover relative cursor-pointer p-5", selected && "border-[#35d0ba]/35 ring-1 ring-[#35d0ba]/20")}> 
      {selected && <div className="absolute left-4 top-4 grid h-6 w-6 place-items-center rounded-full bg-[#35d0ba] text-[#07100f]"><Check size={14} strokeWidth={3} /></div>}
      <Icon className={item.tone} size={24} />
      <div className="mt-5 text-base font-black">{item.title}</div>
      <div className="mt-1 text-xs font-bold text-[#8e9db3]">{item.subtitle}</div>
      <p className="mt-3 min-h-10 text-xs leading-6 text-[#67768d]">{item.body}</p>
      <div className="mt-4 flex flex-wrap gap-2">{item.tags.map((tag) => <Badge key={tag} tone="gray">{tag}</Badge>)}</div>
    </Card>
  );
}
