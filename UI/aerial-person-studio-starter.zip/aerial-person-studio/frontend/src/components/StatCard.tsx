import type { ReactNode } from "react";
import { Card } from "@/components/ui/Card";

export function StatCard({ title, value, caption, icon, trend }: { title: string; value: string; caption: string; icon: ReactNode; trend?: string }) {
  return (
    <Card className="panel-hover p-5">
      <div className="flex items-start justify-between">
        <div className="grid h-10 w-10 place-items-center rounded-xl border border-[#35d0ba]/15 bg-[#35d0ba]/8 text-[#52dac6]">{icon}</div>
        {trend && <span className="rounded-full bg-[#35d0ba]/10 px-2 py-1 text-[10px] font-bold text-[#5bdfcd]">{trend}</span>}
      </div>
      <div className="mt-5 text-xs font-semibold text-[#8291a7]">{title}</div>
      <div className="mt-1 text-2xl font-black tracking-tight text-white">{value}</div>
      <div className="mt-2 text-[11px] text-[#607087]">{caption}</div>
    </Card>
  );
}
