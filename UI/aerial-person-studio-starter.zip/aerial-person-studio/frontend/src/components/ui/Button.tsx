import type { ButtonHTMLAttributes, ReactNode } from "react";
import { cn } from "@/lib/cn";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  children: ReactNode;
  variant?: "primary" | "secondary" | "ghost" | "danger";
}

export function Button({ children, variant = "primary", className, ...props }: ButtonProps) {
  const variants = {
    primary: "bg-[#35d0ba] text-[#05100f] hover:bg-[#5be0cc] shadow-[0_10px_30px_rgba(53,208,186,.18)]",
    secondary: "bg-white/[.06] text-white border border-white/[.08] hover:bg-white/[.10]",
    ghost: "bg-transparent text-[#9eacc0] hover:bg-white/[.06] hover:text-white",
    danger: "bg-[#ff6c80]/15 text-[#ff8293] border border-[#ff6c80]/25 hover:bg-[#ff6c80]/20",
  };
  return (
    <button
      className={cn("inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold transition disabled:cursor-not-allowed disabled:opacity-50", variants[variant], className)}
      {...props}
    >
      {children}
    </button>
  );
}
