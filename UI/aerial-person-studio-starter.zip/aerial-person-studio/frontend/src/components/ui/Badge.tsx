import type { ReactNode } from "react";
import { cn } from "@/lib/cn";

export function Badge({ children, tone = "green" }: { children: ReactNode; tone?: "green" | "blue" | "amber" | "red" | "gray" }) {
  const tones = {
    green: "bg-[#35d0ba]/10 text-[#57dec9] border-[#35d0ba]/20",
    blue: "bg-[#7c8cff]/10 text-[#9aa7ff] border-[#7c8cff]/20",
    amber: "bg-[#f7bf59]/10 text-[#f7ca75] border-[#f7bf59]/20",
    red: "bg-[#ff6c80]/10 text-[#ff8696] border-[#ff6c80]/20",
    gray: "bg-white/[.05] text-[#a8b4c7] border-white/[.08]",
  };
  return <span className={cn("inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-bold", tones[tone])}>{children}</span>;
}
