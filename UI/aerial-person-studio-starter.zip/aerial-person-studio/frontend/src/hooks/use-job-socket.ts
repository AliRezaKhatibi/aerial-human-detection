import { useEffect, useState } from "react";
import { WS_BASE_URL } from "@/lib/config";
import type { Job } from "@/types/api";

export function useJobSocket(jobId?: string) {
  const [job, setJob] = useState<Job | null>(null);
  const [connected, setConnected] = useState(false);
  useEffect(() => {
    if (!jobId) return;
    const socket = new WebSocket(`${WS_BASE_URL}/ws/jobs/${jobId}`);
    socket.onopen = () => setConnected(true);
    socket.onmessage = (event) => setJob(JSON.parse(event.data) as Job);
    socket.onclose = () => setConnected(false);
    socket.onerror = () => setConnected(false);
    return () => socket.close();
  }, [jobId]);
  return { job, connected };
}
