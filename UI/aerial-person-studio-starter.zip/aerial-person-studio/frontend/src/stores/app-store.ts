import { create } from "zustand";

type Locale = "fa" | "en";
type Theme = "dark" | "light";

interface AppState {
  locale: Locale;
  theme: Theme;
  sidebarCollapsed: boolean;
  setLocale: (locale: Locale) => void;
  toggleTheme: () => void;
  toggleSidebar: () => void;
}

export const useAppStore = create<AppState>((set) => ({
  locale: "fa",
  theme: "dark",
  sidebarCollapsed: false,
  setLocale: (locale) => set({ locale }),
  toggleTheme: () => set((state) => ({ theme: state.theme === "dark" ? "light" : "dark" })),
  toggleSidebar: () => set((state) => ({ sidebarCollapsed: !state.sidebarCollapsed })),
}));
