import { useQuery } from "@tanstack/react-query";
import { Cpu, HardDrive, MemoryStick, MonitorCog, type LucideIcon } from "lucide-react";
import { Card, CardHeader } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { api } from "@/lib/api";

interface SystemItem {
  label: string;
  value: string;
  icon: LucideIcon;
}

export function SystemPage() {
  const { data } = useQuery({
    queryKey: ["system-page"],
    queryFn: api.system,
    refetchInterval: 3000,
  });

  const items: SystemItem[] = [
    { label: "GPU", value: data?.gpu_name ?? "Unavailable", icon: Cpu },
    {
      label: "VRAM",
      value: data?.vram_total_mb ? `${data.vram_used_mb}/${data.vram_total_mb} MB` : "Unavailable",
      icon: MemoryStick,
    },
    { label: "Platform", value: data?.platform ?? "—", icon: MonitorCog },
    { label: "Backend", value: data?.inference_backend ?? "mock", icon: HardDrive },
  ];

  return (
    <div className="grid grid-cols-2 gap-4">
      {items.map(({ label, value, icon: Icon }) => (
        <Card key={label} className="p-5">
          <div className="flex items-center justify-between">
            <Icon className="text-[#35d0ba]" />
            <Badge tone="green">ONLINE</Badge>
          </div>
          <div className="mt-6 text-xs text-[#718198]">{label}</div>
          <div className="mt-2 text-lg font-black">{value}</div>
        </Card>
      ))}
      <Card className="col-span-2">
        <CardHeader title="بررسی وابستگی‌ها" />
        <div className="grid grid-cols-4 gap-3 p-5">
          {[
            ["FastAPI", "Ready"],
            ["TensorRT", "Pending"],
            ["FFmpeg", "Pending"],
            ["ByteTrack", "Scaffolded"],
          ].map(([name, status]) => (
            <div key={name} className="rounded-xl bg-white/[.03] p-4">
              <div className="text-xs font-bold">{name}</div>
              <div className="mt-2 text-[10px] text-[#6e7e95]">{status}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
