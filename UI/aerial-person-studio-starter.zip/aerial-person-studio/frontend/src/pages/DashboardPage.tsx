import { Activity, ArrowUpLeft, Clock3, Cpu, FileVideo2, Gauge, Play, Users } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import ReactECharts from "echarts-for-react";
import { motion } from "framer-motion";
import { api } from "@/lib/api";
import { Button } from "@/components/ui/Button";
import { Card, CardHeader } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { StatCard } from "@/components/StatCard";
import { ProfileCard } from "@/components/ProfileCard";

const chartOption = {
  backgroundColor: "transparent",
  grid: { left: 10, right: 10, top: 18, bottom: 12, containLabel: true },
  tooltip: { trigger: "axis", backgroundColor: "#101a29", borderColor: "rgba(255,255,255,.08)", textStyle: { color: "#fff" } },
  xAxis: { type: "category", boundaryGap: false, data: ["00", "04", "08", "12", "16", "20", "24"], axisLine: { lineStyle: { color: "rgba(255,255,255,.08)" } }, axisLabel: { color: "#607087", fontSize: 10 } },
  yAxis: { type: "value", min: 0, max: 30, splitLine: { lineStyle: { color: "rgba(255,255,255,.045)" } }, axisLabel: { color: "#607087", fontSize: 10 } },
  series: [{ name: "FPS", type: "line", smooth: true, symbol: "none", data: [14, 16, 15, 18, 17, 19, 18], lineStyle: { width: 3, color: "#35d0ba" }, areaStyle: { color: { type: "linear", x: 0, y: 0, x2: 0, y2: 1, colorStops: [{ offset: 0, color: "rgba(53,208,186,.28)" }, { offset: 1, color: "rgba(53,208,186,0)" }] } } }],
};

export function DashboardPage() {
  const { data: system } = useQuery({ queryKey: ["system"], queryFn: api.system, refetchInterval: 5000 });
  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      <section className="glass metric-grid relative overflow-hidden rounded-3xl p-6">
        <div className="absolute -left-20 -top-24 h-64 w-64 rounded-full bg-[#7c8cff]/10 blur-3xl" />
        <div className="relative flex items-center justify-between">
          <div>
            <div className="mb-3 flex items-center gap-2"><Badge tone="green">SYSTEM ONLINE</Badge><Badge tone={system?.model_loaded ? "green" : "amber"}>{system?.model_loaded ? "MODEL READY" : "MOCK MODE"}</Badge></div>
            <h2 className="max-w-2xl text-2xl font-black leading-[1.55]">تشخیص و ردیابی هوشمند افراد در تصاویر و ویدئوهای هوایی</h2>
            <p className="mt-2 max-w-2xl text-sm leading-7 text-[#8090a8]">یک فضای کاری یکپارچه برای تحلیل ویدئو، تنظیم سرعت و دقت، پایش GPU و تولید گزارش‌های حرفه‌ای.</p>
          </div>
          <Link to="/analysis/new"><Button className="px-5 py-3"><Play size={17} fill="currentColor" /> شروع تحلیل جدید</Button></Link>
        </div>
      </section>

      <section className="grid grid-cols-4 gap-4">
        <StatCard title="وضعیت GPU" value={system?.gpu_name ?? "Mock GPU"} caption={`${system?.gpu_usage_percent ?? 0}% استفاده فعلی`} icon={<Cpu size={19} />} trend="ONLINE" />
        <StatCard title="میانگین سرعت" value="18.4 FPS" caption="حالت Balanced" icon={<Gauge size={19} />} trend="+8.1%" />
        <StatCard title="افراد یکتا" value="1,284" caption="در ۳۰ روز اخیر" icon={<Users size={19} />} trend="+12.7%" />
        <StatCard title="زمان پردازش" value="42.6 h" caption="۲۴ پروژه تکمیل‌شده" icon={<Clock3 size={19} />} />
      </section>

      <section className="grid grid-cols-[1.55fr_1fr] gap-4">
        <Card>
          <CardHeader title={<span className="flex items-center gap-2"><Activity size={17} className="text-[#35d0ba]" /> عملکرد پردازش</span>} action={<Badge tone="gray">۲۴ ساعت اخیر</Badge>} />
          <div className="p-3"><ReactECharts option={chartOption} style={{ height: 265 }} /></div>
        </Card>
        <Card>
          <CardHeader title="وضعیت موتور" action={<Badge tone="green">Healthy</Badge>} />
          <div className="space-y-4 p-5">
            {[
              ["Inference backend", system?.inference_backend ?? "Mock"],
              ["Model", system?.model_loaded ? "YOLO26m-P2" : "Not loaded"],
              ["Tracking", "ByteTrack"],
              ["Video engine", "OpenCV / FFmpeg"],
              ["VRAM", system?.vram_total_mb ? `${system.vram_used_mb} / ${system.vram_total_mb} MB` : "Unavailable"],
            ].map(([label, value]) => <div key={label} className="flex items-center justify-between border-b border-white/[.055] pb-3 text-xs"><span className="text-[#718198]">{label}</span><span className="font-bold text-[#dce7f7]">{value}</span></div>)}
          </div>
        </Card>
      </section>

      <section>
        <div className="mb-4 flex items-end justify-between"><div><h3 className="text-base font-black">پروفایل‌های استنتاج</h3><p className="mt-1 text-xs text-[#6e7e95]">همان مدل، با سه روش اجرا برای نیازهای متفاوت</p></div><Link to="/profiles" className="flex items-center gap-1 text-xs font-bold text-[#56dac7]">مدیریت پروفایل‌ها <ArrowUpLeft size={14} /></Link></div>
        <div className="grid grid-cols-3 gap-4"><ProfileCard kind="fast" /><ProfileCard kind="balanced" selected /><ProfileCard kind="accuracy" /></div>
      </section>

      <section className="grid grid-cols-[1.4fr_1fr] gap-4">
        <Card><CardHeader title="پروژه‌های اخیر" action={<Button variant="ghost" className="px-2 py-1 text-xs">مشاهده همه</Button>} />
          <div className="divide-y divide-white/[.055] px-5">
            {[['visdrone-campus-01.mp4','Completed','Balanced','18.2 FPS'],['parking-east.mp4','Completed','Accuracy','7.4 FPS'],['uav-demo-night.mp4','Processing','Fast','24.1 FPS']].map(([name,status,profile,fps]) => <div className="flex items-center justify-between py-4" key={name}><div className="flex items-center gap-3"><div className="grid h-9 w-9 place-items-center rounded-xl bg-white/[.05] text-[#7f90a9]"><FileVideo2 size={17}/></div><div><div className="text-xs font-bold">{name}</div><div className="mt-1 text-[10px] text-[#64748a]">{profile} · {fps}</div></div></div><Badge tone={status==='Completed'?'green':'blue'}>{status}</Badge></div>)}
          </div>
        </Card>
        <Card><CardHeader title="مصرف منابع" /><div className="space-y-5 p-5">{[["GPU",system?.gpu_usage_percent ?? 0],["RAM",system?.memory_percent ?? 0],["CPU",system?.cpu_percent ?? 0]].map(([name,value])=><div key={String(name)}><div className="mb-2 flex justify-between text-xs"><span className="text-[#7c8ba1]">{name}</span><span className="font-bold">{value}%</span></div><div className="h-2 overflow-hidden rounded-full bg-white/[.05]"><div className="h-full rounded-full bg-gradient-to-l from-[#35d0ba] to-[#7c8cff]" style={{width:`${value}%`}} /></div></div>)}</div></Card>
      </section>
    </motion.div>
  );
}
