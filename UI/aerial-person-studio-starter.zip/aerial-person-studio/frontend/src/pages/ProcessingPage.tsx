import { Maximize2, Pause, Radio, Square, Users } from "lucide-react";
import { useParams } from "react-router-dom";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { useJobSocket } from "@/hooks/use-job-socket";

export function ProcessingPage() {
  const { jobId } = useParams();
  const { job, connected } = useJobSocket(jobId);
  const progress = job?.progress ?? 0;
  return <div className="space-y-4">
    <div className="flex items-center justify-between"><div><h2 className="text-lg font-black">پردازش زنده</h2><p className="mt-1 text-xs text-[#718198]">Job ID: {jobId ?? 'هنوز کاری انتخاب نشده است'}</p></div><div className="flex gap-2"><Badge tone={connected?'green':'amber'}>{connected?'LIVE CONNECTED':'WAITING'}</Badge><Badge tone="blue">{job?.profile ?? 'balanced'}</Badge></div></div>
    <div className="grid grid-cols-[1fr_300px] gap-4">
      <Card className="overflow-hidden"><div className="relative aspect-video min-h-[480px] bg-[#03060a] metric-grid"><div className="absolute inset-0 grid place-items-center"><div className="text-center"><Radio className="mx-auto text-[#35d0ba]" size={36}/><div className="mt-4 text-sm font-bold">پیش‌نمایش ویدئو در مرحله اتصال موتور اضافه می‌شود</div><div className="mt-2 text-xs text-[#64748a]">در Mock Mode فقط تله‌متری زنده نمایش داده می‌شود.</div></div></div><div className="absolute left-4 top-4 flex gap-2"><Badge tone="red">REC</Badge><Badge tone="gray">1280p</Badge></div><Button variant="ghost" className="absolute bottom-4 left-4 h-10 w-10 p-0"><Maximize2 size={18}/></Button></div><div className="flex items-center justify-between border-t border-white/[.06] px-5 py-4"><div className="flex gap-2"><Button variant="secondary"><Pause size={16}/> مکث</Button><Button variant="danger"><Square size={15}/> توقف</Button></div><div className="text-xs text-[#77869d]">Frame {job?.frame ?? 0} / {job?.total_frames ?? 0}</div></div></Card>
      <div className="space-y-4">{[['FPS',(job?.fps ?? 0).toFixed(1)],['افراد فعال',String(job?.active_tracks ?? 0)],['افراد یکتا',String(job?.unique_tracks ?? 0)],['Confidence',`${Math.round((job?.mean_confidence ?? 0)*100)}%`],['Tiling',job?.tiling_active?'فعال':'غیرفعال']].map(([label,value])=><Card key={label} className="p-4"><div className="text-[10px] font-semibold text-[#68778e]">{label}</div><div className="mt-1 flex items-center justify-between"><div className="text-xl font-black">{value}</div>{label==='افراد فعال'&&<Users size={18} className="text-[#35d0ba]"/>}</div></Card>)}</div>
    </div>
    <Card className="p-5"><div className="mb-2 flex justify-between text-xs"><span className="font-bold">پیشرفت پردازش</span><span>{progress.toFixed(1)}%</span></div><div className="h-2 overflow-hidden rounded-full bg-white/[.06]"><div className="h-full rounded-full bg-gradient-to-l from-[#35d0ba] to-[#7c8cff] transition-all" style={{width:`${progress}%`}}/></div></Card>
  </div>;
}
