import { Camera, FileVideo2, FolderOpen, Radio, UploadCloud } from "lucide-react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ProfileCard } from "@/components/ProfileCard";
import { Button } from "@/components/ui/Button";
import { Card, CardHeader } from "@/components/ui/Card";
import { api } from "@/lib/api";

const sourceTypes = [
  { icon: FileVideo2, title: "فایل ویدئویی", state: "فعال" },
  { icon: Camera, title: "دوربین محلی", state: "به‌زودی" },
  { icon: Radio, title: "جریان RTSP", state: "به‌زودی" },
];

export function NewAnalysisPage() {
  const [profile, setProfile] = useState<"fast"|"balanced"|"accuracy">("balanced");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const startMock = async () => { setLoading(true); try { const job = await api.createMockJob(profile); navigate(`/processing/${job.id}`); } finally { setLoading(false); } };
  return <div className="space-y-6">
    <Card className="p-6"><div className="grid grid-cols-[1fr_320px] gap-6">
      <div className="grid min-h-[280px] place-items-center rounded-2xl border border-dashed border-[#35d0ba]/25 bg-[#35d0ba]/[.035] text-center"><div><div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-[#35d0ba]/10 text-[#57dec9]"><UploadCloud size={28}/></div><h3 className="mt-5 font-black">ویدئو را اینجا رها کنید</h3><p className="mt-2 text-xs text-[#728198]">MP4, MOV, MKV, AVI · حداکثر اندازه در نسخه محلی نامحدود</p><Button variant="secondary" className="mt-5"><FolderOpen size={16}/> انتخاب فایل</Button></div></div>
      <div><h3 className="text-sm font-black">نوع منبع</h3><div className="mt-4 space-y-3">{sourceTypes.map(({ icon: Icon, title, state })=><button key={title} className="flex w-full items-center justify-between rounded-xl border border-white/[.07] bg-white/[.03] p-4 text-right hover:bg-white/[.05]"><div className="flex items-center gap-3"><Icon size={18} className="text-[#5adcc9]"/><div><div className="text-xs font-bold">{title}</div><div className="mt-1 text-[10px] text-[#65758c]">{state}</div></div></div></button>)}</div></div>
    </div></Card>
    <div><h3 className="mb-4 text-base font-black">پروفایل پردازش</h3><div className="grid grid-cols-3 gap-4"><ProfileCard kind="fast" selected={profile==='fast'} onClick={()=>setProfile('fast')}/><ProfileCard kind="balanced" selected={profile==='balanced'} onClick={()=>setProfile('balanced')}/><ProfileCard kind="accuracy" selected={profile==='accuracy'} onClick={()=>setProfile('accuracy')}/></div></div>
    <Card><CardHeader title="تنظیمات سریع"/><div className="grid grid-cols-4 gap-4 p-5">{[['Confidence','0.20'],['نمایش مسیر','فعال'],['ذخیره ویدئو','فعال'],['Codec','H.264']].map(([a,b])=><div key={a} className="rounded-xl bg-white/[.035] p-4"><div className="text-[10px] text-[#697991]">{a}</div><div className="mt-2 text-xs font-bold">{b}</div></div>)}</div></Card>
    <div className="flex justify-end"><Button onClick={startMock} disabled={loading} className="px-8 py-3">{loading?'در حال ایجاد...':'شروع پردازش آزمایشی'}</Button></div>
  </div>;
}
