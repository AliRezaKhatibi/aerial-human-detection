import type { Config } from "tailwindcss";

export default {
  darkMode: ["class"],
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: ["Vazirmatn", "Inter", "Segoe UI", "sans-serif"],
      },
      boxShadow: {
        panel: "0 18px 60px rgba(0,0,0,.22)",
        glow: "0 0 45px rgba(51, 206, 177, .13)",
      },
    },
  },
  plugins: [],
} satisfies Config;
