fn main() {
    aerial_person_studio_lib::run()
}
