$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
pnpm --dir frontend build
Write-Host "Frontend production bundle created." -ForegroundColor Green
Write-Host "Desktop packaging and Python sidecar are enabled in a later milestone." -ForegroundColor Yellow
