$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
Write-Host "Ensure the backend is already running in another terminal." -ForegroundColor Yellow
pnpm --dir frontend tauri dev --config ../src-tauri/tauri.conf.json
