$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root

Write-Host "[1/4] Checking pnpm..." -ForegroundColor Cyan
if (-not (Get-Command pnpm -ErrorAction SilentlyContinue)) {
  npm install -g pnpm
}

Write-Host "[2/4] Installing frontend packages..." -ForegroundColor Cyan
pnpm install

Write-Host "[3/4] Creating Python environment..." -ForegroundColor Cyan
if (-not (Test-Path "backend/.venv")) {
  python -m venv backend/.venv
}
& "backend/.venv/Scripts/python.exe" -m pip install --upgrade pip
& "backend/.venv/Scripts/pip.exe" install -e "backend[dev]"

Write-Host "[4/4] Preparing runtime directories..." -ForegroundColor Cyan
New-Item -ItemType Directory -Force -Path "runtime/outputs", "runtime/logs", "models" | Out-Null
if (-not (Test-Path "backend/.env")) { Copy-Item "backend/.env.example" "backend/.env" }
if (-not (Test-Path "frontend/.env")) { Copy-Item "frontend/.env.example" "frontend/.env" }

Write-Host "Setup complete." -ForegroundColor Green
Write-Host "Start backend: ./scripts/backend-dev.ps1"
Write-Host "Start frontend: ./scripts/frontend-dev.ps1"
