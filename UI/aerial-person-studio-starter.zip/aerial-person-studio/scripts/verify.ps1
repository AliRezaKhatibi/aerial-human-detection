$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
pnpm --dir frontend build
& "backend/.venv/Scripts/python.exe" -m pytest backend/tests
Write-Host "Frontend build and backend tests passed." -ForegroundColor Green
