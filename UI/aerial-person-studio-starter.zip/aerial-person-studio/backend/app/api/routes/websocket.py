from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from app.services.job_manager import job_manager

router = APIRouter()

@router.websocket("/jobs/{job_id}")
async def job_updates(websocket: WebSocket, job_id: str) -> None:
    await websocket.accept()
    queue = job_manager.subscribe(job_id)
    try:
        job = job_manager.get_job(job_id)
        if job:
            await websocket.send_json(job.model_dump(mode="json"))
        while True:
            update = await queue.get()
            await websocket.send_json(update.model_dump(mode="json"))
    except WebSocketDisconnect:
        pass
    finally:
        job_manager.unsubscribe(job_id, queue)
