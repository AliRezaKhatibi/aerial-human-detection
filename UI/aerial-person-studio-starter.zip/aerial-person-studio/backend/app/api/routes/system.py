from fastapi import APIRouter
from app.schemas.system import SystemStatus
from app.services.system_monitor import get_system_status

router = APIRouter()

@router.get("/system", response_model=SystemStatus)
async def system_status() -> SystemStatus:
    return get_system_status()
