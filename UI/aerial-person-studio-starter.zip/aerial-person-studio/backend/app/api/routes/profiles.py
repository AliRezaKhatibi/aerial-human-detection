from fastapi import APIRouter
from app.schemas.profile import InferenceProfile
from app.services.profile_manager import PROFILES

router = APIRouter()

@router.get("/profiles", response_model=list[InferenceProfile])
async def list_profiles() -> list[InferenceProfile]:
    return list(PROFILES.values())
