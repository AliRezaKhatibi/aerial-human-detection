from fastapi import APIRouter, HTTPException
from app.schemas.job import CreateJobRequest, JobState
from app.services.job_manager import job_manager

router = APIRouter()

@router.get("", response_model=list[JobState])
async def list_jobs() -> list[JobState]:
    return job_manager.list_jobs()

@router.post("", response_model=JobState, status_code=201)
async def create_job(payload: CreateJobRequest) -> JobState:
    return await job_manager.create_job(payload)

@router.get("/{job_id}", response_model=JobState)
async def get_job(job_id: str) -> JobState:
    job = job_manager.get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job

@router.post("/{job_id}/cancel", response_model=JobState)
async def cancel_job(job_id: str) -> JobState:
    job = await job_manager.cancel_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job
