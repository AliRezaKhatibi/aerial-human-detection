import asyncio
import math
import random
from collections import defaultdict
from datetime import datetime, timezone
from app.schemas.job import CreateJobRequest, JobState

class JobManager:
    def __init__(self) -> None:
        self._jobs: dict[str, JobState] = {}
        self._tasks: dict[str, asyncio.Task[None]] = {}
        self._subscribers: dict[str, set[asyncio.Queue[JobState]]] = defaultdict(set)

    async def start(self) -> None:
        return None

    async def shutdown(self) -> None:
        for task in self._tasks.values():
            task.cancel()
        await asyncio.gather(*self._tasks.values(), return_exceptions=True)

    def list_jobs(self) -> list[JobState]:
        return sorted(self._jobs.values(), key=lambda x: x.created_at, reverse=True)

    def get_job(self, job_id: str) -> JobState | None:
        return self._jobs.get(job_id)

    async def create_job(self, payload: CreateJobRequest) -> JobState:
        job = JobState(source_type=payload.source_type, source_path=payload.source_path, profile=payload.profile)
        self._jobs[job.id] = job
        self._tasks[job.id] = asyncio.create_task(self._run_mock_job(job.id))
        return job

    async def cancel_job(self, job_id: str) -> JobState | None:
        job = self._jobs.get(job_id)
        if not job:
            return None
        job.status = "cancelled"
        job.updated_at = datetime.now(timezone.utc)
        task = self._tasks.get(job_id)
        if task:
            task.cancel()
        await self._publish(job)
        return job

    def subscribe(self, job_id: str) -> asyncio.Queue[JobState]:
        queue: asyncio.Queue[JobState] = asyncio.Queue(maxsize=4)
        self._subscribers[job_id].add(queue)
        return queue

    def unsubscribe(self, job_id: str, queue: asyncio.Queue[JobState]) -> None:
        self._subscribers[job_id].discard(queue)

    async def _publish(self, job: JobState) -> None:
        for queue in tuple(self._subscribers.get(job.id, set())):
            if queue.full():
                try:
                    queue.get_nowait()
                except asyncio.QueueEmpty:
                    pass
            await queue.put(job.model_copy(deep=True))

    async def _run_mock_job(self, job_id: str) -> None:
        job = self._jobs[job_id]
        job.status = "running"
        total = job.total_frames
        try:
            for frame in range(total + 1):
                if job.status == "cancelled":
                    break
                job.frame = frame
                job.progress = round(frame / total * 100, 2)
                base_fps = {"fast": 25.0, "balanced": 16.5, "accuracy": 7.0}.get(job.profile, 15.0)
                job.fps = round(base_fps + math.sin(frame / 22) * 1.6 + random.uniform(-0.5, 0.5), 1)
                job.active_tracks = max(0, int(9 + math.sin(frame / 30) * 5 + random.uniform(-2, 2)))
                job.unique_tracks = max(job.unique_tracks, int(frame / 25) + job.active_tracks)
                job.mean_confidence = round(0.68 + math.sin(frame / 40) * 0.07, 3)
                job.tiling_active = job.profile != "fast" and (job.profile == "accuracy" or frame % 6 == 0)
                job.updated_at = datetime.now(timezone.utc)
                await self._publish(job)
                await asyncio.sleep(0.08)
            if job.status != "cancelled":
                job.status = "completed"
                job.progress = 100.0
                await self._publish(job)
        except asyncio.CancelledError:
            return

job_manager = JobManager()
