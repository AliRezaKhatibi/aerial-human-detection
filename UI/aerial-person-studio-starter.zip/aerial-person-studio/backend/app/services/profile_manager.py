from app.schemas.profile import InferenceProfile

PROFILES = {
    "fast": InferenceProfile(id="fast", title="Fast", subtitle="Maximum performance", enable_tiling=False, max_tiles=0, refresh_interval=None),
    "balanced": InferenceProfile(id="balanced", title="Balanced", subtitle="Adaptive tiling", enable_tiling=True, max_tiles=2, refresh_interval=6, recommended=True),
    "accuracy": InferenceProfile(id="accuracy", title="Accuracy", subtitle="Maximum recall", enable_tiling=True, max_tiles=6, refresh_interval=1),
}
