import platform
from pathlib import Path
import psutil
from app.core.config import settings
from app.schemas.system import SystemStatus


def _gpu_info() -> tuple[str | None, float | None, float | None, float | None]:
    try:
        import pynvml
        pynvml.nvmlInit()
        handle = pynvml.nvmlDeviceGetHandleByIndex(0)
        name = pynvml.nvmlDeviceGetName(handle)
        if isinstance(name, bytes):
            name = name.decode("utf-8")
        util = pynvml.nvmlDeviceGetUtilizationRates(handle)
        memory = pynvml.nvmlDeviceGetMemoryInfo(handle)
        return str(name), float(util.gpu), memory.used / 1024**2, memory.total / 1024**2
    except Exception:
        return None, None, None, None


def get_system_status() -> SystemStatus:
    gpu_name, gpu_usage, vram_used, vram_total = _gpu_info()
    model_loaded = Path(settings.model_path).exists() and not settings.mock_mode
    backend = "TensorRT FP16" if str(settings.model_path).endswith((".engine", ".plan")) else ("PyTorch" if model_loaded else "Mock")
    return SystemStatus(
        platform=f"{platform.system()} {platform.release()}",
        cpu_percent=psutil.cpu_percent(interval=None),
        memory_percent=psutil.virtual_memory().percent,
        gpu_name=gpu_name,
        gpu_usage_percent=gpu_usage,
        vram_used_mb=round(vram_used, 1) if vram_used is not None else None,
        vram_total_mb=round(vram_total, 1) if vram_total is not None else None,
        model_loaded=model_loaded,
        inference_backend=backend,
    )
