from datetime import datetime, timezone
from typing import Literal
from uuid import uuid4
from pydantic import BaseModel, Field

JobStatus = Literal["queued", "running", "paused", "completed", "failed", "cancelled"]

class CreateJobRequest(BaseModel):
    source_type: Literal["mock", "video", "folder", "camera", "rtsp"] = "mock"
    source_path: str
    profile: Literal["fast", "balanced", "accuracy"] = "balanced"

class JobState(BaseModel):
    id: str = Field(default_factory=lambda: uuid4().hex[:12])
    status: JobStatus = "queued"
    source_type: str
    source_path: str
    profile: str
    progress: float = 0.0
    frame: int = 0
    total_frames: int = 900
    fps: float = 0.0
    active_tracks: int = 0
    unique_tracks: int = 0
    mean_confidence: float = 0.0
    tiling_active: bool = False
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
