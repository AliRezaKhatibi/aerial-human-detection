from typing import Literal
from pydantic import BaseModel

class InferenceProfile(BaseModel):
    id: Literal["fast", "balanced", "accuracy"]
    title: str
    subtitle: str
    enable_tiling: bool
    max_tiles: int
    refresh_interval: int | None
    full_imgsz: int = 1280
    tile_imgsz: int = 960
    recommended: bool = False
