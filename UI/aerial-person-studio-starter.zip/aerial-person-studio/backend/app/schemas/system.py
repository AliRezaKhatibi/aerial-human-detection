from pydantic import BaseModel

class SystemStatus(BaseModel):
    platform: str
    cpu_percent: float
    memory_percent: float
    gpu_name: str | None
    gpu_usage_percent: float | None
    vram_used_mb: float | None
    vram_total_mb: float | None
    model_loaded: bool
    inference_backend: str
