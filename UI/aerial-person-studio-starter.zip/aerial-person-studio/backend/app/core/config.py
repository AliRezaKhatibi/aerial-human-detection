from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_prefix="APS_", extra="ignore")
    env: str = "development"
    host: str = "127.0.0.1"
    port: int = 8000
    cors_origins: list[str] = ["http://127.0.0.1:1420", "http://localhost:1420", "tauri://localhost", "http://tauri.localhost"]
    mock_mode: bool = True
    model_path: Path = Path("../models/best.pt")
    database_url: str = "sqlite+aiosqlite:///../runtime/aerial_person_studio.db"
    output_dir: Path = Path("../runtime/outputs")
    log_level: str = "INFO"

settings = Settings()
settings.output_dir.mkdir(parents=True, exist_ok=True)
