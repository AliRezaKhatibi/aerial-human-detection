"""Detector adapter.

Phase 4 replaces this placeholder with a TensorRT-first implementation and
PyTorch fallback. The public method should remain stable for the API layer.
"""
from dataclasses import dataclass

@dataclass(slots=True)
class Detection:
    x1: float
    y1: float
    x2: float
    y2: float
    confidence: float
    class_id: int = 0

class Detector:
    def __init__(self, model_path: str) -> None:
        self.model_path = model_path

    def infer(self, frame, imgsz: int = 1280) -> list[Detection]:
        raise NotImplementedError("Connect YOLO26m-P2/TensorRT in the inference phase.")
