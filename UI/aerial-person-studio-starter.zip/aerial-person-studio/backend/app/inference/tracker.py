"""ByteTrack adapter contract."""
class Tracker:
    def update(self, detections, frame):
        raise NotImplementedError("Connect supervision.ByteTrack in the inference phase.")
