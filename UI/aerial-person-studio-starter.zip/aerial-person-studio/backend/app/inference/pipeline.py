"""Production video pipeline outline.

Decode -> full-frame inference -> optional ATTI tiles -> coordinate restore ->
fusion -> ByteTrack -> overlay -> encode -> telemetry event.
"""
class VideoPipeline:
    def process(self, source: str, output: str, profile: str) -> None:
        raise NotImplementedError("Implemented after UI and API contracts are approved.")
