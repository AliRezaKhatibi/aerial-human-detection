"""Cross-view detection fusion contract."""
def fuse_detections(full_detections, tile_detections, iou_threshold: float = 0.55):
    # Replace with class-aware cross-view NMS/weighted fusion.
    return [*full_detections, *tile_detections]
