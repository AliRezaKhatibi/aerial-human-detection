"""Adaptive temporal tiling (ATTI) contract."""
from dataclasses import dataclass

@dataclass(frozen=True, slots=True)
class Tile:
    x: int
    y: int
    width: int
    height: int

class AdaptiveTiler:
    def select_tiles(self, frame, tracks, max_tiles: int, refresh_interval: int | None) -> list[Tile]:
        # Implement confidence-drop, count-drop, and periodic-refresh triggers here.
        return []
