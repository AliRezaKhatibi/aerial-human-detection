# API contract v1

Base URL: `/api/v1`

## Health

`GET /health`

## System

`GET /system`

Returns CPU, RAM, GPU, VRAM, model status, and inference backend.

## Profiles

`GET /profiles`

Returns Fast, Balanced, and Accuracy settings. These are runtime profiles using the same trained model.

## Jobs

- `GET /jobs`
- `POST /jobs`
- `GET /jobs/{job_id}`
- `POST /jobs/{job_id}/cancel`

Planned:

- pause
- resume
- result download
- video upload/import
- RTSP source validation

## WebSocket

`/ws/jobs/{job_id}`

Each event is a full current job state so reconnecting clients do not need event replay for the initial version.
