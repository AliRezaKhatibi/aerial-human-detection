# Architecture

```text
Tauri desktop window
  -> React/Vite frontend
      -> REST for commands and queries
      -> WebSocket for progress telemetry
          -> FastAPI backend
              -> Job manager / single GPU worker
              -> Inference pipeline
                  -> YOLO26m-P2
                  -> ATTI tiles
                  -> cross-view fusion
                  -> ByteTrack
                  -> OpenCV/FFmpeg output
              -> SQLite + reports + logs
```

## Process separation

The frontend never imports Python or TensorRT directly. The backend owns GPU state and loads the model once. A single GPU worker prevents duplicate model allocation and makes cancellation, queueing, and telemetry predictable.

## Initial mock mode

Mock mode intentionally preserves the final API and WebSocket contracts while generating synthetic progress data. UI implementation can therefore continue before inference integration.

## Deployment milestone

The production bundle will package the FastAPI backend as a Windows sidecar executable. Tauri starts it on an available loopback port, waits for `/health`, then loads the main workspace.
