# Development roadmap

## Phase 1 — Foundation (included)

- Repository structure
- React/Tauri/FastAPI baseline
- Design tokens and dashboard shell
- RTL/LTR state
- REST and WebSocket contracts
- Mock processing worker

## Phase 2 — Final UI/UX

- Approve visual identity
- Complete New Analysis wizard
- Live preview player and timeline
- Results data table and charts
- Empty, loading, error, and offline states
- Keyboard navigation and accessibility

## Phase 3 — Persistence and job control

- SQLite models and migrations
- Project history
- Pause/resume/cancel state machine
- Output and storage management
- Structured logging and crash recovery

## Phase 4 — AI integration

- TensorRT and PyTorch detector adapters
- ATTI trigger logic
- Coordinate restoration and fusion
- ByteTrack integration
- Overlay renderer and telemetry
- Official metric validation

## Phase 5 — Video and reports

- Hardware-aware decode/encode
- MP4/CSV/JSON/PDF exports
- Snapshot and clip export
- Long-video reliability tests

## Phase 6 — Commercial packaging

- Python backend sidecar
- Model/resource bundling
- Windows MSI/NSIS installer
- Signed binaries and update channel
- Hardware compatibility diagnostics
- License and customer settings
