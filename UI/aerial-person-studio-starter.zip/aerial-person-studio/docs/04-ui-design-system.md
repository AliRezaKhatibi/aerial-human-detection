# UI design system

## Product character

- Professional and technical
- Calm rather than game-like
- High information density without clutter
- Dark-first for monitoring rooms
- Persian RTL and English LTR

## Core colors

- Background: `#070b12`
- Panel: `#0f1623`
- Primary: `#35d0ba`
- Secondary: `#7c8cff`
- Warning: `#f7bf59`
- Danger: `#ff6c80`

## Layout

- Fixed right sidebar in RTL
- Sticky top bar
- 12-column content grid
- 16–24 px spacing rhythm
- 12–24 px corner radius

## Typography

- Persian: Vazirmatn
- Latin: Inter
- Numeric monitoring values use bold, compact sizing

## Interaction

- Motion under 220 ms for routine interactions
- No decorative animation during live video processing
- Important status must use icon + text, not color alone
