$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$Python = "$Root/backend/.venv/Scripts/python.exe"
if (-not (Test-Path $Python)) { throw "Run setup.ps1 first." }
& $Python -m compileall -q "$Root/backend/app"
Push-Location "$Root/backend"
try { & ".venv/Scripts/python.exe" -m pytest -q } finally { Pop-Location }
Push-Location "$Root/frontend"
try { npm run build } finally { Pop-Location }
Write-Host "Verification passed." -ForegroundColor Green
