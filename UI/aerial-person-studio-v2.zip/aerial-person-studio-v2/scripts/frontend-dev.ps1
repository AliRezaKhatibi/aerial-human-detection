$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
if (-not (Test-Path "$Root/frontend/node_modules")) {
  throw "Frontend dependencies are missing. Run .\scripts\setup.ps1 first."
}
Set-Location "$Root/frontend"
npm run dev
