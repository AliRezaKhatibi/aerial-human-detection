param(
  [switch]$RequireDesktop
)

$ErrorActionPreference = "Continue"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root

$LogDir = Join-Path $Root "runtime/logs"
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$LogFile = Join-Path $LogDir "doctor.txt"

$lines = New-Object System.Collections.Generic.List[string]
function Add-Result([string]$Name, [bool]$Ok, [string]$Value, [string]$Help = "") {
  $tag = if ($Ok) { "OK" } else { "FAIL" }
  $color = if ($Ok) { "Green" } else { "Red" }
  $line = "[$tag] $Name : $Value"
  Write-Host $line -ForegroundColor $color
  $lines.Add($line)
  if (-not $Ok -and $Help) {
    Write-Host "      $Help" -ForegroundColor Yellow
    $lines.Add("      $Help")
  }
}

Write-Host "Aerial Person Studio - Environment Doctor" -ForegroundColor Cyan
Write-Host "Project: $Root`n"

# Node.js
$nodeOk = $false
$nodeValue = "not found"
if (Get-Command node -ErrorAction SilentlyContinue) {
  try {
    $nodeValue = (& node --version).Trim()
    $ver = [version]($nodeValue.TrimStart('v'))
    $nodeOk = ($ver.Major -gt 20) -or ($ver.Major -eq 20 -and $ver.Minor -ge 19)
  } catch {}
}
Add-Result "Node.js" $nodeOk $nodeValue "Install Node.js 22 LTS, then close and reopen PowerShell."

# npm
$npmOk = $false
$npmValue = "not found"
if (Get-Command npm -ErrorAction SilentlyContinue) {
  try { $npmValue = (& npm --version).Trim(); $npmOk = $LASTEXITCODE -eq 0 } catch {}
}
Add-Result "npm" $npmOk $npmValue "npm is installed with Node.js."

# Python 3.11/3.12
$pythonExe = $null
$pythonValue = "not found"
$candidates = @()
if (Get-Command py -ErrorAction SilentlyContinue) {
  $candidates += ,@("py", "-3.12")
  $candidates += ,@("py", "-3.11")
}
if (Get-Command python -ErrorAction SilentlyContinue) {
  $candidates += ,@("python")
}
foreach ($candidate in $candidates) {
  try {
    $cmd = $candidate[0]
    $args = @()
    if ($candidate.Count -gt 1) { $args = $candidate[1..($candidate.Count-1)] }
    $out = & $cmd @args -c "import sys; print(sys.executable); print(f'{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}')" 2>$null
    if ($LASTEXITCODE -eq 0 -and $out.Count -ge 2) {
      $v = [version]$out[1]
      if ($v.Major -eq 3 -and ($v.Minor -eq 11 -or $v.Minor -eq 12)) {
        $pythonExe = $out[0].Trim()
        $pythonValue = "$($out[1].Trim()) - $pythonExe"
        break
      }
    }
  } catch {}
}
Add-Result "Python" ($null -ne $pythonExe) $pythonValue "Install Python 3.12 x64. Python 3.13 is not used by this starter."

# Rust and Cargo (required only for Tauri desktop)
$rustOk = $false
$rustValue = "not found"
if (Get-Command rustc -ErrorAction SilentlyContinue) {
  try { $rustValue = (& rustc --version).Trim(); $rustOk = $LASTEXITCODE -eq 0 } catch {}
}
Add-Result "Rust" ($rustOk -or -not $RequireDesktop) $rustValue $(if ($RequireDesktop) { "Install Rust stable using rustup." } else { "Optional for web development; required for the Tauri desktop window." })

$cargoOk = $false
$cargoValue = "not found"
if (Get-Command cargo -ErrorAction SilentlyContinue) {
  try { $cargoValue = (& cargo --version).Trim(); $cargoOk = $LASTEXITCODE -eq 0 } catch {}
}
Add-Result "Cargo" ($cargoOk -or -not $RequireDesktop) $cargoValue $(if ($RequireDesktop) { "Cargo is installed with Rust." } else { "Optional for web development; required for Tauri." })

# Project files
$files = @(
  "frontend/package.json",
  "backend/pyproject.toml",
  "src-tauri/Cargo.toml",
  "src-tauri/tauri.conf.json"
)
$missing = @($files | Where-Object { -not (Test-Path (Join-Path $Root $_)) })
Add-Result "Project files" ($missing.Count -eq 0) $(if ($missing.Count -eq 0) { "present" } else { "missing: $($missing -join ', ')" }) "Extract the ZIP completely before running scripts."

$lines | Set-Content -Encoding UTF8 $LogFile
Write-Host "`nDiagnostic report: $LogFile" -ForegroundColor Cyan

$requiredOk = $nodeOk -and $npmOk -and ($null -ne $pythonExe) -and ($missing.Count -eq 0)
if ($RequireDesktop) { $requiredOk = $requiredOk -and $rustOk -and $cargoOk }
if (-not $requiredOk) { exit 1 }
exit 0
