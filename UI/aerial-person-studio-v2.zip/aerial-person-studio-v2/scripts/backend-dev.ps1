$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$Python = "$Root/backend/.venv/Scripts/python.exe"
if (-not (Test-Path $Python)) {
  throw "Backend virtual environment is missing. Run .\scripts\setup.ps1 first."
}
Set-Location "$Root/backend"
& $Python -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
