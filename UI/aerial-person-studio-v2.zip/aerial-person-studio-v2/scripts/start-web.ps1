$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
if (-not (Test-Path "$Root/backend/.venv/Scripts/python.exe") -or -not (Test-Path "$Root/frontend/node_modules")) {
  throw "Project is not set up. Run .\scripts\setup.ps1 first."
}
$PowerShell = (Get-Process -Id $PID).Path
Start-Process -FilePath $PowerShell -ArgumentList @("-NoExit", "-ExecutionPolicy", "Bypass", "-File", "$Root/scripts/backend-dev.ps1")
Start-Sleep -Seconds 2
Start-Process -FilePath $PowerShell -ArgumentList @("-NoExit", "-ExecutionPolicy", "Bypass", "-File", "$Root/scripts/frontend-dev.ps1")
Write-Host "Backend: http://127.0.0.1:8000/docs" -ForegroundColor Cyan
Write-Host "Frontend: http://127.0.0.1:1420" -ForegroundColor Cyan
