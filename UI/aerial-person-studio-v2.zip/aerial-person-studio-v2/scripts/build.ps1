$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
& "$PSScriptRoot/doctor.ps1" -RequireDesktop
if ($LASTEXITCODE -ne 0) { throw "Desktop prerequisites are missing." }
Push-Location "$Root/frontend"
try { npm run tauri -- build --config ../src-tauri/tauri.conf.json } finally { Pop-Location }
