$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
& "$PSScriptRoot/doctor.ps1" -RequireDesktop
if ($LASTEXITCODE -ne 0) { throw "Desktop prerequisites are missing. See runtime/logs/doctor.txt" }
if (-not (Test-Path "$Root/frontend/node_modules")) { throw "Run .\scripts\setup.ps1 first." }
Write-Host "Start the FastAPI backend in another terminal before opening Tauri." -ForegroundColor Yellow
Set-Location "$Root/frontend"
npm run tauri -- dev --config ../src-tauri/tauri.conf.json
