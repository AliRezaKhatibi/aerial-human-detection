# Aerial Person Studio v0.2

Starter اصلاح‌شده برای رابط تجاری تشخیص و ردیابی افراد در تصاویر هوایی.

## فناوری‌ها

- Tauri 2
- React + TypeScript + Vite
- Tailwind CSS
- FastAPI + WebSocket
- SQLite
- YOLO26m-P2 / TensorRT / ByteTrack در مراحل بعد

## اجرای مرحله اول: نسخه وب

PowerShell را در ریشه پروژه باز کنید:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\scripts\doctor.ps1
.\scripts\setup.ps1
.\scripts\start-web.ps1
```

آدرس‌ها:

- `http://127.0.0.1:8000/docs`
- `http://127.0.0.1:1420`

## اجرای Desktop

تنها بعد از سالم بودن نسخه وب:

```powershell
.\scripts\tauri-dev.ps1
```

این مرحله علاوه بر Node و Python به Rust، Cargo، Microsoft C++ Build Tools و WebView2 نیاز دارد.

## تشخیص خطا

راهنمای کامل در `TROUBLESHOOTING_FA.md` است. گزارش‌ها در این مسیر ذخیره می‌شوند:

```text
runtime/logs/doctor.txt
runtime/logs/setup.log
```

## وضعیت مدل

پروژه در حالت Mock شروع می‌شود. بعداً مدل در یکی از مسیرهای زیر قرار می‌گیرد:

```text
models/best.pt
models/aerial-person.onnx
models/aerial-person.engine
```
