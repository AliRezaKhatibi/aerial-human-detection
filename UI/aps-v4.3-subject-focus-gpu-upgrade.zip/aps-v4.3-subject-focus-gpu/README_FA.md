# Aerial Person Studio v4.3

این ارتقا دو مسئله را برطرف می‌کند:

1. انتخاب یک یا چند Track ID در پردازش زنده، با کلیک روی Bounding Box یا دکمه ID.
2. تفکیک «GPU شناسایی‌شده» از «دستگاه واقعی استنتاج»؛ اگر PyTorch روی CPU باشد رابط دیگر GPU را به‌اشتباه فعال نشان نمی‌دهد.

## قابلیت انتخاب سوژه

- انتخاب یک یا چند ID
- قرمز شدن باکس سوژه‌های انتخاب‌شده
- کم‌رنگ شدن صحنه و Trackهای دیگر
- نگه‌داشتن انتخاب در قطع کوتاه Track
- پاک‌کردن همه انتخاب‌ها
- ثبت ستون selected در CSV

انتخاب از لحظه اعمال به بعد روی ویدئوی خروجی اثر می‌گذارد و فریم‌های قبلی را بازنویسی نمی‌کند.

## نصب

Backend و Frontend را متوقف کنید، سپس:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\apply-v4.3.ps1 -ProjectPath "D:\APS\app"
```

## بررسی دستگاه واقعی

```powershell
cd "D:\APS\app"
.\scripts\verify-compute.ps1
```

اگر NVIDIA GPU شناسایی شد ولی CUDA unavailable بود، پس از به‌روزرسانی درایور:

```powershell
.\scripts\install-torch-cuda.ps1 -CudaWheel cu128
```

سپس Backend را Restart کنید.
