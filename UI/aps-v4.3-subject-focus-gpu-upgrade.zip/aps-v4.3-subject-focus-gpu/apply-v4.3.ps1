param(
  [string]$ProjectPath = "D:\APS\app"
)

$ErrorActionPreference = "Stop"

function Assert-Exists([string]$Path, [string]$Label) {
  if (-not (Test-Path $Path)) { throw "$Label not found: $Path" }
}

$ProjectPath = (Resolve-Path $ProjectPath).Path
$PayloadRoot = Join-Path $PSScriptRoot "payload"
$ManifestPath = Join-Path $PSScriptRoot "MANIFEST.txt"
$Python = Join-Path $ProjectPath "backend\.venv\Scripts\python.exe"

Assert-Exists $PayloadRoot "Upgrade payload"
Assert-Exists $ManifestPath "Upgrade manifest"
Assert-Exists $Python "Backend Python environment"
Assert-Exists (Join-Path $ProjectPath "frontend\package.json") "Frontend package"

$Files = Get-Content $ManifestPath | Where-Object { $_ -and -not $_.StartsWith("#") }
$Timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$BackupPath = Join-Path $ProjectPath "v4.3-backup-$Timestamp"
New-Item -ItemType Directory -Force $BackupPath | Out-Null

Write-Host "Aerial Person Studio - v4.3 Subject Focus & GPU Truth Upgrade" -ForegroundColor Cyan
Write-Host "Project: $ProjectPath"
Write-Host "Backup:  $BackupPath"

try {
  Write-Host "[1/5] Backing up changed files..." -ForegroundColor Yellow
  foreach ($Relative in $Files) {
    $Target = Join-Path $ProjectPath $Relative
    if (Test-Path $Target) {
      $BackupTarget = Join-Path $BackupPath $Relative
      New-Item -ItemType Directory -Force (Split-Path -Parent $BackupTarget) | Out-Null
      Copy-Item $Target $BackupTarget -Force
    }
  }

  Write-Host "[2/5] Applying backend, frontend, and diagnostic files..." -ForegroundColor Yellow
  foreach ($Relative in $Files) {
    $Source = Join-Path $PayloadRoot $Relative
    $Target = Join-Path $ProjectPath $Relative
    Assert-Exists $Source "Payload file"
    New-Item -ItemType Directory -Force (Split-Path -Parent $Target) | Out-Null
    Copy-Item $Source $Target -Force
  }

  Write-Host "[3/5] Validating backend syntax and tests..." -ForegroundColor Yellow
  Push-Location (Join-Path $ProjectPath "backend")
  try {
    & $Python -m compileall -q app
    if ($LASTEXITCODE -ne 0) { throw "Python syntax validation failed." }
    & $Python -m pytest -q
    if ($LASTEXITCODE -ne 0) { throw "Backend tests failed." }
  }
  finally { Pop-Location }

  Write-Host "[4/5] Building frontend..." -ForegroundColor Yellow
  Push-Location $ProjectPath
  try {
    & npm --prefix frontend run build
    if ($LASTEXITCODE -ne 0) { throw "Frontend build failed." }
  }
  finally { Pop-Location }

  Write-Host "[5/5] Verifying compute-report script..." -ForegroundColor Yellow
  & (Join-Path $ProjectPath "scripts\verify-compute.ps1") -ProjectPath $ProjectPath
  if ($LASTEXITCODE -ne 0) { throw "Compute verification script failed." }

  Write-Host ""
  Write-Host "v4.3 upgrade completed successfully." -ForegroundColor Green
  Write-Host "Restart backend and frontend before starting a new job."
  Write-Host "Backup: $BackupPath"
}
catch {
  Write-Host "Upgrade failed. Restoring changed files..." -ForegroundColor Red
  foreach ($Relative in $Files) {
    $BackupFile = Join-Path $BackupPath $Relative
    $Target = Join-Path $ProjectPath $Relative
    if (Test-Path $BackupFile) {
      New-Item -ItemType Directory -Force (Split-Path -Parent $Target) | Out-Null
      Copy-Item $BackupFile $Target -Force
    }
  }
  throw
}
