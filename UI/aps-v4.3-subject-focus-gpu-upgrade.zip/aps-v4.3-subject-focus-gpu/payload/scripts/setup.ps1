$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root

$LogDir = Join-Path $Root "runtime/logs"
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$LogFile = Join-Path $LogDir "setup.log"

try {
  Start-Transcript -Path $LogFile -Force | Out-Null

  Write-Host "[0/5] Checking prerequisites..." -ForegroundColor Cyan
  & "$PSScriptRoot/doctor.ps1"
  if ($LASTEXITCODE -ne 0) { throw "Prerequisite check failed. See runtime/logs/doctor.txt" }

  Write-Host "[1/5] Installing frontend packages with npm..." -ForegroundColor Cyan
  Push-Location "$Root/frontend"
  try {
    npm install
    if ($LASTEXITCODE -ne 0) { throw "npm install failed" }
  } finally { Pop-Location }

  Write-Host "[2/5] Selecting Python 3.12 or 3.11..." -ForegroundColor Cyan
  $PythonExe = $null
  if (Get-Command py -ErrorAction SilentlyContinue) {
    foreach ($tag in @("-3.12", "-3.11")) {
      try {
        $candidate = (& py $tag -c "import sys; print(sys.executable)" 2>$null).Trim()
        if ($LASTEXITCODE -eq 0 -and $candidate) { $PythonExe = $candidate; break }
      } catch {}
    }
  }
  if (-not $PythonExe -and (Get-Command python -ErrorAction SilentlyContinue)) {
    $candidate = (& python -c "import sys; print(sys.executable); print(f'{sys.version_info.major}.{sys.version_info.minor}')")
    if ($candidate.Count -ge 2 -and $candidate[1] -in @("3.11", "3.12")) { $PythonExe = $candidate[0] }
  }
  if (-not $PythonExe) { throw "Python 3.11 or 3.12 was not found." }

  Write-Host "[3/5] Creating backend virtual environment..." -ForegroundColor Cyan
  if (-not (Test-Path "$Root/backend/.venv/Scripts/python.exe")) {
    & $PythonExe -m venv "$Root/backend/.venv"
  }
  $VenvPython = "$Root/backend/.venv/Scripts/python.exe"
  & $VenvPython -m pip install --upgrade pip setuptools wheel
  if ($LASTEXITCODE -ne 0) { throw "Python packaging tools installation failed" }
  & $VenvPython -m pip install -e "$Root/backend[dev]"
  if ($LASTEXITCODE -ne 0) { throw "Backend dependency installation failed" }

  Write-Host "[4/5] Preparing environment files and runtime directories..." -ForegroundColor Cyan
  New-Item -ItemType Directory -Force -Path "$Root/runtime/outputs", "$Root/runtime/logs", "$Root/models" | Out-Null

  # Vite exposes import.meta.env through the vite/client type declarations.
  # Recreate this file automatically if it is missing from a copied project.
  $ViteEnvFile = "$Root/frontend/src/vite-env.d.ts"
  if (-not (Test-Path $ViteEnvFile)) {
    '/// <reference types="vite/client" />' | Set-Content -Path $ViteEnvFile -Encoding utf8
  }
  if (-not (Test-Path "$Root/backend/.env")) { Copy-Item "$Root/backend/.env.example" "$Root/backend/.env" }
  if (-not (Test-Path "$Root/frontend/.env")) { Copy-Item "$Root/frontend/.env.example" "$Root/frontend/.env" }

  Write-Host "[5/5] Verifying backend and frontend build..." -ForegroundColor Cyan
  & $VenvPython -m compileall -q "$Root/backend/app"
  Push-Location "$Root/backend"
  try {
    & ".venv/Scripts/python.exe" -m pytest -q
    if ($LASTEXITCODE -ne 0) { throw "Backend tests failed" }
  } finally { Pop-Location }
  Push-Location "$Root/frontend"
  try {
    npm run build
    if ($LASTEXITCODE -ne 0) { throw "Frontend build failed" }
  } finally { Pop-Location }

  Write-Host "`nSetup completed successfully." -ForegroundColor Green
  Write-Host "Next: .\scripts\start-web.ps1" -ForegroundColor Green
}
catch {
  Write-Host "`nSETUP FAILED: $($_.Exception.Message)" -ForegroundColor Red
  Write-Host "Full log: $LogFile" -ForegroundColor Yellow
  throw
}
finally {
  try { Stop-Transcript | Out-Null } catch {}
}
