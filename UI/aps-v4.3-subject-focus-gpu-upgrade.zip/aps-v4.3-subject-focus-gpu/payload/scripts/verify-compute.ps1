param(
  [string]$ProjectPath = "D:\APS\app"
)

$ErrorActionPreference = "Stop"
$ProjectPath = (Resolve-Path $ProjectPath).Path
$Python = Join-Path $ProjectPath "backend\.venv\Scripts\python.exe"

if (-not (Test-Path $Python)) {
  throw "Backend virtual environment was not found: $Python"
}

Write-Host "Aerial Person Studio - Compute Runtime Check" -ForegroundColor Cyan
Write-Host "Project: $ProjectPath"

@'
import json
import platform

result = {
    "python": platform.python_version(),
    "torch": None,
    "torch_cuda_runtime": None,
    "cuda_available": False,
    "device": "CPU",
    "gpu_count": 0,
}

try:
    import torch
    result["torch"] = torch.__version__
    result["torch_cuda_runtime"] = torch.version.cuda
    result["cuda_available"] = bool(torch.cuda.is_available())
    result["gpu_count"] = int(torch.cuda.device_count()) if result["cuda_available"] else 0
    if result["cuda_available"]:
        result["device"] = f"CUDA:0 · {torch.cuda.get_device_name(0)}"
except Exception as exc:
    result["torch_error"] = f"{type(exc).__name__}: {exc}"

try:
    import pynvml
    pynvml.nvmlInit()
    handle = pynvml.nvmlDeviceGetHandleByIndex(0)
    name = pynvml.nvmlDeviceGetName(handle)
    if isinstance(name, bytes):
        name = name.decode("utf-8")
    result["nvidia_adapter"] = str(name)
except Exception as exc:
    result["nvidia_adapter"] = None
    result["nvml_error"] = f"{type(exc).__name__}: {exc}"

print(json.dumps(result, indent=2, ensure_ascii=False))
'@ | & $Python -

if ($LASTEXITCODE -ne 0) {
  throw "Compute verification failed."
}
