param(
  [string]$ProjectPath = "D:\APS\app",
  [ValidateSet("cu128", "cu126")]
  [string]$CudaWheel = "cu128"
)

$ErrorActionPreference = "Stop"
$ProjectPath = (Resolve-Path $ProjectPath).Path
$Python = Join-Path $ProjectPath "backend\.venv\Scripts\python.exe"
$LogDir = Join-Path $ProjectPath "runtime\logs"

if (-not (Test-Path $Python)) {
  throw "Backend virtual environment was not found: $Python"
}
if (-not (Get-Command nvidia-smi -ErrorAction SilentlyContinue)) {
  throw "nvidia-smi was not found. Install or update the NVIDIA display driver first."
}

New-Item -ItemType Directory -Force $LogDir | Out-Null
$Timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$FreezePath = Join-Path $LogDir "pip-before-cuda-$Timestamp.txt"

Write-Host "Aerial Person Studio - CUDA PyTorch Installer" -ForegroundColor Cyan
Write-Host "Project: $ProjectPath"
Write-Host "Wheel channel: $CudaWheel"

& $Python -m pip freeze | Set-Content $FreezePath -Encoding utf8
Write-Host "Saved current package list: $FreezePath"

& $Python -m pip uninstall torch torchvision torchaudio -y
if ($LASTEXITCODE -ne 0) { throw "Could not uninstall the current PyTorch packages." }

$IndexUrl = "https://download.pytorch.org/whl/$CudaWheel"
& $Python -m pip install torch torchvision --index-url $IndexUrl
if ($LASTEXITCODE -ne 0) { throw "CUDA-enabled PyTorch installation failed." }

@'
import torch
print("Torch:", torch.__version__)
print("CUDA runtime:", torch.version.cuda)
print("CUDA available:", torch.cuda.is_available())
print("GPU:", torch.cuda.get_device_name(0) if torch.cuda.is_available() else "CPU")
raise SystemExit(0 if torch.cuda.is_available() else 2)
'@ | & $Python -

if ($LASTEXITCODE -ne 0) {
  throw "PyTorch was installed, but CUDA is still unavailable. Update the NVIDIA driver and run scripts\verify-compute.ps1."
}

Write-Host "CUDA-enabled PyTorch is ready." -ForegroundColor Green
Write-Host "Restart the backend before processing another video."
