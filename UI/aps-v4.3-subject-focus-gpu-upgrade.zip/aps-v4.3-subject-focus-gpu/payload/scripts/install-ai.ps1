$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$Python = Join-Path $ProjectRoot "backend\.venv\Scripts\python.exe"
$EnvFile = Join-Path $ProjectRoot "backend\.env"
$EnvExample = Join-Path $ProjectRoot "backend\.env.example"

Write-Host "Aerial Person Studio - AI Runtime Installer" -ForegroundColor Cyan
Write-Host "Project: $ProjectRoot"

if (-not (Test-Path $Python)) {
    throw "Python virtual environment was not found. Run .\scripts\setup.ps1 first."
}

Write-Host "[1/4] Upgrading packaging tools..." -ForegroundColor Yellow
& $Python -m pip install --upgrade pip setuptools wheel
if ($LASTEXITCODE -ne 0) { throw "Could not upgrade pip tools." }

Write-Host "[2/4] Installing the pinned inference runtime..." -ForegroundColor Yellow
& $Python -m pip install -e "$ProjectRoot\backend[ai]"
if ($LASTEXITCODE -ne 0) { throw "AI dependency installation failed." }

Write-Host "[3/4] Enabling real inference mode..." -ForegroundColor Yellow
if (-not (Test-Path $EnvFile)) {
    Copy-Item $EnvExample $EnvFile
}
$Content = Get-Content $EnvFile -Raw
if ($Content -match '(?m)^APS_MOCK_MODE=') {
    $Content = [regex]::Replace($Content, '(?m)^APS_MOCK_MODE=.*$', 'APS_MOCK_MODE=false')
} else {
    $Content = $Content.TrimEnd() + "`r`nAPS_MOCK_MODE=false`r`n"
}
Set-Content -Path $EnvFile -Value $Content -Encoding utf8

Write-Host "[4/4] Verifying OpenCV, Ultralytics, CUDA, and local models..." -ForegroundColor Yellow
Push-Location (Join-Path $ProjectRoot "backend")
try {
@'
import cv2
import torch
import ultralytics
from app.services.model_manager import model_manager

status = model_manager.status()
print(f"OpenCV: {cv2.__version__}")
print(f"Ultralytics: {ultralytics.__version__}")
print(f"Torch: {torch.__version__}")
print(f"CUDA runtime: {torch.version.cuda}")
print(f"CUDA available: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print(f"GPU: {torch.cuda.get_device_name(0)}")
else:
    print("Inference device: CPU")
print(f"Models found: {len(status.models)}")
for model in status.models:
    marker = "*" if model.selected else "-"
    print(f"  {marker} {model.name} ({model.format}, {model.size_mb:.1f} MB)")
if not status.available:
    raise SystemExit("No model was found. Put best.pt in the models directory.")
'@ | & $Python -
    if ($LASTEXITCODE -ne 0) { throw "AI runtime verification failed." }
}
finally {
    Pop-Location
}

Write-Host ""
Write-Host "AI runtime installed successfully." -ForegroundColor Green
Write-Host "Run .\scripts\verify-compute.ps1 to confirm the actual inference device."
Write-Host "Restart the backend: .\scripts\backend-dev.ps1"
Write-Host "Then open: http://127.0.0.1:1420"
