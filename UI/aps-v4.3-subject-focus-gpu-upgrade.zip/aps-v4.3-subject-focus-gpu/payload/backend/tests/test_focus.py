from fastapi.testclient import TestClient

from app.main import app


def test_live_focus_selection() -> None:
    with TestClient(app) as client:
        created = client.post(
            "/api/v1/jobs",
            json={
                "source_type": "mock",
                "source_path": "focus-demo.mp4",
                "profile": "fast",
                "confidence": 0.2,
                "show_trails": True,
                "show_track_ids": True,
                "show_confidence": True,
                "save_video": False,
                "save_csv": False,
                "save_json": False,
            },
        )
        assert created.status_code == 201
        job_id = created.json()["id"]

        focused = client.post(
            f"/api/v1/jobs/{job_id}/focus",
            json={"track_ids": [7, 12], "dim_others": True},
        )
        assert focused.status_code == 200
        body = focused.json()
        assert body["selected_track_ids"] == [7, 12]
        assert body["focus_dim_others"] is True
