from __future__ import annotations

from datetime import datetime, timezone
from typing import Literal
from uuid import uuid4

from pydantic import BaseModel, Field

JobStatus = Literal["queued", "running", "paused", "completed", "failed", "cancelled"]


class CreateJobRequest(BaseModel):
    source_type: Literal["mock", "video", "folder", "camera", "rtsp"] = "video"
    source_path: str
    source_name: str | None = None
    profile: Literal["fast", "balanced", "accuracy"] = "balanced"
    confidence: float = Field(default=0.20, ge=0.01, le=0.95)
    show_trails: bool = True
    show_track_ids: bool = True
    show_confidence: bool = True
    save_video: bool = True
    save_csv: bool = True
    save_json: bool = True
    model_id: str | None = None


class FocusUpdateRequest(BaseModel):
    track_ids: list[int] = Field(default_factory=list, max_length=24)
    dim_others: bool = True


class JobState(BaseModel):
    id: str = Field(default_factory=lambda: uuid4().hex[:12])
    status: JobStatus = "queued"
    source_type: str
    source_path: str
    source_name: str | None = None
    profile: str
    confidence: float = 0.20
    progress: float = 0.0
    frame: int = 0
    total_frames: int = 0
    frame_width: int = 0
    frame_height: int = 0
    fps: float = 0.0
    inference_ms: float = 0.0
    inference_device: str = "unknown"
    elapsed_seconds: float = 0.0
    active_tracks: int = 0
    active_track_ids: list[int] = Field(default_factory=list)
    active_track_boxes: list[dict[str, float | int | bool]] = Field(default_factory=list)
    selected_track_ids: list[int] = Field(default_factory=list)
    focus_dim_others: bool = True
    unique_tracks: int = 0
    mean_confidence: float = 0.0
    tiling_active: bool = False
    processed_tiles: int = 0
    preview_available: bool = False
    model_name: str | None = None
    output_video_path: str | None = None
    report_csv_path: str | None = None
    report_json_path: str | None = None
    error: str | None = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
