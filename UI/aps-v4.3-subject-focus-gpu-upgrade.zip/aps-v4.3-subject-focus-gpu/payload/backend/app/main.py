from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.router import api_router
from app.core.config import settings
from app.services.job_manager import job_manager


@asynccontextmanager
async def lifespan(_: FastAPI):
    await job_manager.start()
    yield
    await job_manager.shutdown()


app = FastAPI(
    title="Aerial Person Studio API",
    version="0.4.3",
    description="Local API for aerial person detection, tracking, and video analysis.",
    lifespan=lifespan,
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(api_router, prefix="/api/v1")


@app.get("/")
async def root() -> dict[str, str]:
    return {"service": "Aerial Person Studio API", "docs": "/docs", "version": "0.4.3"}
