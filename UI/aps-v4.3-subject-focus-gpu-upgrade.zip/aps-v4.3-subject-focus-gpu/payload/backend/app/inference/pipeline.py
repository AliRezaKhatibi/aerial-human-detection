from __future__ import annotations

import csv
import json
import threading
import time
from collections import defaultdict, deque
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

import numpy as np

from app.core.config import settings
from app.inference.detector import Detector
from app.inference.fusion import nms_fusion
from app.inference.tiling import generate_tiles, select_balanced_tiles
from app.inference.tracker import ByteTrackAdapter, StableIdReconciler, Track


ProgressCallback = Callable[[dict[str, object]], None]
FocusGetter = Callable[[], tuple[set[int], bool]]


class PipelineCancelled(RuntimeError):
    pass


@dataclass(slots=True)
class PipelineOptions:
    job_id: str
    source_path: Path
    source_name: str
    profile: str
    confidence: float
    show_trails: bool
    show_track_ids: bool
    show_confidence: bool
    save_video: bool
    save_csv: bool
    save_json: bool


@dataclass(slots=True)
class PipelineResult:
    output_video_path: str | None
    report_csv_path: str | None
    report_json_path: str | None
    total_frames: int
    elapsed_seconds: float
    average_fps: float
    unique_tracks: int


def _draw_tracks(
    frame: np.ndarray,
    tracks: list[Track],
    trails: dict[int, deque[tuple[int, int]]],
    options: PipelineOptions,
    selected_ids: set[int],
    dim_others: bool,
) -> tuple[np.ndarray, list[Track]]:
    import cv2

    visible = [track for track in tracks if track.confidence >= options.confidence]
    selected_visible = [track for track in visible if track.track_id in selected_ids]

    # Subject-isolation mode dims the scene, then restores the selected subjects.
    # This keeps the selected person visually clear without changing tracking logic.
    if selected_ids and dim_others and selected_visible:
        original = frame.copy()
        frame = cv2.addWeighted(frame, 0.30, np.zeros_like(frame), 0.70, 0)
        frame_height, frame_width = frame.shape[:2]
        for track in selected_visible:
            pad = max(8, int(min(track.x2 - track.x1, track.y2 - track.y1) * 0.18))
            x1 = max(0, int(track.x1) - pad)
            y1 = max(0, int(track.y1) - pad)
            x2 = min(frame_width, int(track.x2) + pad)
            y2 = min(frame_height, int(track.y2) + pad)
            if x2 > x1 and y2 > y1:
                frame[y1:y2, x1:x2] = original[y1:y2, x1:x2]

    focus_active = bool(selected_ids)
    for track in visible:
        x1, y1, x2, y2 = map(int, (track.x1, track.y1, track.x2, track.y2))
        selected = track.track_id in selected_ids
        if selected:
            color = (35, 45, 245)  # BGR red
            thickness = 3
        elif focus_active:
            color = (82, 92, 100)  # muted gray for non-selected tracks
            thickness = 1
        else:
            color = (201, 214, 54)  # BGR teal-like accent
            thickness = 2

        cv2.rectangle(frame, (x1, y1), (x2, y2), color, thickness, cv2.LINE_AA)

        label_parts: list[str] = []
        # During focus mode, labels are intentionally reduced for non-selected
        # subjects so the chosen tracks remain easy to follow.
        show_label = selected or not focus_active
        if show_label and options.show_track_ids:
            label_parts.append(f"{'FOCUS ' if selected else ''}ID {track.track_id}")
        if show_label and options.show_confidence:
            label_parts.append(f"{track.confidence:.2f}")
        label = "  ".join(label_parts)
        if label:
            (text_w, text_h), baseline = cv2.getTextSize(
                label, cv2.FONT_HERSHEY_SIMPLEX, 0.52, 1
            )
            top = max(0, y1 - text_h - baseline - 7)
            cv2.rectangle(frame, (x1, top), (x1 + text_w + 10, y1), color, -1)
            cv2.putText(
                frame,
                label,
                (x1 + 5, y1 - 5),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.52,
                (255, 255, 255) if selected else (4, 12, 18),
                1,
                cv2.LINE_AA,
            )

        center = (int((x1 + x2) / 2), int((y1 + y2) / 2))
        trails[track.track_id].append(center)
        if options.show_trails and len(trails[track.track_id]) > 1:
            points = np.asarray(trails[track.track_id], dtype=np.int32).reshape((-1, 1, 2))
            cv2.polylines(frame, [points], False, color, thickness, cv2.LINE_AA)

    return frame, visible


def _write_preview(frame: np.ndarray, preview_path: Path) -> None:
    import cv2

    preview_path.parent.mkdir(parents=True, exist_ok=True)
    temporary = preview_path.with_suffix(".tmp.jpg")
    if cv2.imwrite(str(temporary), frame, [int(cv2.IMWRITE_JPEG_QUALITY), 84]):
        temporary.replace(preview_path)


def _create_writer(output_path: Path, fps: float, width: int, height: int):
    import cv2

    output_path.parent.mkdir(parents=True, exist_ok=True)
    for codec in ("mp4v", "avc1"):
        writer = cv2.VideoWriter(
            str(output_path),
            cv2.VideoWriter_fourcc(*codec),
            fps,
            (width, height),
        )
        if writer.isOpened():
            return writer
        writer.release()
    raise RuntimeError("OpenCV could not create an MP4 video writer on this system.")


def _tile_detections(
    detector: Detector,
    frame: np.ndarray,
    tiles,
    confidence: float,
) -> tuple[list[np.ndarray], float]:
    outputs: list[np.ndarray] = []
    total_ms = 0.0
    for tile in tiles:
        crop = frame[tile.y1 : tile.y2, tile.x1 : tile.x2]
        prediction = detector.infer(crop, imgsz=960, confidence=confidence)
        total_ms += prediction.inference_ms
        if len(prediction.boxes):
            mapped = prediction.boxes.copy()
            mapped[:, [0, 2]] += tile.x1
            mapped[:, [1, 3]] += tile.y1
            outputs.append(mapped)
    return outputs, total_ms


def _track_boxes(tracks: list[Track], selected_ids: set[int]) -> list[dict[str, float | int | bool]]:
    return [
        {
            "track_id": int(track.track_id),
            "x1": round(float(track.x1), 2),
            "y1": round(float(track.y1), 2),
            "x2": round(float(track.x2), 2),
            "y2": round(float(track.y2), 2),
            "confidence": round(float(track.confidence), 5),
            "selected": track.track_id in selected_ids,
        }
        for track in tracks
    ]


def process_video(
    model,
    options: PipelineOptions,
    progress_callback: ProgressCallback,
    cancel_event: threading.Event,
    focus_getter: FocusGetter | None = None,
) -> PipelineResult:
    try:
        import cv2
    except ImportError as exc:
        raise RuntimeError(
            "OpenCV is not installed. Run scripts\\install-ai.ps1 and restart the backend."
        ) from exc

    focus_getter = focus_getter or (lambda: (set(), True))
    capture = cv2.VideoCapture(str(options.source_path))
    if not capture.isOpened():
        raise RuntimeError(f"Could not open video: {options.source_path}")

    width = int(capture.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
    height = int(capture.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
    source_fps = float(capture.get(cv2.CAP_PROP_FPS) or 0.0)
    source_fps = source_fps if source_fps > 0 else 25.0
    total_frames = int(capture.get(cv2.CAP_PROP_FRAME_COUNT) or 0)

    job_dir = settings.output_dir / options.job_id
    job_dir.mkdir(parents=True, exist_ok=True)
    preview_path = job_dir / "preview.jpg"
    output_video_path = job_dir / f"{Path(options.source_name).stem}_tracked.mp4"
    report_csv_path = settings.report_dir / f"{options.job_id}_tracks.csv"
    report_json_path = settings.report_dir / f"{options.job_id}_summary.json"

    writer = _create_writer(output_video_path, source_fps, width, height) if options.save_video else None
    detector = Detector(model)
    tracker = ByteTrackAdapter(frame_rate=source_fps, confidence=options.confidence)
    id_reconciler = StableIdReconciler(frame_rate=source_fps)
    trails: dict[int, deque[tuple[int, int]]] = defaultdict(lambda: deque(maxlen=45))
    unique_ids: set[int] = set()
    csv_rows: list[dict[str, object]] = []
    confidence_floor = min(0.05, options.confidence)
    all_tiles = generate_tiles(width, height, tile_size=768, overlap=0.20)

    frame_index = 0
    previous_full_count = 0
    started = time.perf_counter()
    inference_total_ms = 0.0

    progress_callback(
        {
            "frame_width": width,
            "frame_height": height,
            "inference_device": detector.device_label,
        }
    )

    try:
        while True:
            if cancel_event.is_set():
                raise PipelineCancelled("Job cancelled by user.")

            ok, frame = capture.read()
            if not ok:
                break
            frame_index += 1

            full = detector.infer(frame, imgsz=1280, confidence=confidence_floor)
            inference_ms = full.inference_ms
            detection_sources = [full.boxes]
            selected_tiles = []

            if options.profile == "accuracy":
                selected_tiles = all_tiles
            elif options.profile == "balanced":
                count_drop = previous_full_count > 0 and len(full.boxes) < previous_full_count * 0.65
                refresh = frame_index == 1 or frame_index % 5 == 0 or count_drop
                if refresh:
                    selected_tiles = select_balanced_tiles(
                        all_tiles,
                        full.boxes,
                        width,
                        height,
                        frame_index,
                        max_tiles=2,
                    )

            if selected_tiles:
                tiled, tiled_ms = _tile_detections(
                    detector,
                    frame,
                    selected_tiles,
                    confidence_floor,
                )
                detection_sources.extend(tiled)
                inference_ms += tiled_ms

            fused = nms_fusion(detection_sources, iou_threshold=0.55)
            raw_tracks = tracker.update(fused, frame)
            tracks = id_reconciler.update(raw_tracks, frame_index, frame.shape)
            selected_ids, dim_others = focus_getter()
            annotated, visible_tracks = _draw_tracks(
                frame.copy(),
                tracks,
                trails,
                options,
                selected_ids,
                dim_others,
            )

            for track in visible_tracks:
                unique_ids.add(track.track_id)
                csv_rows.append(
                    {
                        "frame": frame_index,
                        "timestamp_seconds": round(frame_index / source_fps, 4),
                        "track_id": track.track_id,
                        "x1": round(track.x1, 2),
                        "y1": round(track.y1, 2),
                        "x2": round(track.x2, 2),
                        "y2": round(track.y2, 2),
                        "confidence": round(track.confidence, 5),
                        "selected": track.track_id in selected_ids,
                    }
                )

            if writer is not None:
                writer.write(annotated)

            elapsed = time.perf_counter() - started
            current_fps = frame_index / max(elapsed, 1e-6)
            inference_total_ms += inference_ms
            mean_confidence = (
                float(np.mean([track.confidence for track in visible_tracks]))
                if visible_tracks
                else 0.0
            )
            previous_full_count = len(full.boxes)

            should_publish = (
                frame_index == 1
                or frame_index % settings.telemetry_interval_frames == 0
                or (total_frames > 0 and frame_index >= total_frames)
            )
            if should_publish:
                # Keep the displayed JPEG and the clickable box metadata on the
                # same frame to make subject selection spatially accurate.
                _write_preview(annotated, preview_path)
                progress_callback(
                    {
                        "frame": frame_index,
                        "total_frames": total_frames,
                        "frame_width": width,
                        "frame_height": height,
                        "progress": round(frame_index / total_frames * 100.0, 2)
                        if total_frames > 0
                        else 0.0,
                        "fps": round(current_fps, 2),
                        "inference_ms": round(inference_ms, 2),
                        "inference_device": detector.device_label,
                        "elapsed_seconds": round(elapsed, 2),
                        "active_tracks": len(visible_tracks),
                        "active_track_ids": sorted(track.track_id for track in visible_tracks),
                        "active_track_boxes": _track_boxes(visible_tracks, selected_ids),
                        "selected_track_ids": sorted(selected_ids),
                        "focus_dim_others": dim_others,
                        "unique_tracks": len(unique_ids),
                        "mean_confidence": round(mean_confidence, 4),
                        "tiling_active": bool(selected_tiles),
                        "processed_tiles": len(selected_tiles),
                        "preview_available": preview_path.exists(),
                    }
                )
    finally:
        capture.release()
        if writer is not None:
            writer.release()

    elapsed_seconds = time.perf_counter() - started
    average_fps = frame_index / max(elapsed_seconds, 1e-6)

    if options.save_csv:
        report_csv_path.parent.mkdir(parents=True, exist_ok=True)
        with report_csv_path.open("w", newline="", encoding="utf-8-sig") as file:
            fieldnames = [
                "frame",
                "timestamp_seconds",
                "track_id",
                "x1",
                "y1",
                "x2",
                "y2",
                "confidence",
                "selected",
            ]
            writer_csv = csv.DictWriter(file, fieldnames=fieldnames)
            writer_csv.writeheader()
            writer_csv.writerows(csv_rows)

    summary = {
        "job_id": options.job_id,
        "source_name": options.source_name,
        "profile": options.profile,
        "confidence": options.confidence,
        "total_frames": frame_index,
        "source_fps": source_fps,
        "resolution": {"width": width, "height": height},
        "inference_device": detector.device_label,
        "elapsed_seconds": round(elapsed_seconds, 3),
        "average_fps": round(average_fps, 3),
        "average_inference_ms": round(inference_total_ms / max(frame_index, 1), 3),
        "unique_tracks": len(unique_ids),
        "tracking_stabilization": "byte-track-plus-stable-id-v1",
        "focus_selection_supported": True,
        "detections_written": len(csv_rows),
        "output_video": str(output_video_path.resolve()) if options.save_video else None,
    }
    if options.save_json:
        report_json_path.parent.mkdir(parents=True, exist_ok=True)
        report_json_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

    selected_ids, dim_others = focus_getter()
    progress_callback(
        {
            "frame": frame_index,
            "total_frames": frame_index if total_frames <= 0 else total_frames,
            "frame_width": width,
            "frame_height": height,
            "progress": 100.0,
            "fps": round(average_fps, 2),
            "inference_ms": round(inference_total_ms / max(frame_index, 1), 2),
            "inference_device": detector.device_label,
            "elapsed_seconds": round(elapsed_seconds, 2),
            "active_tracks": 0,
            "active_track_ids": [],
            "active_track_boxes": [],
            "selected_track_ids": sorted(selected_ids),
            "focus_dim_others": dim_others,
            "unique_tracks": len(unique_ids),
            "tiling_active": False,
            "processed_tiles": 0,
            "preview_available": preview_path.exists(),
        }
    )

    return PipelineResult(
        output_video_path=str(output_video_path.resolve()) if options.save_video else None,
        report_csv_path=str(report_csv_path.resolve()) if options.save_csv else None,
        report_json_path=str(report_json_path.resolve()) if options.save_json else None,
        total_frames=frame_index,
        elapsed_seconds=elapsed_seconds,
        average_fps=average_fps,
        unique_tracks=len(unique_ids),
    )
