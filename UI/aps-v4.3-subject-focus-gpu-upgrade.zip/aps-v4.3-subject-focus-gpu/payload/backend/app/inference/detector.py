from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np

from app.core.config import settings


@dataclass(slots=True)
class DetectionBatch:
    boxes: np.ndarray  # shape (N, 6): x1, y1, x2, y2, confidence, class_id
    inference_ms: float


class Detector:
    def __init__(self, model: Any) -> None:
        self.model = model
        self._device = self._resolve_device()
        self._device_label = self._resolve_device_label()

    @staticmethod
    def _resolve_device() -> str | int:
        try:
            import torch

            requested = str(settings.device).strip().lower()
            if requested in {"cpu", "-1"} or not torch.cuda.is_available():
                return "cpu"
            if requested.startswith("cuda:"):
                requested = requested.split(":", 1)[1]
            return int(requested) if requested.isdigit() else requested
        except Exception:
            return "cpu"

    def _resolve_device_label(self) -> str:
        if self._device == "cpu":
            return "CPU"
        try:
            import torch

            index = int(self._device) if isinstance(self._device, int) or str(self._device).isdigit() else 0
            return f"CUDA:{index} · {torch.cuda.get_device_name(index)}"
        except Exception:
            return f"CUDA:{self._device}"

    @property
    def device(self) -> str | int:
        return self._device

    @property
    def device_label(self) -> str:
        return self._device_label

    @property
    def uses_cuda(self) -> bool:
        return self._device != "cpu"

    def infer(self, frame: np.ndarray, imgsz: int, confidence: float) -> DetectionBatch:
        results = self.model.predict(
            source=frame,
            imgsz=imgsz,
            conf=confidence,
            iou=0.70,
            max_det=1000,
            classes=[0],
            single_cls=True,
            device=self._device,
            half=bool(settings.half and self.uses_cuda),
            verbose=False,
        )
        result = results[0]
        inference_ms = float((result.speed or {}).get("inference", 0.0))
        if result.boxes is None or len(result.boxes) == 0:
            return DetectionBatch(np.empty((0, 6), dtype=np.float32), inference_ms)

        xyxy = result.boxes.xyxy.detach().cpu().numpy().astype(np.float32)
        conf = result.boxes.conf.detach().cpu().numpy().astype(np.float32)[:, None]
        cls = result.boxes.cls.detach().cpu().numpy().astype(np.float32)[:, None]
        return DetectionBatch(np.concatenate([xyxy, conf, cls], axis=1), inference_ms)
