from __future__ import annotations

import importlib.util
import platform
import shutil

import psutil

from app.core.config import settings
from app.schemas.system import SystemStatus
from app.services.model_manager import model_manager


def _gpu_info() -> tuple[str | None, float | None, float | None, float | None]:
    try:
        import pynvml

        pynvml.nvmlInit()
        handle = pynvml.nvmlDeviceGetHandleByIndex(0)
        name = pynvml.nvmlDeviceGetName(handle)
        if isinstance(name, bytes):
            name = name.decode("utf-8")
        util = pynvml.nvmlDeviceGetUtilizationRates(handle)
        memory = pynvml.nvmlDeviceGetMemoryInfo(handle)
        return str(name), float(util.gpu), memory.used / 1024**2, memory.total / 1024**2
    except Exception:
        return None, None, None, None


def _torch_info() -> tuple[bool, str, str | None, str | None, str | None]:
    try:
        import torch

        cuda_available = bool(torch.cuda.is_available())
        torch_version = str(torch.__version__)
        torch_cuda_version = str(torch.version.cuda) if torch.version.cuda else None
        if cuda_available:
            device_name = torch.cuda.get_device_name(0)
            return True, f"CUDA:0 · {device_name}", torch_version, torch_cuda_version, None
        return (
            False,
            "CPU",
            torch_version,
            torch_cuda_version,
            "NVIDIA GPU may be detected, but the installed PyTorch runtime cannot use CUDA.",
        )
    except Exception as exc:
        return False, "CPU", None, None, f"PyTorch runtime check failed: {type(exc).__name__}"


def get_system_status() -> SystemStatus:
    gpu_name, gpu_usage, vram_used, vram_total = _gpu_info()
    cuda_available, inference_device, torch_version, torch_cuda_version, compute_warning = _torch_info()
    model_status = model_manager.status()
    selected = model_status.selected_model

    # TensorRT engines are GPU-only. For other formats, report the actual runtime
    # capability of the installed Python environment rather than merely the
    # presence of an NVIDIA adapter.
    if selected and selected.format in {"engine", "plan"}:
        inference_device = f"TensorRT GPU · {gpu_name or 'NVIDIA GPU'}"
        compute_warning = None if gpu_name else "TensorRT model selected, but no NVIDIA GPU was detected."
    elif gpu_name is None and not cuda_available:
        compute_warning = None

    cv_ready = importlib.util.find_spec("cv2") is not None
    ultralytics_ready = importlib.util.find_spec("ultralytics") is not None
    free_space = shutil.disk_usage(settings.output_dir).free / 1024**3

    return SystemStatus(
        platform=f"{platform.system()} {platform.release()}",
        cpu_percent=psutil.cpu_percent(interval=None),
        memory_percent=psutil.virtual_memory().percent,
        gpu_name=gpu_name,
        gpu_detected=gpu_name is not None,
        gpu_usage_percent=gpu_usage,
        vram_used_mb=round(vram_used, 1) if vram_used is not None else None,
        vram_total_mb=round(vram_total, 1) if vram_total is not None else None,
        cuda_available=cuda_available,
        inference_device=inference_device,
        torch_version=torch_version,
        torch_cuda_version=torch_cuda_version,
        compute_warning=compute_warning,
        model_available=model_status.available,
        model_loaded=model_status.loaded,
        model_name=selected.name if selected else None,
        model_error=model_status.error,
        inference_backend=model_status.backend if model_status.available else (
            "Mock" if settings.mock_mode else "Unavailable"
        ),
        storage_free_gb=round(free_space, 2),
        ai_dependencies_ready=ultralytics_ready and cv_ready,
        video_engine_ready=cv_ready,
        tracking_ready=ultralytics_ready,
    )
