from __future__ import annotations

import asyncio
import math
import random
import threading
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

from app.core.config import settings
from app.inference.pipeline import PipelineCancelled, PipelineOptions, process_video
from app.schemas.job import CreateJobRequest, FocusUpdateRequest, JobState
from app.services.model_manager import model_manager


class FocusControl:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._track_ids: set[int] = set()
        self._dim_others = True

    def update(self, track_ids: list[int], dim_others: bool) -> tuple[set[int], bool]:
        sanitized = {int(track_id) for track_id in track_ids if int(track_id) >= 0}
        with self._lock:
            self._track_ids = sanitized
            self._dim_others = bool(dim_others)
            return set(self._track_ids), self._dim_others

    def snapshot(self) -> tuple[set[int], bool]:
        with self._lock:
            return set(self._track_ids), self._dim_others


class JobManager:
    def __init__(self) -> None:
        self._jobs: dict[str, JobState] = {}
        self._tasks: dict[str, asyncio.Task[None]] = {}
        self._cancel_events: dict[str, threading.Event] = {}
        self._focus_controls: dict[str, FocusControl] = {}
        self._subscribers: dict[str, set[asyncio.Queue[JobState]]] = defaultdict(set)
        self._gpu_lock = asyncio.Lock()

    async def start(self) -> None:
        return None

    async def shutdown(self) -> None:
        for event in self._cancel_events.values():
            event.set()
        for task in self._tasks.values():
            task.cancel()
        await asyncio.gather(*self._tasks.values(), return_exceptions=True)

    def list_jobs(self) -> list[JobState]:
        return sorted(self._jobs.values(), key=lambda item: item.created_at, reverse=True)

    def get_job(self, job_id: str) -> JobState | None:
        return self._jobs.get(job_id)

    def get_job_artifact(self, job_id: str, kind: str) -> Path | None:
        job = self._jobs.get(job_id)
        if not job:
            return None
        mapping = {
            "output": job.output_video_path,
            "csv": job.report_csv_path,
            "json": job.report_json_path,
            "preview": str(settings.output_dir / job_id / "preview.jpg"),
        }
        value = mapping.get(kind)
        if not value:
            return None
        path = Path(value)
        return path if path.exists() else None

    async def create_job(self, payload: CreateJobRequest) -> JobState:
        source_path = Path(payload.source_path)
        if payload.source_type == "video" and not source_path.exists():
            raise FileNotFoundError(f"Uploaded video was not found: {source_path}")

        job = JobState(
            source_type=payload.source_type,
            source_path=str(source_path),
            source_name=payload.source_name or source_path.name,
            profile=payload.profile,
            confidence=payload.confidence,
        )
        self._jobs[job.id] = job
        cancel_event = threading.Event()
        self._cancel_events[job.id] = cancel_event
        self._focus_controls[job.id] = FocusControl()

        if settings.mock_mode or payload.source_type == "mock":
            task = asyncio.create_task(self._run_mock_job(job.id))
        else:
            if not model_manager.status().available:
                del self._jobs[job.id]
                self._cancel_events.pop(job.id, None)
                self._focus_controls.pop(job.id, None)
                raise FileNotFoundError(
                    f"No model was found in {settings.model_dir}. Place the trained model in that folder."
                )
            task = asyncio.create_task(self._run_real_job(job.id, payload, cancel_event))
        self._tasks[job.id] = task
        return job

    async def update_focus(self, job_id: str, payload: FocusUpdateRequest) -> JobState | None:
        job = self._jobs.get(job_id)
        control = self._focus_controls.get(job_id)
        if not job or not control:
            return None
        selected, dim_others = control.update(payload.track_ids, payload.dim_others)
        job.selected_track_ids = sorted(selected)
        job.focus_dim_others = dim_others
        job.updated_at = datetime.now(timezone.utc)
        await self._publish(job)
        return job

    async def cancel_job(self, job_id: str) -> JobState | None:
        job = self._jobs.get(job_id)
        if not job:
            return None
        job.status = "cancelled"
        job.updated_at = datetime.now(timezone.utc)
        event = self._cancel_events.get(job_id)
        if event:
            event.set()
        task = self._tasks.get(job_id)
        if task and settings.mock_mode:
            task.cancel()
        await self._publish(job)
        return job

    def subscribe(self, job_id: str) -> asyncio.Queue[JobState]:
        queue: asyncio.Queue[JobState] = asyncio.Queue(maxsize=4)
        self._subscribers[job_id].add(queue)
        return queue

    def unsubscribe(self, job_id: str, queue: asyncio.Queue[JobState]) -> None:
        self._subscribers[job_id].discard(queue)

    async def _publish(self, job: JobState) -> None:
        for queue in tuple(self._subscribers.get(job.id, set())):
            if queue.full():
                try:
                    queue.get_nowait()
                except asyncio.QueueEmpty:
                    pass
            await queue.put(job.model_copy(deep=True))

    async def _apply_progress(self, job_id: str, values: dict[str, object]) -> None:
        job = self._jobs.get(job_id)
        if not job or job.status in {"cancelled", "failed"}:
            return
        for key, value in values.items():
            if hasattr(job, key):
                setattr(job, key, value)
        job.updated_at = datetime.now(timezone.utc)
        await self._publish(job)

    async def _run_real_job(
        self,
        job_id: str,
        payload: CreateJobRequest,
        cancel_event: threading.Event,
    ) -> None:
        job = self._jobs[job_id]
        loop = asyncio.get_running_loop()
        focus_control = self._focus_controls[job_id]

        def progress_callback(values: dict[str, object]) -> None:
            asyncio.run_coroutine_threadsafe(
                self._apply_progress(job_id, values),
                loop,
            )

        try:
            # Only one real job may own the local accelerator at a time. Additional
            # jobs remain queued and begin automatically when the previous job finishes.
            async with self._gpu_lock:
                if cancel_event.is_set() or job.status == "cancelled":
                    return
                job.status = "running"
                job.updated_at = datetime.now(timezone.utc)
                await self._publish(job)

                model = await asyncio.to_thread(model_manager.ensure_loaded, payload.model_id)
                status = model_manager.status()
                selected = status.selected_model
                job.model_name = selected.name if selected else None
                await self._publish(job)

                options = PipelineOptions(
                    job_id=job_id,
                    source_path=Path(payload.source_path),
                    source_name=payload.source_name or Path(payload.source_path).name,
                    profile=payload.profile,
                    confidence=payload.confidence,
                    show_trails=payload.show_trails,
                    show_track_ids=payload.show_track_ids,
                    show_confidence=payload.show_confidence,
                    save_video=payload.save_video,
                    save_csv=payload.save_csv,
                    save_json=payload.save_json,
                )
                result = await asyncio.to_thread(
                    process_video,
                    model,
                    options,
                    progress_callback,
                    cancel_event,
                    focus_control.snapshot,
                )
                if cancel_event.is_set() or job.status == "cancelled":
                    job.status = "cancelled"
                else:
                    job.status = "completed"
                    job.progress = 100.0
                    job.total_frames = result.total_frames
                    job.elapsed_seconds = round(result.elapsed_seconds, 2)
                    job.fps = round(result.average_fps, 2)
                    job.unique_tracks = result.unique_tracks
                    job.output_video_path = result.output_video_path
                    job.report_csv_path = result.report_csv_path
                    job.report_json_path = result.report_json_path
        except PipelineCancelled:
            job.status = "cancelled"
        except asyncio.CancelledError:
            cancel_event.set()
            job.status = "cancelled"
        except Exception as exc:
            job.status = "failed"
            job.error = f"{type(exc).__name__}: {exc}"
        finally:
            job.updated_at = datetime.now(timezone.utc)
            await self._publish(job)

    async def _run_mock_job(self, job_id: str) -> None:
        job = self._jobs[job_id]
        job.status = "running"
        job.total_frames = 900
        job.frame_width = 1280
        job.frame_height = 720
        job.inference_device = "Mock"
        total = job.total_frames
        try:
            for frame in range(total + 1):
                if job.status == "cancelled":
                    break
                selected, dim_others = self._focus_controls[job_id].snapshot()
                active_ids = list(range(1, max(2, int(9 + math.sin(frame / 30) * 5))))
                job.frame = frame
                job.progress = round(frame / total * 100, 2)
                base_fps = {"fast": 25.0, "balanced": 16.5, "accuracy": 7.0}.get(
                    job.profile, 15.0
                )
                job.fps = round(
                    base_fps + math.sin(frame / 22) * 1.6 + random.uniform(-0.5, 0.5),
                    1,
                )
                job.active_tracks = len(active_ids)
                job.active_track_ids = active_ids
                job.active_track_boxes = []
                job.selected_track_ids = sorted(selected)
                job.focus_dim_others = dim_others
                job.unique_tracks = max(job.unique_tracks, int(frame / 25) + job.active_tracks)
                job.mean_confidence = round(0.68 + math.sin(frame / 40) * 0.07, 3)
                job.tiling_active = job.profile != "fast" and (
                    job.profile == "accuracy" or frame % 6 == 0
                )
                job.processed_tiles = 2 if job.tiling_active and job.profile == "balanced" else (
                    6 if job.tiling_active else 0
                )
                job.updated_at = datetime.now(timezone.utc)
                await self._publish(job)
                await asyncio.sleep(0.08)
            if job.status != "cancelled":
                job.status = "completed"
                job.progress = 100.0
                await self._publish(job)
        except asyncio.CancelledError:
            return


job_manager = JobManager()
