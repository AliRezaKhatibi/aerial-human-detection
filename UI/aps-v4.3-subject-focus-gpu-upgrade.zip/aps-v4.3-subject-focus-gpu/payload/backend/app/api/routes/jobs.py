from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse

from app.schemas.job import CreateJobRequest, FocusUpdateRequest, JobState
from app.services.job_manager import job_manager

router = APIRouter()


@router.get("", response_model=list[JobState])
async def list_jobs() -> list[JobState]:
    return job_manager.list_jobs()


@router.post("", response_model=JobState, status_code=201)
async def create_job(payload: CreateJobRequest) -> JobState:
    try:
        return await job_manager.create_job(payload)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.get("/{job_id}", response_model=JobState)
async def get_job(job_id: str) -> JobState:
    job = job_manager.get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


@router.post("/{job_id}/focus", response_model=JobState)
async def update_job_focus(job_id: str, payload: FocusUpdateRequest) -> JobState:
    job = await job_manager.update_focus(job_id, payload)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


@router.post("/{job_id}/cancel", response_model=JobState)
async def cancel_job(job_id: str) -> JobState:
    job = await job_manager.cancel_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


def _artifact(job_id: str, kind: str, media_type: str | None = None) -> FileResponse:
    path = job_manager.get_job_artifact(job_id, kind)
    if not path:
        raise HTTPException(status_code=404, detail=f"{kind} artifact is not available")
    return FileResponse(path, filename=path.name, media_type=media_type)


@router.get("/{job_id}/preview")
async def job_preview(job_id: str) -> FileResponse:
    response = _artifact(job_id, "preview", "image/jpeg")
    response.headers["Cache-Control"] = "no-store, max-age=0"
    return response


@router.get("/{job_id}/output")
async def job_output(job_id: str) -> FileResponse:
    return _artifact(job_id, "output", "video/mp4")


@router.get("/{job_id}/report.csv")
async def job_csv(job_id: str) -> FileResponse:
    return _artifact(job_id, "csv", "text/csv")


@router.get("/{job_id}/report.json")
async def job_json(job_id: str) -> FileResponse:
    return _artifact(job_id, "json", "application/json")
