import { useQuery } from "@tanstack/react-query";
import { AlertTriangle, CheckCircle2, Cpu, HardDrive, MemoryStick, MonitorCog, RefreshCw, XCircle, type LucideIcon } from "lucide-react";
import { Card, CardHeader } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { ProgressBar } from "@/components/ui/ProgressBar";
import { PageHeader } from "@/components/PageHeader";
import { api } from "@/lib/api";
import { useI18n } from "@/hooks/use-i18n";

interface SystemItem { label: string; value: string; icon: LucideIcon; percent?: number; state?: "green" | "amber" | "red"; badge?: string; }

export function SystemPage() {
  const { t } = useI18n();
  const query = useQuery({ queryKey: ["system-page"], queryFn: api.system, refetchInterval: 3000, retry: 1 });
  const data = query.data;
  const vramPercent = data?.vram_total_mb ? ((data.vram_used_mb ?? 0) / data.vram_total_mb) * 100 : 0;
  const accelerated = Boolean(data?.cuda_available || /TensorRT|GPU/i.test(data?.inference_device ?? ""));
  const items: SystemItem[] = [
    {
      label: t("system.gpuDetected"),
      value: data?.gpu_name ?? t("common.unavailable"),
      icon: Cpu,
      percent: data?.gpu_usage_percent ?? 0,
      state: data?.gpu_detected ? "green" : "red",
      badge: data?.gpu_detected ? t("dashboard.gpuDetected") : t("common.unavailable"),
    },
    {
      label: t("system.inferenceDevice"),
      value: data?.inference_device ?? "—",
      icon: MonitorCog,
      state: accelerated ? "green" : "amber",
      badge: accelerated ? t("dashboard.inferenceOnGpu") : t("dashboard.inferenceOnCpu"),
    },
    { label: "VRAM", value: data?.vram_total_mb ? `${Math.round(data.vram_used_mb ?? 0)} / ${Math.round(data.vram_total_mb)} MB` : t("common.unavailable"), icon: MemoryStick, percent: vramPercent, state: data?.gpu_detected ? "green" : "red", badge: data?.gpu_detected ? t("common.online") : t("common.offline") },
    { label: "CPU / RAM", value: `${Math.round(data?.cpu_percent ?? 0)}% / ${Math.round(data?.memory_percent ?? 0)}%`, icon: HardDrive, percent: data?.cpu_percent ?? 0, state: query.isSuccess ? "green" : "red", badge: query.isSuccess ? t("common.online") : t("common.offline") },
  ];
  const dependencies = [
    { name: "FastAPI", ready: query.isSuccess, detail: t("system.backendApi") },
    { name: "WebSocket", ready: query.isSuccess, detail: t("system.liveTelemetry") },
    { name: t("common.model"), ready: Boolean(data?.model_available), detail: data?.model_name ?? t("system.modelNotFound") },
    { name: "CUDA / PyTorch", ready: Boolean(data?.cuda_available), detail: data?.cuda_available ? t("system.cudaReady") : t("system.cudaUnavailable") },
    { name: "OpenCV", ready: Boolean(data?.video_engine_ready), detail: data?.video_engine_ready ? t("system.videoReady") : t("system.runInstall") },
    { name: "ByteTrack", ready: Boolean(data?.tracking_ready), detail: data?.tracking_ready ? t("system.trackerReady") : t("system.runInstall") },
  ];

  return (
    <div className="space-y-6">
      <PageHeader eyebrow={t("system.eyebrow")} title={t("system.title")} description={t("system.description")} actions={<Button variant="secondary" onClick={() => void query.refetch()} loading={query.isFetching}><RefreshCw size={15}/> {t("common.refresh")}</Button>} />

      {data?.gpu_detected && !data.cuda_available && (
        <div className="flex items-start gap-3 rounded-2xl border border-[#f6bd58]/25 bg-[#f6bd58]/8 p-4 text-xs leading-6 text-[#f6d38b]" role="status">
          <AlertTriangle size={19} className="mt-0.5 shrink-0" />
          <div><div className="font-black">{t("system.computeWarning")}</div><div className="mt-1" dir="auto">{data.compute_warning ?? t("system.cudaUnavailable")}</div></div>
        </div>
      )}

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {items.map(({ label, value, icon: Icon, percent, state = "green", badge }) => (
          <Card key={label} className="p-5">
            <div className="flex items-center justify-between"><div className="grid h-10 w-10 place-items-center rounded-xl bg-[#33d3bb]/8"><Icon className="text-[#33d3bb]" size={20}/></div><Badge tone={state} dot>{badge}</Badge></div>
            <div className="mt-6 text-xs text-[var(--muted)]">{label}</div><div className="mt-2 truncate text-lg font-black" dir="auto">{value}</div>{typeof percent === "number" && <ProgressBar value={percent} className="mt-4 h-1.5"/>}
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-[1.2fr_1fr]">
        <Card><CardHeader title={t("system.dependencyCheck")} description={t("system.dependencyDescription")}/><div className="grid grid-cols-1 gap-3 p-5 sm:grid-cols-2">{dependencies.map((item) => <div key={item.name} className="flex items-center justify-between rounded-xl border border-[var(--border)] bg-white/[.025] p-4"><div><div className="text-xs font-bold">{item.name}</div><div className="mt-1 text-[10px] text-[var(--muted-2)]" dir="auto">{item.detail}</div></div>{item.ready ? <CheckCircle2 size={20} className="text-[#49d6a5]"/> : <XCircle size={20} className="text-[#f6bd58]"/>}</div>)}</div></Card>
        <Card><CardHeader title={t("system.runtimeInfo")}/><div className="space-y-4 p-5">{[
          [t("system.platform"), data?.platform ?? "—"],
          [t("system.inferenceBackend"), data?.inference_backend ?? "—"],
          [t("system.inferenceDevice"), data?.inference_device ?? "—"],
          [t("system.cudaStatus"), data?.cuda_available ? t("system.cudaReady") : t("system.cudaUnavailable")],
          [t("system.torchVersion"), data?.torch_version ?? "—"],
          [t("system.torchCuda"), data?.torch_cuda_version ?? "—"],
          [t("common.model"), data?.model_name ?? t("system.modelNotFound")],
          [t("system.modelLoaded"), data?.model_loaded ? t("common.yes") : t("common.no")],
          [t("system.storageFree"), `${(data?.storage_free_gb ?? 0).toFixed(1)} GB`],
          [t("system.apiEndpoint"), "127.0.0.1:8000"],
          [t("system.frontend"), "127.0.0.1:1420"],
        ].map(([label,value])=><div key={label} className="flex items-center justify-between gap-4 border-b border-[var(--border)] pb-3 text-xs last:border-0"><span className="text-[var(--muted)]">{label}</span><span className="max-w-[60%] truncate font-bold" dir="auto">{value}</span></div>)}</div></Card>
      </div>
    </div>
  );
}
