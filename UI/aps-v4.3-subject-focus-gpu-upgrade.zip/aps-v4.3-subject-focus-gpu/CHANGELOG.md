# v4.3

- Added live multi-subject Track ID selection.
- Added clickable bounding-box overlay synchronized with preview frames.
- Added server-side red focus boxes and optional scene/track dimming.
- Added persistent focus state through short track disappearances.
- Added focus API: POST /api/v1/jobs/{job_id}/focus.
- Added active track IDs and boxes to WebSocket job telemetry.
- Added per-job actual inference device telemetry.
- Split NVIDIA adapter detection from CUDA/PyTorch inference availability.
- Corrected Dashboard and System GPU wording.
- Added verify-compute.ps1 and optional install-torch-cuda.ps1.
- Fixed install-ai.ps1 native PowerShell/Python quoting.
- Made setup.ps1 fail when backend tests fail.
