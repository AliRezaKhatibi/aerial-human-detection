ارتقای رابط کاربری از v2 به v3

1) فایل ZIP را Extract کنید.
2) PowerShell را داخل پوشه Extract شده باز کنید.
3) اجرا کنید:

Set-ExecutionPolicy -Scope Process Bypass
.\apply-upgrade.ps1

مسیر پیش‌فرض پروژه:
D:\A_Senior - Data Science\Projects\UI\aerial-person-studio-v2

برای مسیر متفاوت:
.\apply-upgrade.ps1 -ProjectPath "D:\path\to\project"

اسکریپت ابتدا از frontend/src نسخه پشتیبان می‌گیرد، سپس فایل‌های جدید را کپی و Build می‌کند.
