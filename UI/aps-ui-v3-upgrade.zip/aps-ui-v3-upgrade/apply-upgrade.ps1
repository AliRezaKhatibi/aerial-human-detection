param(
    [string]$ProjectPath = "D:\A_Senior - Data Science\Projects\UI\aerial-person-studio-v2"
)

$ErrorActionPreference = "Stop"
$upgradeRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$payload = Join-Path $upgradeRoot "payload\frontend"
$frontend = Join-Path $ProjectPath "frontend"

if (-not (Test-Path $frontend)) {
    throw "Frontend folder not found: $frontend"
}

$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backup = Join-Path $ProjectPath "frontend-src-backup-$timestamp"
Write-Host "Backing up current frontend/src to: $backup" -ForegroundColor Cyan
Copy-Item (Join-Path $frontend "src") $backup -Recurse -Force

Write-Host "Applying UI v3 files..." -ForegroundColor Cyan
Copy-Item (Join-Path $payload "src") $frontend -Recurse -Force
foreach ($file in @("package.json", "vite.config.ts", "tailwind.config.ts", "postcss.config.cjs", "tsconfig.json", "tsconfig.app.json", "tsconfig.node.json", "index.html")) {
    Copy-Item (Join-Path $payload $file) (Join-Path $frontend $file) -Force
}

Write-Host "Building frontend..." -ForegroundColor Cyan
Push-Location $ProjectPath
try {
    npm --prefix frontend run build
    if ($LASTEXITCODE -ne 0) { throw "Frontend build failed" }
}
finally {
    Pop-Location
}

Write-Host "UI v3 upgrade completed successfully." -ForegroundColor Green
Write-Host "Run: .\scripts\backend-dev.ps1 and .\scripts\frontend-dev.ps1"
