import { lazy, Suspense, useEffect } from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import { AppShell } from "@/components/layout/AppShell";
import { PageLoader } from "@/components/feedback/PageLoader";
import { useAppStore } from "@/stores/app-store";

const DashboardPage = lazy(() => import("@/pages/DashboardPage").then((m) => ({ default: m.DashboardPage })));
const NewAnalysisPage = lazy(() => import("@/pages/NewAnalysisPage").then((m) => ({ default: m.NewAnalysisPage })));
const ProcessingPage = lazy(() => import("@/pages/ProcessingPage").then((m) => ({ default: m.ProcessingPage })));
const ResultsPage = lazy(() => import("@/pages/ResultsPage").then((m) => ({ default: m.ResultsPage })));
const ProfilesPage = lazy(() => import("@/pages/ProfilesPage").then((m) => ({ default: m.ProfilesPage })));
const SettingsPage = lazy(() => import("@/pages/SettingsPage").then((m) => ({ default: m.SettingsPage })));
const SystemPage = lazy(() => import("@/pages/SystemPage").then((m) => ({ default: m.SystemPage })));

export default function App() {
  const locale = useAppStore((state) => state.locale);
  const theme = useAppStore((state) => state.theme);

  useEffect(() => {
    document.documentElement.dir = locale === "fa" ? "rtl" : "ltr";
    document.documentElement.lang = locale;
    document.documentElement.dataset.theme = theme;
    document.documentElement.classList.toggle("dark", theme === "dark");
  }, [locale, theme]);

  return (
    <Suspense fallback={<PageLoader />}>
      <Routes>
        <Route element={<AppShell />}>
          <Route path="/" element={<DashboardPage />} />
          <Route path="/analysis/new" element={<NewAnalysisPage />} />
          <Route path="/processing/:jobId?" element={<ProcessingPage />} />
          <Route path="/results" element={<ResultsPage />} />
          <Route path="/profiles" element={<ProfilesPage />} />
          <Route path="/settings" element={<SettingsPage />} />
          <Route path="/system" element={<SystemPage />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Suspense>
  );
}
