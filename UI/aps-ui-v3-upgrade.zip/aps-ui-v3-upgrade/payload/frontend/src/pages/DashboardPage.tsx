import { Activity, ArrowUpLeft, Clock3, Cpu, FileVideo2, Gauge, Play, RefreshCw, Users } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import ReactECharts from "echarts-for-react";
import { motion } from "framer-motion";
import { api } from "@/lib/api";
import { Button } from "@/components/ui/Button";
import { Card, CardHeader } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { StatCard } from "@/components/StatCard";
import { ProfileCard } from "@/components/ProfileCard";
import { ResourceMeter } from "@/components/dashboard/ResourceMeter";
import { useAppStore } from "@/stores/app-store";

const chartOption = {
  backgroundColor: "transparent",
  animationDuration: 700,
  grid: { left: 10, right: 14, top: 24, bottom: 12, containLabel: true },
  tooltip: { trigger: "axis", backgroundColor: "#101a29", borderColor: "rgba(255,255,255,.08)", textStyle: { color: "#fff" } },
  xAxis: { type: "category", boundaryGap: false, data: ["00", "04", "08", "12", "16", "20", "24"], axisLine: { lineStyle: { color: "rgba(255,255,255,.08)" } }, axisLabel: { color: "#6f8099", fontSize: 10 } },
  yAxis: { type: "value", min: 0, max: 30, splitLine: { lineStyle: { color: "rgba(255,255,255,.045)" } }, axisLabel: { color: "#6f8099", fontSize: 10 } },
  series: [{ name: "FPS", type: "line", smooth: true, symbol: "none", data: [14, 16, 15, 18, 17, 19, 18], lineStyle: { width: 3, color: "#33d3bb" }, areaStyle: { color: { type: "linear", x: 0, y: 0, x2: 0, y2: 1, colorStops: [{ offset: 0, color: "rgba(51,211,187,.28)" }, { offset: 1, color: "rgba(51,211,187,0)" }] } } }],
};

export function DashboardPage() {
  const selectedProfile = useAppStore((s) => s.selectedProfile);
  const setSelectedProfile = useAppStore((s) => s.setSelectedProfile);
  const systemQuery = useQuery({ queryKey: ["system"], queryFn: api.system, refetchInterval: 5000, retry: 1 });
  const jobsQuery = useQuery({ queryKey: ["jobs-dashboard"], queryFn: api.jobs, refetchInterval: 5000, retry: 1 });
  const system = systemQuery.data;
  const recentJobs = jobsQuery.data?.slice(0, 4) ?? [];
  const activeJobs = jobsQuery.data?.filter((job) => job.status === "running").length ?? 0;
  const completedJobs = jobsQuery.data?.filter((job) => job.status === "completed").length ?? 0;

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      <section className="glass metric-grid relative overflow-hidden rounded-3xl p-5 sm:p-6 lg:p-7">
        <div className="absolute -left-20 -top-24 h-64 w-64 rounded-full bg-[#7d8dff]/10 blur-3xl" />
        <div className="absolute -bottom-24 right-20 h-56 w-56 rounded-full bg-[#33d3bb]/8 blur-3xl" />
        <div className="relative flex flex-col justify-between gap-6 xl:flex-row xl:items-center">
          <div>
            <div className="mb-3 flex flex-wrap items-center gap-2">
              <Badge tone={systemQuery.isSuccess ? "green" : "red"} dot>{systemQuery.isSuccess ? "System Online" : "Backend Offline"}</Badge>
              <Badge tone={system?.model_loaded ? "green" : "amber"}>{system?.model_loaded ? "Model Ready" : "Mock Mode"}</Badge>
              {activeJobs > 0 && <Badge tone="blue">{activeJobs} Active Job</Badge>}
            </div>
            <h2 className="max-w-3xl text-xl font-black leading-[1.65] sm:text-2xl lg:text-[28px]">تشخیص، ردیابی و تحلیل هوشمند افراد در تصاویر و ویدئوهای هوایی</h2>
            <p className="mt-3 max-w-3xl text-xs leading-7 text-[var(--muted)] sm:text-sm">یک فضای کاری یکپارچه برای انتخاب پروفایل استنتاج، پایش GPU، مشاهده تله‌متری زنده و تولید خروجی‌های تحلیلی.</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="secondary" onClick={() => { void systemQuery.refetch(); void jobsQuery.refetch(); }}><RefreshCw size={16} /> تازه‌سازی</Button>
            <Link to="/analysis/new"><Button className="px-5 py-3"><Play size={17} fill="currentColor" /> شروع تحلیل جدید</Button></Link>
          </div>
        </div>
      </section>

      <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 2xl:grid-cols-4">
        <StatCard title="وضعیت GPU" value={system?.gpu_name ?? "Unavailable"} caption={`${Math.round(system?.gpu_usage_percent ?? 0)}% استفاده فعلی`} icon={<Cpu size={19} />} trend={system?.gpu_name ? "ONLINE" : undefined} />
        <StatCard title="سرعت هدف" value={selectedProfile === "fast" ? "17–28 FPS" : selectedProfile === "balanced" ? "10–18 FPS" : "4–9 FPS"} caption={`پروفایل ${selectedProfile}`} icon={<Gauge size={19} />} trend="Live" />
        <StatCard title="کارهای تکمیل‌شده" value={String(completedJobs)} caption="در نشست فعلی Backend" icon={<Users size={19} />} />
        <StatCard title="پردازش‌های فعال" value={String(activeJobs)} caption="صف محلی GPU" icon={<Clock3 size={19} />} />
      </section>

      <section className="grid grid-cols-1 gap-4 2xl:grid-cols-[1.55fr_1fr]">
        <Card>
          <CardHeader title={<span className="flex items-center gap-2"><Activity size={17} className="text-[#33d3bb]" /> عملکرد پردازش</span>} description="میانگین سرعت تخمینی در ۲۴ ساعت اخیر" action={<Badge tone="gray">24H</Badge>} />
          <div className="p-3"><ReactECharts option={chartOption} style={{ height: 280 }} /></div>
        </Card>
        <Card>
          <CardHeader title="سلامت موتور" description="وضعیت سرویس‌ها و مسیر استنتاج" action={<Badge tone={systemQuery.isSuccess ? "green" : "red"} dot>{systemQuery.isSuccess ? "Healthy" : "Offline"}</Badge>} />
          <div className="space-y-4 p-5">
            {[
              ["Inference backend", system?.inference_backend ?? "Unavailable"],
              ["Model", system?.model_loaded ? "YOLO26m-P2" : "Not loaded"],
              ["Tracking", "ByteTrack scaffold"],
              ["Video engine", "OpenCV / FFmpeg pending"],
              ["Platform", system?.platform ?? "—"],
            ].map(([label, value]) => <div key={label} className="flex items-center justify-between gap-4 border-b border-[var(--border)] pb-3 text-xs last:border-0 last:pb-0"><span className="text-[var(--muted)]">{label}</span><span className="max-w-[55%] truncate font-bold text-[var(--text)]">{value}</span></div>)}
          </div>
        </Card>
      </section>

      <section>
        <div className="mb-4 flex flex-col justify-between gap-3 sm:flex-row sm:items-end"><div><h3 className="text-base font-black">پروفایل‌های استنتاج</h3><p className="mt-1 text-xs text-[var(--muted-2)]">همان مدل، با سه راهبرد اجرا برای نیازهای متفاوت</p></div><Link to="/profiles" className="flex items-center gap-1 text-xs font-bold text-[#56dac7]">مدیریت پروفایل‌ها <ArrowUpLeft size={14} /></Link></div>
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3"><ProfileCard kind="fast" selected={selectedProfile === "fast"} onClick={() => setSelectedProfile("fast")} /><ProfileCard kind="balanced" selected={selectedProfile === "balanced"} onClick={() => setSelectedProfile("balanced")} /><ProfileCard kind="accuracy" selected={selectedProfile === "accuracy"} onClick={() => setSelectedProfile("accuracy")} /></div>
      </section>

      <section className="grid grid-cols-1 gap-4 2xl:grid-cols-[1.45fr_1fr]">
        <Card>
          <CardHeader title="پردازش‌های اخیر" description="آخرین Jobهای ثبت‌شده در Backend" action={<Link to="/results"><Button variant="ghost" className="px-2 py-1 text-xs">مشاهده همه</Button></Link>} />
          <div className="divide-y divide-[var(--border)] px-5">
            {recentJobs.length > 0 ? recentJobs.map((job) => (
              <div className="flex items-center justify-between gap-3 py-4" key={job.id}>
                <div className="flex min-w-0 items-center gap-3"><div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-white/[.045] text-[var(--muted)]"><FileVideo2 size={18}/></div><div className="min-w-0"><div className="truncate text-xs font-bold">{job.source_path || job.id}</div><div className="mt-1 text-[10px] text-[var(--muted-2)]">{job.profile} · {job.fps.toFixed(1)} FPS · {job.progress.toFixed(0)}%</div></div></div>
                <Badge tone={job.status === "completed" ? "green" : job.status === "running" ? "blue" : job.status === "failed" ? "red" : "gray"}>{job.status}</Badge>
              </div>
            )) : <div className="py-10 text-center text-xs text-[var(--muted)]">هنوز پردازشی ثبت نشده است.</div>}
          </div>
        </Card>
        <Card>
          <CardHeader title="مصرف منابع" description="به‌روزرسانی خودکار هر پنج ثانیه" />
          <div className="space-y-6 p-5">
            <ResourceMeter label="GPU" value={system?.gpu_usage_percent ?? 0} detail={system?.gpu_name ?? "—"} />
            <ResourceMeter label="VRAM" value={system?.vram_total_mb ? ((system.vram_used_mb ?? 0) / system.vram_total_mb) * 100 : 0} detail={system?.vram_total_mb ? `${Math.round(system.vram_used_mb ?? 0)} / ${Math.round(system.vram_total_mb)} MB` : "—"} />
            <ResourceMeter label="RAM" value={system?.memory_percent ?? 0} />
            <ResourceMeter label="CPU" value={system?.cpu_percent ?? 0} />
          </div>
        </Card>
      </section>
    </motion.div>
  );
}
