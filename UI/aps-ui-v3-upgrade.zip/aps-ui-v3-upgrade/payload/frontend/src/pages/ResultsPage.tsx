import { Download, Eye, FileBarChart, FileJson, FileVideo2, Search, SlidersHorizontal } from "lucide-react";
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Card, CardHeader } from "@/components/ui/Card";
import { PageHeader } from "@/components/PageHeader";
import { ProgressBar } from "@/components/ui/ProgressBar";
import { api } from "@/lib/api";

export function ResultsPage() {
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState("all");
  const jobsQuery = useQuery({ queryKey: ["jobs-results"], queryFn: api.jobs, refetchInterval: 4000, retry: 1 });
  const jobs = useMemo(() => (jobsQuery.data ?? []).filter((job) => {
    const matchesQuery = job.source_path.toLowerCase().includes(query.toLowerCase()) || job.id.includes(query);
    const matchesStatus = status === "all" || job.status === status;
    return matchesQuery && matchesStatus;
  }), [jobsQuery.data, query, status]);

  return (
    <div className="space-y-6">
      <PageHeader eyebrow="Archive" title="نتایج و گزارش‌ها" description="آرشیو Jobها، وضعیت پردازش و خروجی‌های تحلیلی در این صفحه نمایش داده می‌شود." actions={<Button variant="secondary" disabled><Download size={15}/> خروجی کامل</Button>} />

      <Card>
        <div className="flex flex-col justify-between gap-3 border-b border-[var(--border)] p-4 lg:flex-row lg:items-center">
          <div className="flex min-w-0 flex-1 items-center gap-2 rounded-xl border border-[var(--border)] bg-white/[.025] px-3 py-2.5"><Search size={16} className="text-[var(--muted-2)]"/><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="جست‌وجو بر اساس نام فایل یا Job ID..." className="min-w-0 flex-1 bg-transparent text-xs outline-none"/></div>
          <div className="flex gap-2"><label className="flex items-center gap-2 rounded-xl border border-[var(--border)] bg-white/[.025] px-3 py-2.5"><SlidersHorizontal size={15} className="text-[var(--muted-2)]"/><select value={status} onChange={(e) => setStatus(e.target.value)} className="bg-transparent text-xs outline-none"><option value="all">همه وضعیت‌ها</option><option value="running">در حال اجرا</option><option value="completed">تکمیل‌شده</option><option value="cancelled">لغوشده</option></select></label></div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[780px] text-right text-xs">
            <thead className="text-[10px] uppercase tracking-wide text-[var(--muted-2)]"><tr className="border-b border-[var(--border)]"><th className="px-5 py-4 font-semibold">منبع</th><th className="px-5 py-4 font-semibold">پروفایل</th><th className="px-5 py-4 font-semibold">وضعیت</th><th className="px-5 py-4 font-semibold">پیشرفت</th><th className="px-5 py-4 font-semibold">FPS</th><th className="px-5 py-4 font-semibold">Trackها</th><th className="px-5 py-4 font-semibold">عملیات</th></tr></thead>
            <tbody className="divide-y divide-[var(--border)]">
              {jobs.map((job) => <tr key={job.id} className="transition hover:bg-white/[.025]"><td className="px-5 py-4"><div className="flex items-center gap-3"><div className="grid h-9 w-9 place-items-center rounded-xl bg-white/[.045]"><FileVideo2 size={17}/></div><div><div className="max-w-[220px] truncate font-bold">{job.source_path}</div><div className="mt-1 max-w-[180px] truncate text-[10px] text-[var(--muted-2)]">{job.id}</div></div></div></td><td className="px-5 py-4"><Badge tone="blue">{job.profile}</Badge></td><td className="px-5 py-4"><Badge tone={job.status === "completed" ? "green" : job.status === "running" ? "blue" : job.status === "failed" ? "red" : "gray"} dot>{job.status}</Badge></td><td className="px-5 py-4"><div className="w-28"><div className="mb-1 text-[10px] text-[var(--muted-2)]">{job.progress.toFixed(0)}%</div><ProgressBar value={job.progress} className="h-1.5"/></div></td><td className="px-5 py-4 font-bold">{job.fps.toFixed(1)}</td><td className="px-5 py-4">{job.unique_tracks}</td><td className="px-5 py-4"><Link to={`/processing/${job.id}`}><Button variant="ghost" className="h-9 px-3"><Eye size={15}/> مشاهده</Button></Link></td></tr>)}
            </tbody>
          </table>
          {jobs.length === 0 && <div className="py-14 text-center text-xs text-[var(--muted)]">نتیجه‌ای مطابق فیلتر پیدا نشد.</div>}
        </div>
      </Card>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="p-5"><FileBarChart className="text-[#33d3bb]"/><h3 className="mt-4 text-sm font-black">گزارش تحلیلی</h3><p className="mt-2 text-xs leading-6 text-[var(--muted)]">نمودار تعداد افراد، Confidence، سرعت و Timeline رخدادها.</p><div className="mt-4"><Badge tone="gray">مرحله اتصال مدل</Badge></div></Card>
        <Card className="p-5"><FileJson className="text-[#8e9aff]"/><h3 className="mt-4 text-sm font-black">داده ساختاریافته</h3><p className="mt-2 text-xs leading-6 text-[var(--muted)]">خروجی CSV و JSON برای تحلیل‌های بعدی و اتصال به سامانه‌های دیگر.</p></Card>
        <Card className="p-5"><FileVideo2 className="text-[#f6bd58]"/><h3 className="mt-4 text-sm font-black">ویدئوی Annotated</h3><p className="mt-2 text-xs leading-6 text-[var(--muted)]">خروجی H.264 همراه Bounding Box، Track ID و مسیر حرکت.</p></Card>
      </div>
    </div>
  );
}
