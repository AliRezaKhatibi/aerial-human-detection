import { Save, ShieldCheck } from "lucide-react";
import { ProfileCard } from "@/components/ProfileCard";
import { Card, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Badge } from "@/components/ui/Badge";
import { PageHeader } from "@/components/PageHeader";
import { useAppStore } from "@/stores/app-store";

export function ProfilesPage() {
  const profile = useAppStore((s) => s.selectedProfile);
  const setProfile = useAppStore((s) => s.setSelectedProfile);
  const values = {
    fast: { maxTiles: "0", refresh: "—", overlap: "20%", tiling: "Off", target: "Real-time" },
    balanced: { maxTiles: "2", refresh: "6 frames", overlap: "20%", tiling: "Adaptive", target: "Production" },
    accuracy: { maxTiles: "6", refresh: "1 frame", overlap: "25%", tiling: "Extensive", target: "Offline analysis" },
  }[profile];
  return (
    <div className="space-y-6">
      <PageHeader eyebrow="Inference profiles" title="پروفایل‌های استنتاج" description="این سه پروفایل از یک مدل واحد استفاده می‌کنند؛ تفاوت آن‌ها در راهبرد Tiling و هزینه پردازشی است." actions={<><Badge tone="green"><ShieldCheck size={12}/> Same best.pt</Badge><Button disabled><Save size={15}/> ذخیره پروفایل سفارشی</Button></>} />
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3"><ProfileCard kind="fast" selected={profile === "fast"} onClick={() => setProfile("fast")}/><ProfileCard kind="balanced" selected={profile === "balanced"} onClick={() => setProfile("balanced")}/><ProfileCard kind="accuracy" selected={profile === "accuracy"} onClick={() => setProfile("accuracy")}/></div>
      <Card><CardHeader title={`پارامترهای پروفایل ${profile}`} description="مقادیر پیش‌فرض برای رابط تجاری" /><div className="grid grid-cols-2 gap-4 p-5 sm:grid-cols-3 xl:grid-cols-5">{[["Full image","1280"],["Tile image","960"],["Max tiles",values.maxTiles],["Refresh",values.refresh],["Overlap",values.overlap],["Tiling",values.tiling],["Tracker","ByteTrack"],["Precision","FP16"],["Model","YOLO26m-P2"],["Target",values.target]].map(([a,b])=><div key={a} className="rounded-xl border border-[var(--border)] bg-white/[.025] p-4"><div className="text-[10px] text-[var(--muted-2)]">{a}</div><div className="mt-2 text-xs font-black">{b}</div></div>)}</div></Card>
      <Card><CardHeader title="راهنمای انتخاب" /><div className="grid grid-cols-1 gap-4 p-5 md:grid-cols-3"><div className="rounded-xl bg-[#33d3bb]/6 p-4 text-xs leading-7 text-[var(--muted)]"><strong className="text-[var(--text)]">Fast:</strong> پایش زنده و صحنه‌های دارای افراد نسبتاً بزرگ.</div><div className="rounded-xl bg-[#7d8dff]/7 p-4 text-xs leading-7 text-[var(--muted)]"><strong className="text-[var(--text)]">Balanced:</strong> انتخاب پیش‌فرض برای محصول نهایی و استفاده عمومی.</div><div className="rounded-xl bg-[#f6bd58]/7 p-4 text-xs leading-7 text-[var(--muted)]"><strong className="text-[var(--text)]">Accuracy:</strong> تحلیل آفلاین صحنه‌های شلوغ با اهداف بسیار کوچک.</div></div></Card>
    </div>
  );
}
