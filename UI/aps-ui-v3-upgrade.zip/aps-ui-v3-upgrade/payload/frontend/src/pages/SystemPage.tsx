import { useQuery } from "@tanstack/react-query";
import { CheckCircle2, Cpu, HardDrive, MemoryStick, MonitorCog, RefreshCw, XCircle, type LucideIcon } from "lucide-react";
import { Card, CardHeader } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { ProgressBar } from "@/components/ui/ProgressBar";
import { PageHeader } from "@/components/PageHeader";
import { api } from "@/lib/api";

interface SystemItem { label: string; value: string; icon: LucideIcon; percent?: number; }

export function SystemPage() {
  const query = useQuery({ queryKey: ["system-page"], queryFn: api.system, refetchInterval: 3000, retry: 1 });
  const data = query.data;
  const vramPercent = data?.vram_total_mb ? ((data.vram_used_mb ?? 0) / data.vram_total_mb) * 100 : 0;
  const items: SystemItem[] = [
    { label: "GPU", value: data?.gpu_name ?? "Unavailable", icon: Cpu, percent: data?.gpu_usage_percent ?? 0 },
    { label: "VRAM", value: data?.vram_total_mb ? `${Math.round(data.vram_used_mb ?? 0)} / ${Math.round(data.vram_total_mb)} MB` : "Unavailable", icon: MemoryStick, percent: vramPercent },
    { label: "RAM", value: `${Math.round(data?.memory_percent ?? 0)}%`, icon: HardDrive, percent: data?.memory_percent ?? 0 },
    { label: "CPU", value: `${Math.round(data?.cpu_percent ?? 0)}%`, icon: MonitorCog, percent: data?.cpu_percent ?? 0 },
  ];
  const dependencies = [
    { name: "FastAPI", ready: query.isSuccess, detail: "Backend API" },
    { name: "WebSocket", ready: query.isSuccess, detail: "Live telemetry" },
    { name: "Model", ready: Boolean(data?.model_loaded), detail: data?.model_loaded ? "Loaded" : "Mock mode" },
    { name: "TensorRT", ready: data?.inference_backend.includes("TensorRT") ?? false, detail: data?.inference_backend ?? "Pending" },
    { name: "FFmpeg", ready: false, detail: "Pending integration" },
    { name: "ByteTrack", ready: false, detail: "Scaffolded" },
  ];

  return (
    <div className="space-y-6">
      <PageHeader eyebrow="Diagnostics" title="وضعیت سیستم" description="نمایش منابع سخت‌افزاری، Backend و وابستگی‌های موتور استنتاج." actions={<Button variant="secondary" onClick={() => void query.refetch()} loading={query.isFetching}><RefreshCw size={15}/> تازه‌سازی</Button>} />
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">{items.map(({ label, value, icon: Icon, percent }) => <Card key={label} className="p-5"><div className="flex items-center justify-between"><div className="grid h-10 w-10 place-items-center rounded-xl bg-[#33d3bb]/8"><Icon className="text-[#33d3bb]" size={20}/></div><Badge tone={query.isSuccess ? "green" : "red"} dot>{query.isSuccess ? "ONLINE" : "OFFLINE"}</Badge></div><div className="mt-6 text-xs text-[var(--muted)]">{label}</div><div className="mt-2 truncate text-lg font-black">{value}</div>{typeof percent === "number" && <ProgressBar value={percent} className="mt-4 h-1.5"/>}</Card>)}</div>
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-[1.2fr_1fr]">
        <Card><CardHeader title="بررسی وابستگی‌ها" description="آمادگی اجزای محصول نهایی"/><div className="grid grid-cols-1 gap-3 p-5 sm:grid-cols-2">{dependencies.map((item) => <div key={item.name} className="flex items-center justify-between rounded-xl border border-[var(--border)] bg-white/[.025] p-4"><div><div className="text-xs font-bold">{item.name}</div><div className="mt-1 text-[10px] text-[var(--muted-2)]">{item.detail}</div></div>{item.ready ? <CheckCircle2 size={20} className="text-[#49d6a5]"/> : <XCircle size={20} className="text-[#f6bd58]"/>}</div>)}</div></Card>
        <Card><CardHeader title="اطلاعات Runtime"/><div className="space-y-4 p-5">{[["Platform",data?.platform ?? "—"],["Inference backend",data?.inference_backend ?? "—"],["Model loaded",data?.model_loaded ? "Yes" : "No"],["API endpoint","127.0.0.1:8000"],["Frontend","127.0.0.1:1420"]].map(([a,b])=><div key={a} className="flex items-center justify-between gap-4 border-b border-[var(--border)] pb-3 text-xs last:border-0"><span className="text-[var(--muted)]">{a}</span><span className="max-w-[60%] truncate font-bold">{b}</span></div>)}</div></Card>
      </div>
    </div>
  );
}
