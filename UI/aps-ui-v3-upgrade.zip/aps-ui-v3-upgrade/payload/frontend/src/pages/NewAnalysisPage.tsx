import { Camera, FileVideo2, FolderOpen, Info, Radio, SlidersHorizontal, UploadCloud } from "lucide-react";
import { useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ProfileCard } from "@/components/ProfileCard";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/Button";
import { Card, CardHeader } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Toggle } from "@/components/ui/Toggle";
import { api } from "@/lib/api";
import { useAppStore, type InferenceMode } from "@/stores/app-store";

const sourceTypes = [
  { id: "video", icon: FileVideo2, title: "فایل ویدئویی", description: "MP4، MOV، MKV و AVI", state: "فعال" },
  { id: "camera", icon: Camera, title: "دوربین محلی", description: "وب‌کم یا Capture Card", state: "به‌زودی" },
  { id: "rtsp", icon: Radio, title: "جریان RTSP", description: "دوربین شبکه و پهپاد", state: "به‌زودی" },
];

export function NewAnalysisPage() {
  const selectedProfile = useAppStore((s) => s.selectedProfile);
  const setSelectedProfile = useAppStore((s) => s.setSelectedProfile);
  const [profile, setProfileLocal] = useState<InferenceMode>(selectedProfile);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [confidence, setConfidence] = useState(0.2);
  const [showTrails, setShowTrails] = useState(true);
  const [saveVideo, setSaveVideo] = useState(true);
  const [loading, setLoading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  const setProfile = (next: InferenceMode) => { setProfileLocal(next); setSelectedProfile(next); };
  const startMock = async () => {
    setLoading(true);
    try {
      const job = await api.createMockJob(profile, selectedFile?.name ?? "demo-aerial-video.mp4");
      navigate(`/processing/${job.id}`);
    } finally { setLoading(false); }
  };

  return (
    <div className="space-y-6">
      <PageHeader eyebrow="New project" title="ایجاد تحلیل جدید" description="منبع ورودی، پروفایل استنتاج و تنظیمات خروجی را مشخص کنید. در نسخه فعلی Job به‌صورت Mock ایجاد می‌شود." actions={<Badge tone="amber"><Info size={12} /> Mock mode</Badge>} />

      <div className="grid grid-cols-1 gap-4 2xl:grid-cols-[1.45fr_0.75fr]">
        <Card className="p-5 sm:p-6">
          <input ref={inputRef} type="file" accept="video/*" className="hidden" onChange={(event) => setSelectedFile(event.target.files?.[0] ?? null)} />
          <button type="button" onClick={() => inputRef.current?.click()} onDragOver={(event) => event.preventDefault()} onDrop={(event) => { event.preventDefault(); setSelectedFile(event.dataTransfer.files?.[0] ?? null); }} className="focus-ring metric-grid grid min-h-[320px] w-full place-items-center rounded-2xl border border-dashed border-[#33d3bb]/28 bg-[#33d3bb]/[.03] p-6 text-center transition hover:border-[#33d3bb]/48 hover:bg-[#33d3bb]/[.055]">
            <div>
              <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-[#33d3bb]/10 text-[#57dec9]"><UploadCloud size={28}/></div>
              <h3 className="mt-5 font-black">{selectedFile ? selectedFile.name : "ویدئو را اینجا رها کنید"}</h3>
              <p className="mt-2 text-xs leading-6 text-[var(--muted)]">{selectedFile ? `${(selectedFile.size / 1024 / 1024).toFixed(1)} MB · آماده ایجاد Job آزمایشی` : "MP4, MOV, MKV, AVI · پردازش نهایی به‌صورت محلی انجام می‌شود"}</p>
              <span className="mt-5 inline-flex items-center gap-2 rounded-xl border border-[var(--border)] bg-white/[.055] px-4 py-2.5 text-sm font-bold"><FolderOpen size={16}/> انتخاب فایل</span>
            </div>
          </button>
        </Card>

        <Card>
          <CardHeader title="نوع منبع" description="ورودی موردنظر برای تحلیل" />
          <div className="space-y-3 p-5">
            {sourceTypes.map(({ id, icon: Icon, title, description, state }) => <button key={id} disabled={id !== "video"} className="focus-ring flex w-full items-center justify-between rounded-xl border border-[var(--border)] bg-white/[.025] p-4 text-right transition hover:bg-white/[.05] disabled:cursor-not-allowed disabled:opacity-55"><div className="flex items-center gap-3"><div className="grid h-10 w-10 place-items-center rounded-xl bg-white/[.045]"><Icon size={18} className="text-[#5adcc9]"/></div><div><div className="text-xs font-bold">{title}</div><div className="mt-1 text-[10px] text-[var(--muted-2)]">{description}</div></div></div><Badge tone={id === "video" ? "green" : "gray"}>{state}</Badge></button>)}
          </div>
        </Card>
      </div>

      <section>
        <div className="mb-4"><h3 className="text-base font-black">پروفایل پردازش</h3><p className="mt-1 text-xs text-[var(--muted-2)]">پروفایل Balanced برای استفاده عمومی پیشنهاد می‌شود.</p></div>
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3"><ProfileCard kind="fast" selected={profile === "fast"} onClick={() => setProfile("fast")}/><ProfileCard kind="balanced" selected={profile === "balanced"} onClick={() => setProfile("balanced")}/><ProfileCard kind="accuracy" selected={profile === "accuracy"} onClick={() => setProfile("accuracy")}/></div>
      </section>

      <Card>
        <CardHeader title={<span className="flex items-center gap-2"><SlidersHorizontal size={17} className="text-[#33d3bb]" /> تنظیمات سریع</span>} description="تنظیمات قابل ویرایش قبل از شروع پردازش" />
        <div className="grid grid-cols-1 gap-5 p-5 md:grid-cols-2 xl:grid-cols-4">
          <label className="rounded-xl border border-[var(--border)] bg-white/[.025] p-4"><div className="flex items-center justify-between text-xs"><span className="font-bold">Confidence</span><span className="text-[#5cdbc8]">{confidence.toFixed(2)}</span></div><input type="range" min="0.05" max="0.7" step="0.01" value={confidence} onChange={(e) => setConfidence(Number(e.target.value))} className="mt-4 w-full accent-[#33d3bb]" /><div className="mt-2 text-[10px] text-[var(--muted-2)]">آستانه نمایش جعبه‌های تشخیص</div></label>
          <div className="flex items-center justify-between rounded-xl border border-[var(--border)] bg-white/[.025] p-4"><div><div className="text-xs font-bold">نمایش مسیر Track</div><div className="mt-2 text-[10px] text-[var(--muted-2)]">رسم Trail برای شناسه‌ها</div></div><Toggle checked={showTrails} onChange={setShowTrails} label="نمایش مسیر" /></div>
          <div className="flex items-center justify-between rounded-xl border border-[var(--border)] bg-white/[.025] p-4"><div><div className="text-xs font-bold">ذخیره ویدئوی خروجی</div><div className="mt-2 text-[10px] text-[var(--muted-2)]">خروجی H.264 در پوشه Runtime</div></div><Toggle checked={saveVideo} onChange={setSaveVideo} label="ذخیره ویدئو" /></div>
          <label className="rounded-xl border border-[var(--border)] bg-white/[.025] p-4"><div className="text-xs font-bold">کیفیت خروجی</div><select className="focus-ring mt-3 w-full rounded-lg border border-[var(--border)] bg-[var(--panel-strong)] px-3 py-2 text-xs outline-none"><option>High · H.264</option><option>Balanced · H.264</option><option>Lossless · MKV</option></select></label>
        </div>
      </Card>

      <div className="flex flex-col-reverse justify-between gap-3 sm:flex-row sm:items-center"><p className="text-[11px] leading-6 text-[var(--muted-2)]">در این مرحله فایل واقعی آپلود نمی‌شود؛ تنها نام فایل برای شبیه‌سازی Workflow استفاده می‌شود.</p><Button onClick={startMock} loading={loading} className="px-8 py-3">شروع پردازش آزمایشی</Button></div>
    </div>
  );
}
