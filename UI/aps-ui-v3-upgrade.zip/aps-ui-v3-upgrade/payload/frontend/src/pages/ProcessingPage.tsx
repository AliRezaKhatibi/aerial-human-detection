import { Activity, Maximize2, Pause, Radio, RotateCcw, Square, Users } from "lucide-react";
import { useMemo } from "react";
import { Link, useParams } from "react-router-dom";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Card, CardHeader } from "@/components/ui/Card";
import { ProgressBar } from "@/components/ui/ProgressBar";
import { PageHeader } from "@/components/PageHeader";
import { useJobSocket } from "@/hooks/use-job-socket";

export function ProcessingPage() {
  const { jobId } = useParams();
  const { job, connected } = useJobSocket(jobId);
  const progress = job?.progress ?? 0;
  const telemetry = useMemo(() => [
    { label: "FPS", value: (job?.fps ?? 0).toFixed(1), caption: "سرعت فعلی" },
    { label: "افراد فعال", value: String(job?.active_tracks ?? 0), caption: "در فریم جاری" },
    { label: "افراد یکتا", value: String(job?.unique_tracks ?? 0), caption: "از شروع پردازش" },
    { label: "Confidence", value: `${Math.round((job?.mean_confidence ?? 0) * 100)}%`, caption: "میانگین تشخیص" },
  ], [job]);

  if (!jobId) {
    return <div className="space-y-6"><PageHeader title="پردازش زنده" description="برای مشاهده تله‌متری، ابتدا یک تحلیل جدید ایجاد کنید." /><Card className="grid min-h-[420px] place-items-center p-8 text-center"><div><Radio size={40} className="mx-auto text-[#33d3bb]"/><h3 className="mt-5 text-lg font-black">Job فعالی انتخاب نشده است</h3><p className="mt-2 text-xs text-[var(--muted)]">از صفحه تحلیل جدید یک Job آزمایشی بسازید.</p><Link to="/analysis/new"><Button className="mt-6">ایجاد تحلیل جدید</Button></Link></div></Card></div>;
  }

  return (
    <div className="space-y-5">
      <PageHeader eyebrow="Live workspace" title="پردازش زنده" description={`Job ID: ${jobId}`} actions={<><Badge tone={connected ? "green" : "amber"} dot>{connected ? "Live connected" : "Connecting"}</Badge><Badge tone="blue">{job?.profile ?? "balanced"}</Badge></>} />

      <div className="grid grid-cols-1 gap-4 2xl:grid-cols-[1fr_320px]">
        <Card className="overflow-hidden">
          <div className="relative aspect-video min-h-[360px] bg-[#03060a] metric-grid lg:min-h-[520px]">
            <div className="absolute inset-0 grid place-items-center p-6"><div className="text-center"><div className="mx-auto grid h-16 w-16 place-items-center rounded-full border border-[#33d3bb]/22 bg-[#33d3bb]/8"><Radio className="animate-pulse text-[#33d3bb]" size={30}/></div><div className="mt-5 text-sm font-bold">پیش‌نمایش ویدئو در مرحله اتصال موتور واقعی فعال می‌شود</div><div className="mt-2 text-xs leading-6 text-[var(--muted-2)]">در Mock Mode فقط تله‌متری WebSocket نمایش داده می‌شود.</div></div></div>
            <div className="absolute left-4 top-4 flex gap-2"><Badge tone="red" dot>REC</Badge><Badge tone="gray">1280p</Badge></div>
            <div className="absolute right-4 top-4"><Badge tone={job?.tiling_active ? "green" : "gray"}>{job?.tiling_active ? "ATTI Active" : "Full frame"}</Badge></div>
            <Button variant="ghost" className="absolute bottom-4 left-4 h-10 w-10 bg-black/25 p-0"><Maximize2 size={18}/></Button>
          </div>
          <div className="flex flex-col justify-between gap-3 border-t border-[var(--border)] px-5 py-4 sm:flex-row sm:items-center"><div className="flex flex-wrap gap-2"><Button variant="secondary" disabled><Pause size={16}/> مکث</Button><Button variant="danger" disabled><Square size={15}/> توقف</Button><Button variant="ghost" disabled><RotateCcw size={15}/> شروع مجدد</Button></div><div className="text-xs text-[var(--muted)]">Frame {job?.frame ?? 0} / {job?.total_frames ?? 0}</div></div>
        </Card>

        <div className="grid grid-cols-2 gap-3 2xl:grid-cols-1">
          {telemetry.map((item, index) => <Card key={item.label} className="p-4"><div className="flex items-start justify-between"><div><div className="text-[10px] font-semibold text-[var(--muted-2)]">{item.label}</div><div className="mt-1 text-xl font-black">{item.value}</div><div className="mt-1 text-[10px] text-[var(--muted-2)]">{item.caption}</div></div>{index === 1 ? <Users size={18} className="text-[#33d3bb]"/> : <Activity size={18} className="text-[#7d8dff]"/>}</div></Card>)}
          <Card className="col-span-2 p-4 2xl:col-span-1"><div className="flex items-center justify-between"><div><div className="text-[10px] text-[var(--muted-2)]">Tiling status</div><div className="mt-1 text-sm font-black">{job?.tiling_active ? "فعال" : "غیرفعال"}</div></div><span className={`h-3 w-3 rounded-full ${job?.tiling_active ? "bg-[#33d3bb] shadow-[0_0_14px_#33d3bb]" : "bg-[#69788e]"}`} /></div></Card>
        </div>
      </div>

      <Card>
        <CardHeader title="پیشرفت پردازش" description={job?.status ? `وضعیت: ${job.status}` : "در انتظار داده"} action={<span className="text-sm font-black">{progress.toFixed(1)}%</span>} />
        <div className="p-5"><ProgressBar value={progress} className="h-2.5" /><div className="mt-3 flex justify-between text-[10px] text-[var(--muted-2)]"><span>شروع</span><span>{job?.status === "completed" ? "تکمیل شد" : "در حال پردازش"}</span><span>پایان</span></div></div>
      </Card>
    </div>
  );
}
