import { FolderOpen, RotateCcw, Save } from "lucide-react";
import { useState } from "react";
import { PageHeader } from "@/components/PageHeader";
import { Card, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Toggle } from "@/components/ui/Toggle";
import { useAppStore } from "@/stores/app-store";

export function SettingsPage() {
  const theme = useAppStore((s) => s.theme);
  const setTheme = useAppStore((s) => s.setTheme);
  const locale = useAppStore((s) => s.locale);
  const setLocale = useAppStore((s) => s.setLocale);
  const [autoSave, setAutoSave] = useState(true);
  const [trails, setTrails] = useState(true);
  const [trackIds, setTrackIds] = useState(true);
  const [notifications, setNotifications] = useState(true);
  return (
    <div className="space-y-6">
      <PageHeader eyebrow="Preferences" title="تنظیمات برنامه" description="تنظیمات رابط، مسیر خروجی و رفتار پیش‌فرض پردازش را مدیریت کنید." actions={<><Button variant="ghost"><RotateCcw size={15}/> بازنشانی</Button><Button><Save size={15}/> ذخیره تنظیمات</Button></>} />
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        <Card><CardHeader title="رابط کاربری" description="ظاهر و زبان برنامه"/><div className="space-y-5 p-5"><label className="block"><div className="mb-2 text-xs font-bold">زبان رابط</div><select value={locale} onChange={(e) => setLocale(e.target.value as "fa" | "en")} className="focus-ring w-full rounded-xl border border-[var(--border)] bg-[var(--panel-strong)] px-3 py-3 text-xs outline-none"><option value="fa">فارسی · RTL</option><option value="en">English · LTR</option></select></label><label className="block"><div className="mb-2 text-xs font-bold">پوسته</div><select value={theme} onChange={(e) => setTheme(e.target.value as "dark" | "light")} className="focus-ring w-full rounded-xl border border-[var(--border)] bg-[var(--panel-strong)] px-3 py-3 text-xs outline-none"><option value="dark">Dark</option><option value="light">Light</option></select></label><div className="flex items-center justify-between rounded-xl border border-[var(--border)] bg-white/[.025] p-4"><div><div className="text-xs font-bold">اعلان پایان پردازش</div><div className="mt-1 text-[10px] text-[var(--muted-2)]">نمایش Notification محلی</div></div><Toggle checked={notifications} onChange={setNotifications}/></div></div></Card>
        <Card><CardHeader title="مسیرهای ذخیره‌سازی" description="محل مدل و خروجی‌های پردازش"/><div className="space-y-4 p-5">{[["پوشه خروجی","runtime/outputs"],["پوشه گزارش‌ها","runtime/reports"],["مسیر مدل","models/best.pt"]].map(([label,value])=><div key={label}><div className="mb-2 text-xs font-bold">{label}</div><div className="flex gap-2"><input value={value} readOnly className="min-w-0 flex-1 rounded-xl border border-[var(--border)] bg-white/[.025] px-3 py-3 text-xs outline-none"/><Button variant="secondary" disabled><FolderOpen size={16}/></Button></div></div>)}</div></Card>
        <Card><CardHeader title="تنظیمات خروجی"/><div className="space-y-4 p-5"><div className="flex items-center justify-between border-b border-[var(--border)] pb-4"><div><div className="text-xs font-bold">ذخیره خودکار ویدئو</div><div className="mt-1 text-[10px] text-[var(--muted-2)]">خروجی پس از اتمام Job</div></div><Toggle checked={autoSave} onChange={setAutoSave}/></div><div className="flex items-center justify-between border-b border-[var(--border)] pb-4"><div><div className="text-xs font-bold">نمایش Track ID</div><div className="mt-1 text-[10px] text-[var(--muted-2)]">شناسه یکتا روی هر فرد</div></div><Toggle checked={trackIds} onChange={setTrackIds}/></div><div className="flex items-center justify-between"><div><div className="text-xs font-bold">نمایش مسیر حرکت</div><div className="mt-1 text-[10px] text-[var(--muted-2)]">Trail کوتاه روی ویدئو</div></div><Toggle checked={trails} onChange={setTrails}/></div></div></Card>
        <Card><CardHeader title="کدک و کیفیت"/><div className="grid grid-cols-1 gap-4 p-5 sm:grid-cols-2"><label><div className="mb-2 text-xs font-bold">Codec</div><select className="focus-ring w-full rounded-xl border border-[var(--border)] bg-[var(--panel-strong)] px-3 py-3 text-xs"><option>H.264</option><option>H.265</option><option>FFV1 Lossless</option></select></label><label><div className="mb-2 text-xs font-bold">کیفیت</div><select className="focus-ring w-full rounded-xl border border-[var(--border)] bg-[var(--panel-strong)] px-3 py-3 text-xs"><option>High</option><option>Balanced</option><option>Compact</option></select></label><label><div className="mb-2 text-xs font-bold">فرمت گزارش</div><select className="focus-ring w-full rounded-xl border border-[var(--border)] bg-[var(--panel-strong)] px-3 py-3 text-xs"><option>CSV + JSON</option><option>CSV</option><option>JSON</option></select></label><label><div className="mb-2 text-xs font-bold">Log level</div><select className="focus-ring w-full rounded-xl border border-[var(--border)] bg-[var(--panel-strong)] px-3 py-3 text-xs"><option>Info</option><option>Debug</option><option>Warning</option></select></label></div></Card>
      </div>
    </div>
  );
}
