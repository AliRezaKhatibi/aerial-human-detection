import { API_BASE_URL } from "./config";
import type { HealthResponse, InferenceProfile, Job, SystemStatus } from "@/types/api";

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) },
    ...init,
  });
  if (!response.ok) throw new Error(`API error ${response.status}: ${await response.text()}`);
  return response.json() as Promise<T>;
}

export const api = {
  health: () => request<HealthResponse>("/health"),
  system: () => request<SystemStatus>("/system"),
  profiles: () => request<InferenceProfile[]>("/profiles"),
  jobs: () => request<Job[]>("/jobs"),
  job: (jobId: string) => request<Job>(`/jobs/${jobId}`),
  createMockJob: (profile = "balanced", sourcePath = "demo.mp4") =>
    request<Job>("/jobs", {
      method: "POST",
      body: JSON.stringify({ source_type: "mock", source_path: sourcePath, profile }),
    }),
  cancelJob: (jobId: string) => request<Job>(`/jobs/${jobId}/cancel`, { method: "POST" }),
};
