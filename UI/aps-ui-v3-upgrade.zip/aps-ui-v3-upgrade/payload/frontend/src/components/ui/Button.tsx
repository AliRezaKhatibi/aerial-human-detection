import type { ButtonHTMLAttributes, ReactNode } from "react";
import { LoaderCircle } from "lucide-react";
import { cn } from "@/lib/cn";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  children: ReactNode;
  variant?: "primary" | "secondary" | "ghost" | "danger";
  loading?: boolean;
}

export function Button({ children, variant = "primary", className, loading = false, disabled, ...props }: ButtonProps) {
  const variants = {
    primary: "bg-[#33d3bb] text-[#04110f] hover:bg-[#5de3d0] shadow-[0_10px_30px_rgba(51,211,187,.18)]",
    secondary: "bg-white/[.055] text-[var(--text)] border border-[var(--border)] hover:bg-white/[.09]",
    ghost: "bg-transparent text-[var(--muted)] hover:bg-white/[.055] hover:text-[var(--text)]",
    danger: "bg-[#ff7185]/13 text-[#ff8b9b] border border-[#ff7185]/23 hover:bg-[#ff7185]/20",
  };
  return (
    <button
      className={cn("focus-ring inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold transition disabled:cursor-not-allowed disabled:opacity-50", variants[variant], className)}
      disabled={disabled || loading}
      {...props}
    >
      {loading && <LoaderCircle size={16} className="animate-spin" />}
      {children}
    </button>
  );
}
