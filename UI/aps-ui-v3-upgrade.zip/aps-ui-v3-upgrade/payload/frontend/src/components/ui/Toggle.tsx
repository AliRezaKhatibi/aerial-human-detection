import { cn } from "@/lib/cn";

export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (checked: boolean) => void; label?: string }) {
  return (
    <button type="button" aria-pressed={checked} aria-label={label} onClick={() => onChange(!checked)} className={cn("focus-ring relative h-7 w-12 rounded-full border transition", checked ? "border-[#33d3bb]/35 bg-[#33d3bb]/22" : "border-[var(--border)] bg-white/[.055]")}> 
      <span className={cn("absolute top-1 h-5 w-5 rounded-full bg-white shadow transition-all", checked ? "right-6" : "right-1")} />
    </button>
  );
}
