import type { ReactNode } from "react";
import { cn } from "@/lib/cn";

export function Badge({ children, tone = "green", dot = false }: { children: ReactNode; tone?: "green" | "blue" | "amber" | "red" | "gray"; dot?: boolean }) {
  const tones = {
    green: "bg-[#33d3bb]/10 text-[#62dfcc] border-[#33d3bb]/20",
    blue: "bg-[#7d8dff]/10 text-[#a3adff] border-[#7d8dff]/20",
    amber: "bg-[#f6bd58]/10 text-[#f6ca78] border-[#f6bd58]/20",
    red: "bg-[#ff7185]/10 text-[#ff91a0] border-[#ff7185]/20",
    gray: "bg-white/[.045] text-[var(--muted)] border-[var(--border)]",
  };
  const dots = { green: "bg-[#49d6a5]", blue: "bg-[#7d8dff]", amber: "bg-[#f6bd58]", red: "bg-[#ff7185]", gray: "bg-[#8795a9]" };
  return <span className={cn("inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide", tones[tone])}>{dot && <span className={cn("h-1.5 w-1.5 rounded-full", dots[tone])} />}{children}</span>;
}
