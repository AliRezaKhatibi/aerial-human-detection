import { cn } from "@/lib/cn";

export function ProgressBar({ value, className, tone = "gradient" }: { value: number; className?: string; tone?: "gradient" | "green" | "blue" }) {
  const safe = Math.min(100, Math.max(0, Number.isFinite(value) ? value : 0));
  const fill = tone === "green" ? "bg-[#33d3bb]" : tone === "blue" ? "bg-[#7d8dff]" : "bg-gradient-to-l from-[#33d3bb] to-[#7d8dff]";
  return <div className={cn("h-2 overflow-hidden rounded-full bg-white/[.055]", className)}><div className={cn("h-full rounded-full transition-[width] duration-500", fill)} style={{ width: `${safe}%` }} /></div>;
}
