import type { ReactNode } from "react";

export function PageHeader({ eyebrow, title, description, actions }: { eyebrow?: string; title: string; description?: string; actions?: ReactNode }) {
  return (
    <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
      <div>
        {eyebrow && <div className="mb-2 text-[10px] font-extrabold uppercase tracking-[.18em] text-[#55dbc7]">{eyebrow}</div>}
        <h2 className="text-xl font-black tracking-tight text-[var(--text)] sm:text-2xl">{title}</h2>
        {description && <p className="mt-2 max-w-3xl text-xs leading-6 text-[var(--muted)] sm:text-sm">{description}</p>}
      </div>
      {actions && <div className="flex shrink-0 flex-wrap gap-2">{actions}</div>}
    </div>
  );
}
