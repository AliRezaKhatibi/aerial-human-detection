import { BarChart3, Cpu, FileVideo2, Gauge, LayoutDashboard, Settings, SlidersHorizontal, Sparkles, X } from "lucide-react";
import { NavLink } from "react-router-dom";
import { BrandMark } from "@/components/BrandMark";
import { cn } from "@/lib/cn";
import { useAppStore } from "@/stores/app-store";

const navItems = [
  { to: "/", label: "داشبورد", icon: LayoutDashboard },
  { to: "/analysis/new", label: "تحلیل جدید", icon: FileVideo2 },
  { to: "/processing", label: "پردازش زنده", icon: Gauge },
  { to: "/results", label: "نتایج و گزارش‌ها", icon: BarChart3 },
  { to: "/profiles", label: "پروفایل‌های مدل", icon: SlidersHorizontal },
  { to: "/settings", label: "تنظیمات", icon: Settings },
  { to: "/system", label: "وضعیت سیستم", icon: Cpu },
];

export function Sidebar() {
  const collapsed = useAppStore((state) => state.sidebarCollapsed);
  const mobileOpen = useAppStore((state) => state.mobileSidebarOpen);
  const setMobileOpen = useAppStore((state) => state.setMobileSidebarOpen);
  const locale = useAppStore((state) => state.locale);
  return (
    <aside className={cn(
      "fixed inset-y-0 z-40 border-[var(--border)] bg-[var(--panel-strong)] px-3 py-4 shadow-2xl backdrop-blur-xl transition-all duration-300",
      locale === "fa" ? "right-0 border-l" : "left-0 border-r",
      collapsed ? "lg:w-[84px]" : "lg:w-[272px]",
      mobileOpen ? "translate-x-0 w-[280px]" : locale === "fa" ? "translate-x-full lg:translate-x-0" : "-translate-x-full lg:translate-x-0",
    )}> 
      <div className="flex items-center justify-between px-2">
        <BrandMark compact={collapsed && !mobileOpen} />
        <button className="focus-ring grid h-9 w-9 place-items-center rounded-xl text-[var(--muted)] hover:bg-white/[.055] lg:hidden" onClick={() => setMobileOpen(false)}><X size={18} /></button>
      </div>
      <nav className="mt-8 space-y-1.5">
        {navItems.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            end={to === "/"}
            onClick={() => setMobileOpen(false)}
            title={collapsed ? label : undefined}
            className={({ isActive }) => cn(
              "focus-ring group flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold transition",
              isActive ? "bg-[#33d3bb]/12 text-[#62dfce] ring-1 ring-[#33d3bb]/15" : "text-[var(--muted)] hover:bg-white/[.045] hover:text-[var(--text)]",
            )}
          >
            <Icon size={19} strokeWidth={1.8} className="shrink-0" />
            {(!collapsed || mobileOpen) && <span>{label}</span>}
          </NavLink>
        ))}
      </nav>
      <div className="absolute bottom-4 left-3 right-3 rounded-2xl border border-[#7d8dff]/15 bg-gradient-to-br from-[#7d8dff]/10 to-[#33d3bb]/5 p-3">
        <div className="flex items-center gap-2 text-xs font-bold text-[var(--text)]"><Sparkles size={15} className="text-[#9aa5ff]" /> {(!collapsed || mobileOpen) && "YOLO26m-P2"}</div>
        {(!collapsed || mobileOpen) && <div className="mt-1 text-[11px] leading-5 text-[var(--muted-2)]">نسخه رابط 0.3 · حالت آزمایشی فعال</div>}
      </div>
    </aside>
  );
}
