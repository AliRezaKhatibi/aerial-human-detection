import type { CSSProperties } from "react";
import { Outlet } from "react-router-dom";
import { Sidebar } from "./Sidebar";
import { Topbar } from "./Topbar";
import { useAppStore } from "@/stores/app-store";

export function AppShell() {
  const collapsed = useAppStore((state) => state.sidebarCollapsed);
  const mobileOpen = useAppStore((state) => state.mobileSidebarOpen);
  const setMobileOpen = useAppStore((state) => state.setMobileSidebarOpen);
  const shellStyle = { "--sidebar-offset": collapsed ? "84px" : "272px" } as CSSProperties;

  return (
    <div className="min-h-screen text-[var(--text)]">
      <Sidebar />
      {mobileOpen && <button aria-label="بستن منو" className="fixed inset-0 z-30 bg-black/55 backdrop-blur-sm lg:hidden" onClick={() => setMobileOpen(false)} />}
      <div className="min-h-screen transition-[margin] duration-300 lg:[margin-inline-start:var(--sidebar-offset)]" style={shellStyle}>
        <Topbar />
        <main className="mx-auto w-full max-w-[1800px] p-4 sm:p-5 lg:p-6"><Outlet /></main>
      </div>
    </div>
  );
}
