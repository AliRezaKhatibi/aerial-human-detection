import { Bell, ChevronLeft, Languages, Menu, Moon, Search, Sun } from "lucide-react";
import { useLocation } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { Badge } from "@/components/ui/Badge";
import { useAppStore } from "@/stores/app-store";
import { api } from "@/lib/api";

const titles: Record<string, string> = {
  "/": "داشبورد عملیات",
  "/analysis/new": "تحلیل جدید",
  "/processing": "پردازش زنده",
  "/results": "نتایج و گزارش‌ها",
  "/profiles": "پروفایل‌های استنتاج",
  "/settings": "تنظیمات برنامه",
  "/system": "وضعیت سیستم",
};

export function Topbar() {
  const location = useLocation();
  const toggleSidebar = useAppStore((s) => s.toggleSidebar);
  const setMobileOpen = useAppStore((s) => s.setMobileSidebarOpen);
  const toggleTheme = useAppStore((s) => s.toggleTheme);
  const theme = useAppStore((s) => s.theme);
  const locale = useAppStore((s) => s.locale);
  const setLocale = useAppStore((s) => s.setLocale);
  const health = useQuery({ queryKey: ["health-topbar"], queryFn: api.health, refetchInterval: 8000, retry: 1 });
  const current = Object.entries(titles).find(([path]) => path === "/" ? location.pathname === path : location.pathname.startsWith(path))?.[1] ?? "Aerial Person Studio";
  return (
    <header className="sticky top-0 z-20 flex h-[74px] items-center justify-between border-b border-[var(--border)] bg-[var(--bg)]/78 px-4 backdrop-blur-xl sm:px-5 lg:px-6">
      <div className="flex min-w-0 items-center gap-3">
        <Button variant="ghost" className="h-10 w-10 p-0 lg:hidden" onClick={() => setMobileOpen(true)}><Menu size={19} /></Button>
        <Button variant="ghost" className="hidden h-10 w-10 p-0 lg:inline-flex" onClick={toggleSidebar}><Menu size={19} /></Button>
        <div className="min-w-0">
          <h1 className="truncate text-sm font-extrabold text-[var(--text)] sm:text-base">{current}</h1>
          <div className="mt-0.5 hidden items-center gap-1 text-[11px] text-[var(--muted-2)] sm:flex">استودیو <ChevronLeft size={12} /> عملیات بینایی ماشین</div>
        </div>
      </div>
      <div className="flex items-center gap-1.5 sm:gap-2">
        <div className="hidden items-center gap-2 rounded-xl border border-[var(--border)] bg-white/[.03] px-3 py-2 2xl:flex">
          <Search size={16} className="text-[var(--muted-2)]" />
          <input className="w-48 bg-transparent text-xs text-[var(--text)] outline-none" placeholder="جست‌وجوی پروژه یا گزارش..." />
        </div>
        <Badge tone={health.isSuccess ? "green" : health.isError ? "red" : "amber"} dot>{health.isSuccess ? "Backend Online" : health.isError ? "Disconnected" : "Checking"}</Badge>
        <Button variant="ghost" className="hidden h-10 w-10 p-0 sm:inline-flex" onClick={() => setLocale(locale === "fa" ? "en" : "fa")} title="تغییر زبان"><Languages size={18} /></Button>
        <Button variant="ghost" className="h-10 w-10 p-0" onClick={toggleTheme} title="تغییر پوسته">{theme === "dark" ? <Moon size={18} /> : <Sun size={18} />}</Button>
        <Button variant="ghost" className="relative hidden h-10 w-10 p-0 sm:inline-flex"><Bell size={18} /><span className="absolute left-2 top-2 h-1.5 w-1.5 rounded-full bg-[#ff7185]" /></Button>
        <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-[#33d3bb] to-[#687dff] p-[1px]"><div className="grid h-full w-full place-items-center rounded-[11px] bg-[var(--panel-strong)] text-xs font-black">AP</div></div>
      </div>
    </header>
  );
}
