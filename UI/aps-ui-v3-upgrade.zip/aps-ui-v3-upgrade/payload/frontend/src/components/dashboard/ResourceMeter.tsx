import { ProgressBar } from "@/components/ui/ProgressBar";

export function ResourceMeter({ label, value, detail }: { label: string; value: number; detail?: string }) {
  const safe = Math.round(Math.min(100, Math.max(0, value || 0)));
  return (
    <div>
      <div className="mb-2 flex items-center justify-between text-xs">
        <span className="text-[var(--muted)]">{label}</span>
        <div className="flex items-center gap-2"><span className="text-[10px] text-[var(--muted-2)]">{detail}</span><span className="font-bold text-[var(--text)]">{safe}%</span></div>
      </div>
      <ProgressBar value={safe} />
    </div>
  );
}
