import type { ReactNode } from "react";
import { ArrowDownRight, ArrowUpLeft } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { cn } from "@/lib/cn";

export function StatCard({ title, value, caption, icon, trend, trendDirection = "up" }: { title: string; value: string; caption: string; icon: ReactNode; trend?: string; trendDirection?: "up" | "down" }) {
  return (
    <Card className="panel-hover p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="grid h-10 w-10 place-items-center rounded-xl border border-[#33d3bb]/14 bg-[#33d3bb]/8 text-[#5ee0cc]">{icon}</div>
        {trend && <span className={cn("inline-flex items-center gap-1 rounded-full px-2 py-1 text-[10px] font-bold", trendDirection === "up" ? "bg-[#33d3bb]/10 text-[#5bdfcc]" : "bg-[#ff7185]/10 text-[#ff91a0]")}>{trendDirection === "up" ? <ArrowUpLeft size={11} /> : <ArrowDownRight size={11} />}{trend}</span>}
      </div>
      <div className="mt-5 text-xs font-semibold text-[var(--muted)]">{title}</div>
      <div className="mt-1 text-2xl font-black tracking-tight text-[var(--text)]">{value}</div>
      <div className="mt-2 text-[11px] text-[var(--muted-2)]">{caption}</div>
    </Card>
  );
}
