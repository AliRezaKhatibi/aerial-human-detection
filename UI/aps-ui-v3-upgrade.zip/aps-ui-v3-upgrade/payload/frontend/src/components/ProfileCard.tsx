import { Check, Gauge, ScanSearch, Zap } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { cn } from "@/lib/cn";
import type { InferenceMode } from "@/stores/app-store";

const details = {
  fast: { icon: Zap, tone: "text-[#57dec9]", title: "Fast", subtitle: "بیشترین سرعت", body: "پردازش Full-frame بدون برش تطبیقی؛ مناسب پایش زنده.", tags: ["No tiling", "Max FPS"], estimate: "17–28 FPS" },
  balanced: { icon: Gauge, tone: "text-[#a1abff]", title: "Balanced", subtitle: "پیشنهادشده", body: "برش تطبیقی کم‌هزینه با تعادل میان سرعت و Recall.", tags: ["Adaptive", "Recommended"], estimate: "10–18 FPS" },
  accuracy: { icon: ScanSearch, tone: "text-[#f7ca75]", title: "Accuracy", subtitle: "بیشترین Recall", body: "برش گسترده برای یافتن افراد بسیار کوچک در صحنه‌های دشوار.", tags: ["Extensive", "Max recall"], estimate: "4–9 FPS" },
};

export function ProfileCard({ kind, selected, onClick, compact = false }: { kind: InferenceMode; selected?: boolean; onClick?: () => void; compact?: boolean }) {
  const item = details[kind];
  const Icon = item.icon;
  return (
    <Card onClick={onClick} className={cn("panel-hover relative cursor-pointer p-5", selected && "border-[#33d3bb]/38 ring-1 ring-[#33d3bb]/18", compact && "p-4")}> 
      {selected && <div className="absolute left-4 top-4 grid h-6 w-6 place-items-center rounded-full bg-[#33d3bb] text-[#06110f]"><Check size={14} strokeWidth={3} /></div>}
      <div className="flex items-start justify-between gap-3">
        <div className="grid h-10 w-10 place-items-center rounded-xl bg-white/[.045]"><Icon className={item.tone} size={22} /></div>
        <span className="text-[10px] font-bold text-[var(--muted-2)]">{item.estimate}</span>
      </div>
      <div className="mt-4 text-base font-black text-[var(--text)]">{item.title}</div>
      <div className="mt-1 text-xs font-bold text-[var(--muted)]">{item.subtitle}</div>
      {!compact && <p className="mt-3 min-h-12 text-xs leading-6 text-[var(--muted-2)]">{item.body}</p>}
      <div className="mt-4 flex flex-wrap gap-2">{item.tags.map((tag) => <Badge key={tag} tone={selected ? "green" : "gray"}>{tag}</Badge>)}</div>
    </Card>
  );
}
