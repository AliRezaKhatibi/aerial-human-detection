import { create } from "zustand";
import { persist } from "zustand/middleware";

export type Locale = "fa" | "en";
export type Theme = "dark" | "light";
export type InferenceMode = "fast" | "balanced" | "accuracy";

interface AppState {
  locale: Locale;
  theme: Theme;
  sidebarCollapsed: boolean;
  mobileSidebarOpen: boolean;
  selectedProfile: InferenceMode;
  setLocale: (locale: Locale) => void;
  setTheme: (theme: Theme) => void;
  toggleTheme: () => void;
  toggleSidebar: () => void;
  setMobileSidebarOpen: (open: boolean) => void;
  setSelectedProfile: (profile: InferenceMode) => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      locale: "fa",
      theme: "dark",
      sidebarCollapsed: false,
      mobileSidebarOpen: false,
      selectedProfile: "balanced",
      setLocale: (locale) => set({ locale }),
      setTheme: (theme) => set({ theme }),
      toggleTheme: () => set((state) => ({ theme: state.theme === "dark" ? "light" : "dark" })),
      toggleSidebar: () => set((state) => ({ sidebarCollapsed: !state.sidebarCollapsed })),
      setMobileSidebarOpen: (mobileSidebarOpen) => set({ mobileSidebarOpen }),
      setSelectedProfile: (selectedProfile) => set({ selectedProfile }),
    }),
    {
      name: "aps-ui-settings",
      partialize: (state) => ({
        locale: state.locale,
        theme: state.theme,
        sidebarCollapsed: state.sidebarCollapsed,
        selectedProfile: state.selectedProfile,
      }),
    },
  ),
);
