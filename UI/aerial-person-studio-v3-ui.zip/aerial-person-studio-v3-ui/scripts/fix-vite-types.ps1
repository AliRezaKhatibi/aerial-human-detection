$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$Target = Join-Path $Root "frontend/src/vite-env.d.ts"
'/// <reference types="vite/client" />' | Set-Content -Path $Target -Encoding utf8
Write-Host "Created: $Target" -ForegroundColor Green
Write-Host "Now run: npm --prefix frontend run build" -ForegroundColor Cyan
