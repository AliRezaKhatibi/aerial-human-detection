# راهنمای رفع خطا

## ترتیب صحیح اجرا

فعلاً ابتدا نسخه وب را اجرا کنید. اجرای Tauri را بعد از سالم بودن Frontend و Backend انجام دهید.

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\scripts\doctor.ps1
.\scripts\setup.ps1
.\scripts\start-web.ps1
```

سپس این دو آدرس را بررسی کنید:

- Backend: `http://127.0.0.1:8000/docs`
- Frontend: `http://127.0.0.1:1420`

## محل فایل‌های خطا

- `runtime/logs/doctor.txt`
- `runtime/logs/setup.log`

در صورت خطا، فایل `setup.log` را ارسال کنید.

## خطاهای رایج

### Node.js قدیمی

Vite این پروژه به Node.js جدید نیاز دارد. Node.js 22 LTS نصب شود و PowerShell دوباره باز شود.

### Python نامناسب

پروژه Backend با Python 3.11 یا 3.12 اجرا می‌شود. Python 3.13 برای این Starter انتخاب نشده است.

### Rust یا Cargo پیدا نشد

این مورد فقط برای پنجره Desktop و ساخت Installer لازم است. نسخه وب بدون Rust اجرا می‌شود.

### npm install شکست خورد

اتصال اینترنت، Proxy، VPN، فایروال و دسترسی به `registry.npmjs.org` بررسی شود. سپس داخل پوشه `frontend` اجرا کنید:

```powershell
npm cache verify
npm install
```

## خطای `Property 'env' does not exist on type 'ImportMeta'`

این خطا یعنی اعلان نوع Vite در پروژه وجود ندارد. دستور زیر را از ریشه پروژه اجرا کنید:

```powershell
.\scripts\fix-vite-types.ps1
npm --prefix frontend run build
```
