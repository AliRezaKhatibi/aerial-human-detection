param(
  [string]$ProjectPath = "D:\APS\app"
)

$ErrorActionPreference = "Stop"

function Assert-Exists([string]$Path, [string]$Label) {
  if (-not (Test-Path $Path)) {
    throw "$Label not found: $Path"
  }
}

$ProjectPath = (Resolve-Path $ProjectPath).Path
$FrontendPath = Join-Path $ProjectPath "frontend"
$SourcePath = Join-Path $FrontendPath "src"
$PackagePath = Join-Path $FrontendPath "package.json"
$PayloadFrontend = Join-Path $PSScriptRoot "payload\frontend"
$PayloadSource = Join-Path $PayloadFrontend "src"
$PayloadPackage = Join-Path $PayloadFrontend "package.json"

Assert-Exists $FrontendPath "Frontend directory"
Assert-Exists $SourcePath "Frontend source directory"
Assert-Exists $PackagePath "Frontend package.json"
Assert-Exists $PayloadSource "Upgrade source payload"
Assert-Exists $PayloadPackage "Upgrade package.json payload"

$Timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$BackupPath = Join-Path $ProjectPath "ui-backup-v4.2-$Timestamp"
New-Item -ItemType Directory -Force $BackupPath | Out-Null

Write-Host "Aerial Person Studio - UI v4.2 Upgrade" -ForegroundColor Cyan
Write-Host "Project: $ProjectPath"
Write-Host "Backup:  $BackupPath"

try {
  Write-Host "[1/4] Backing up current frontend files..." -ForegroundColor Yellow
  Copy-Item $SourcePath (Join-Path $BackupPath "src") -Recurse -Force
  Copy-Item $PackagePath (Join-Path $BackupPath "package.json") -Force

  Write-Host "[2/4] Applying localization and settings fixes..." -ForegroundColor Yellow
  Remove-Item $SourcePath -Recurse -Force
  Copy-Item $PayloadSource $SourcePath -Recurse -Force
  Copy-Item $PayloadPackage $PackagePath -Force

  Write-Host "[3/4] Building frontend..." -ForegroundColor Yellow
  Push-Location $ProjectPath
  try {
    & npm --prefix frontend run build
    if ($LASTEXITCODE -ne 0) {
      throw "Frontend build failed with exit code $LASTEXITCODE."
    }
  }
  finally {
    Pop-Location
  }

  Write-Host "[4/4] Upgrade verification completed." -ForegroundColor Yellow
  Write-Host "UI v4.2 upgrade completed successfully." -ForegroundColor Green
  Write-Host "Restart frontend and backend, then open http://127.0.0.1:1420"
}
catch {
  Write-Host "Upgrade failed. Restoring the previous frontend..." -ForegroundColor Red
  if (Test-Path (Join-Path $BackupPath "src")) {
    if (Test-Path $SourcePath) { Remove-Item $SourcePath -Recurse -Force }
    Copy-Item (Join-Path $BackupPath "src") $SourcePath -Recurse -Force
  }
  if (Test-Path (Join-Path $BackupPath "package.json")) {
    Copy-Item (Join-Path $BackupPath "package.json") $PackagePath -Force
  }
  throw
}
