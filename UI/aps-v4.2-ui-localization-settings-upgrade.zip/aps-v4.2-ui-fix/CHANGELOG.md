# UI v4.2 Changelog

## Fixed
- Full bilingual localization instead of direction-only language switching.
- Nonfunctional Save and Reset controls on Settings.
- Settings persistence and application to new-analysis defaults.
- LTR/RTL alignment for tables, toggles, selection marks, and directional icons.
- Fullscreen action on live processing.
- Page search action in the top bar.
- Browser completion notifications.

## Audited controls
- Unsupported codec/quality/log controls are explicitly disabled.
- Runtime paths are read-only with a working copy action.
- Notification bell is disabled when no notification center exists.
- Future source types and custom profile/export actions remain clearly disabled.
