import { lazy, Suspense, useEffect } from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import { AppShell } from "@/components/layout/AppShell";
import { PageLoader } from "@/components/feedback/PageLoader";
import { useAppStore } from "@/stores/app-store";
import { useI18n } from "@/hooks/use-i18n";

const DashboardPage = lazy(() => import("@/pages/DashboardPage").then((module) => ({ default: module.DashboardPage })));
const NewAnalysisPage = lazy(() => import("@/pages/NewAnalysisPage").then((module) => ({ default: module.NewAnalysisPage })));
const ProcessingPage = lazy(() => import("@/pages/ProcessingPage").then((module) => ({ default: module.ProcessingPage })));
const ResultsPage = lazy(() => import("@/pages/ResultsPage").then((module) => ({ default: module.ResultsPage })));
const ProfilesPage = lazy(() => import("@/pages/ProfilesPage").then((module) => ({ default: module.ProfilesPage })));
const SettingsPage = lazy(() => import("@/pages/SettingsPage").then((module) => ({ default: module.SettingsPage })));
const SystemPage = lazy(() => import("@/pages/SystemPage").then((module) => ({ default: module.SystemPage })));

export default function App() {
  const locale = useAppStore((state) => state.locale);
  const theme = useAppStore((state) => state.theme);
  const { t } = useI18n();

  useEffect(() => {
    document.documentElement.dir = locale === "fa" ? "rtl" : "ltr";
    document.documentElement.lang = locale;
    document.documentElement.dataset.theme = theme;
    document.documentElement.classList.toggle("dark", theme === "dark");
    document.title = t("common.appName");
  }, [locale, t, theme]);

  return (
    <Suspense fallback={<PageLoader />}>
      <Routes>
        <Route element={<AppShell />}>
          <Route path="/" element={<DashboardPage />} />
          <Route path="/analysis/new" element={<NewAnalysisPage />} />
          <Route path="/processing/:jobId?" element={<ProcessingPage />} />
          <Route path="/results" element={<ResultsPage />} />
          <Route path="/profiles" element={<ProfilesPage />} />
          <Route path="/settings" element={<SettingsPage />} />
          <Route path="/system" element={<SystemPage />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Suspense>
  );
}
