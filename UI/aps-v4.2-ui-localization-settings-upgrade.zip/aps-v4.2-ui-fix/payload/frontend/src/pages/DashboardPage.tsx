import { Activity, ArrowUpLeft, ArrowUpRight, Clock3, Cpu, FileVideo2, Gauge, Play, RefreshCw, Users } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import ReactECharts from "echarts-for-react";
import { motion } from "framer-motion";
import { api } from "@/lib/api";
import { Button } from "@/components/ui/Button";
import { Card, CardHeader } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { StatCard } from "@/components/StatCard";
import { ProfileCard } from "@/components/ProfileCard";
import { ResourceMeter } from "@/components/dashboard/ResourceMeter";
import { useAppStore } from "@/stores/app-store";
import { useI18n } from "@/hooks/use-i18n";

const chartOption = {
  backgroundColor: "transparent",
  animationDuration: 700,
  grid: { left: 10, right: 14, top: 24, bottom: 12, containLabel: true },
  tooltip: { trigger: "axis", backgroundColor: "#101a29", borderColor: "rgba(255,255,255,.08)", textStyle: { color: "#fff" } },
  xAxis: { type: "category", boundaryGap: false, data: ["00", "04", "08", "12", "16", "20", "24"], axisLine: { lineStyle: { color: "rgba(255,255,255,.08)" } }, axisLabel: { color: "#6f8099", fontSize: 10 } },
  yAxis: { type: "value", min: 0, max: 30, splitLine: { lineStyle: { color: "rgba(255,255,255,.045)" } }, axisLabel: { color: "#6f8099", fontSize: 10 } },
  series: [{ name: "FPS", type: "line", smooth: true, symbol: "none", data: [14, 16, 15, 18, 17, 19, 18], lineStyle: { width: 3, color: "#33d3bb" }, areaStyle: { color: { type: "linear", x: 0, y: 0, x2: 0, y2: 1, colorStops: [{ offset: 0, color: "rgba(51,211,187,.28)" }, { offset: 1, color: "rgba(51,211,187,0)" }] } } }],
};

export function DashboardPage() {
  const selectedProfile = useAppStore((s) => s.selectedProfile);
  const setSelectedProfile = useAppStore((s) => s.setSelectedProfile);
  const { t, isRtl, profileName, jobStatus, formatNumber } = useI18n();
  const systemQuery = useQuery({ queryKey: ["system"], queryFn: api.system, refetchInterval: 5000, retry: 1 });
  const jobsQuery = useQuery({ queryKey: ["jobs-dashboard"], queryFn: api.jobs, refetchInterval: 5000, retry: 1 });
  const system = systemQuery.data;
  const recentJobs = jobsQuery.data?.slice(0, 4) ?? [];
  const activeJobs = jobsQuery.data?.filter((job) => job.status === "running").length ?? 0;
  const completedJobs = jobsQuery.data?.filter((job) => job.status === "completed").length ?? 0;
  const ManageIcon = isRtl ? ArrowUpLeft : ArrowUpRight;

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      <section className="glass metric-grid relative overflow-hidden rounded-3xl p-5 sm:p-6 lg:p-7">
        <div className="absolute -start-20 -top-24 h-64 w-64 rounded-full bg-[#7d8dff]/10 blur-3xl" />
        <div className="absolute -bottom-24 end-20 h-56 w-56 rounded-full bg-[#33d3bb]/8 blur-3xl" />
        <div className="relative flex flex-col justify-between gap-6 xl:flex-row xl:items-center">
          <div>
            <div className="mb-3 flex flex-wrap items-center gap-2">
              <Badge tone={systemQuery.isSuccess ? "green" : "red"} dot>{systemQuery.isSuccess ? t("dashboard.systemOnline") : t("dashboard.backendOffline")}</Badge>
              <Badge tone={system?.model_loaded ? "green" : system?.model_available ? "blue" : "amber"}>{system?.model_loaded ? t("dashboard.modelLoaded") : system?.model_available ? t("dashboard.modelAvailable") : t("dashboard.modelMissing")}</Badge>
              {activeJobs > 0 && <Badge tone="blue">{t("dashboard.activeJobs", { count: formatNumber(activeJobs) })}</Badge>}
            </div>
            <h2 className="max-w-3xl text-xl font-black leading-[1.65] sm:text-2xl lg:text-[28px]">{t("dashboard.heroTitle")}</h2>
            <p className="mt-3 max-w-3xl text-xs leading-7 text-[var(--muted)] sm:text-sm">{t("dashboard.heroDescription")}</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="secondary" onClick={() => { void systemQuery.refetch(); void jobsQuery.refetch(); }}><RefreshCw size={16} /> {t("common.refresh")}</Button>
            <Link to="/analysis/new"><Button className="px-5 py-3"><Play size={17} fill="currentColor" /> {t("dashboard.startNew")}</Button></Link>
          </div>
        </div>
      </section>

      <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 2xl:grid-cols-4">
        <StatCard title={t("dashboard.gpuStatus")} value={system?.gpu_name ?? t("common.unavailable")} caption={t("dashboard.currentUsage", { value: Math.round(system?.gpu_usage_percent ?? 0) })} icon={<Cpu size={19} />} trend={system?.gpu_name ? t("common.online") : undefined} />
        <StatCard title={t("dashboard.targetSpeed")} value={selectedProfile === "fast" ? "17–28 FPS" : selectedProfile === "balanced" ? "10–18 FPS" : "4–9 FPS"} caption={t("dashboard.profileCaption", { profile: profileName(selectedProfile) })} icon={<Gauge size={19} />} trend={t("processing.live")} />
        <StatCard title={t("dashboard.completedJobs")} value={formatNumber(completedJobs)} caption={t("dashboard.currentSession")} icon={<Users size={19} />} />
        <StatCard title={t("dashboard.activeProcessing")} value={formatNumber(activeJobs)} caption={t("dashboard.localQueue")} icon={<Clock3 size={19} />} />
      </section>

      <section className="grid grid-cols-1 gap-4 2xl:grid-cols-[1.55fr_1fr]">
        <Card>
          <CardHeader title={<span className="flex items-center gap-2"><Activity size={17} className="text-[#33d3bb]" /> {t("dashboard.performance")}</span>} description={t("dashboard.estimated24h")} action={<Badge tone="gray">24H</Badge>} />
          <div className="p-3"><ReactECharts option={chartOption} style={{ height: 280 }} /></div>
        </Card>
        <Card>
          <CardHeader title={t("dashboard.engineHealth")} description={t("dashboard.servicesStatus")} action={<Badge tone={systemQuery.isSuccess ? "green" : "red"} dot>{systemQuery.isSuccess ? t("dashboard.healthy") : t("common.offline")}</Badge>} />
          <div className="space-y-4 p-5">
            {[
              [t("dashboard.inferenceBackend"), system?.inference_backend ?? t("common.unavailable")],
              [t("common.model"), system?.model_name ?? t("common.missing")],
              [t("dashboard.tracking"), system?.tracking_ready ? t("dashboard.byteTrackReady") : t("dashboard.dependencyMissing")],
              [t("dashboard.videoEngine"), system?.video_engine_ready ? t("dashboard.openCvReady") : t("dashboard.openCvMissing")],
              [t("dashboard.platform"), system?.platform ?? "—"],
            ].map(([label, value]) => <div key={label} className="flex items-center justify-between gap-4 border-b border-[var(--border)] pb-3 text-xs last:border-0 last:pb-0"><span className="text-[var(--muted)]">{label}</span><span className="max-w-[55%] truncate font-bold text-[var(--text)]" dir="auto">{value}</span></div>)}
          </div>
        </Card>
      </section>

      <section>
        <div className="mb-4 flex flex-col justify-between gap-3 sm:flex-row sm:items-end"><div><h3 className="text-base font-black">{t("dashboard.inferenceProfiles")}</h3><p className="mt-1 text-xs text-[var(--muted-2)]">{t("dashboard.profileDescription")}</p></div><Link to="/profiles" className="flex items-center gap-1 text-xs font-bold text-[#56dac7]">{t("dashboard.manageProfiles")} <ManageIcon size={14} /></Link></div>
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3"><ProfileCard kind="fast" selected={selectedProfile === "fast"} onClick={() => setSelectedProfile("fast")} /><ProfileCard kind="balanced" selected={selectedProfile === "balanced"} onClick={() => setSelectedProfile("balanced")} /><ProfileCard kind="accuracy" selected={selectedProfile === "accuracy"} onClick={() => setSelectedProfile("accuracy")} /></div>
      </section>

      <section className="grid grid-cols-1 gap-4 2xl:grid-cols-[1.45fr_1fr]">
        <Card>
          <CardHeader title={t("dashboard.recentJobs")} description={t("dashboard.recentDescription")} action={<Link to="/results"><Button variant="ghost" className="px-2 py-1 text-xs">{t("dashboard.viewAll")}</Button></Link>} />
          <div className="divide-y divide-[var(--border)] px-5">
            {recentJobs.length > 0 ? recentJobs.map((job) => (
              <div className="flex items-center justify-between gap-3 py-4" key={job.id}>
                <div className="flex min-w-0 items-center gap-3"><div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-white/[.045] text-[var(--muted)]"><FileVideo2 size={18}/></div><div className="min-w-0"><div className="truncate text-xs font-bold" dir="auto">{job.source_name || job.source_path || job.id}</div><div className="mt-1 text-[10px] text-[var(--muted-2)]" dir="ltr">{profileName(job.profile)} · {job.fps.toFixed(1)} FPS · {job.progress.toFixed(0)}%</div></div></div>
                <Badge tone={job.status === "completed" ? "green" : job.status === "running" ? "blue" : job.status === "failed" ? "red" : "gray"}>{jobStatus(job.status)}</Badge>
              </div>
            )) : <div className="py-10 text-center text-xs text-[var(--muted)]">{t("dashboard.noJobs")}</div>}
          </div>
        </Card>
        <Card>
          <CardHeader title={t("dashboard.resources")} description={t("dashboard.resourcesDescription")} />
          <div className="space-y-6 p-5">
            <ResourceMeter label="GPU" value={system?.gpu_usage_percent ?? 0} detail={system?.gpu_name ?? "—"} />
            <ResourceMeter label="VRAM" value={system?.vram_total_mb ? ((system.vram_used_mb ?? 0) / system.vram_total_mb) * 100 : 0} detail={system?.vram_total_mb ? `${Math.round(system.vram_used_mb ?? 0)} / ${Math.round(system.vram_total_mb)} MB` : "—"} />
            <ResourceMeter label="RAM" value={system?.memory_percent ?? 0} />
            <ResourceMeter label="CPU" value={system?.cpu_percent ?? 0} />
          </div>
        </Card>
      </section>
    </motion.div>
  );
}
