import { Save, ShieldCheck } from "lucide-react";
import { ProfileCard } from "@/components/ProfileCard";
import { Card, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Badge } from "@/components/ui/Badge";
import { PageHeader } from "@/components/PageHeader";
import { useAppStore } from "@/stores/app-store";
import { useI18n } from "@/hooks/use-i18n";

export function ProfilesPage() {
  const profile = useAppStore((state) => state.selectedProfile);
  const setProfile = useAppStore((state) => state.setSelectedProfile);
  const { t, profileName } = useI18n();
  const values = {
    fast: { maxTiles: "0", refresh: "—", overlap: "20%", tiling: t("profiles.off"), target: t("profiles.realTime") },
    balanced: { maxTiles: "2", refresh: t("profiles.refreshFrames", { count: 6 }), overlap: "20%", tiling: t("profiles.adaptive"), target: t("profiles.production") },
    accuracy: { maxTiles: "6", refresh: t("profiles.refreshFrames", { count: 1 }), overlap: "25%", tiling: t("profiles.extensive"), target: t("profiles.offlineAnalysis") },
  }[profile];
  return (
    <div className="space-y-6">
      <PageHeader eyebrow={t("profiles.eyebrow")} title={t("profiles.title")} description={t("profiles.description")} actions={<><Badge tone="green"><ShieldCheck size={12}/> {t("profiles.sameModel")}</Badge><Button disabled title={t("common.comingSoon")}><Save size={15}/> {t("profiles.customSave")}</Button></>} />
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3"><ProfileCard kind="fast" selected={profile === "fast"} onClick={() => setProfile("fast")}/><ProfileCard kind="balanced" selected={profile === "balanced"} onClick={() => setProfile("balanced")}/><ProfileCard kind="accuracy" selected={profile === "accuracy"} onClick={() => setProfile("accuracy")}/></div>
      <Card><CardHeader title={t("profiles.parameters", { profile: profileName(profile) })} description={t("profiles.defaults")} /><div className="grid grid-cols-2 gap-4 p-5 sm:grid-cols-3 xl:grid-cols-5">{[["Full image","1280"],["Tile image","960"],["Max tiles",values.maxTiles],["Refresh",values.refresh],["Overlap",values.overlap],["Tiling",values.tiling],["Tracker","ByteTrack"],["Precision","FP16"],["Model","YOLO26m-P2"],["Target",values.target]].map(([label,value])=><div key={label} className="rounded-xl border border-[var(--border)] bg-white/[.025] p-4"><div className="text-[10px] text-[var(--muted-2)]">{label}</div><div className="mt-2 text-xs font-black" dir="auto">{value}</div></div>)}</div></Card>
      <Card><CardHeader title={t("profiles.guide")} /><div className="grid grid-cols-1 gap-4 p-5 md:grid-cols-3"><div className="rounded-xl bg-[#33d3bb]/6 p-4 text-xs leading-7 text-[var(--muted)]"><strong className="text-[var(--text)]">{t("profile.fastTitle")}:</strong> {t("profiles.fastGuide")}</div><div className="rounded-xl bg-[#7d8dff]/7 p-4 text-xs leading-7 text-[var(--muted)]"><strong className="text-[var(--text)]">{t("profile.balancedTitle")}:</strong> {t("profiles.balancedGuide")}</div><div className="rounded-xl bg-[#f6bd58]/7 p-4 text-xs leading-7 text-[var(--muted)]"><strong className="text-[var(--text)]">{t("profile.accuracyTitle")}:</strong> {t("profiles.accuracyGuide")}</div></div></Card>
    </div>
  );
}
