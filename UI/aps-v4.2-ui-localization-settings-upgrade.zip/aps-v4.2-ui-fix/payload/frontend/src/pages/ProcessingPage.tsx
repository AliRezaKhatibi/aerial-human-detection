import {
  Activity,
  CircleAlert,
  Download,
  FileJson,
  FileSpreadsheet,
  Maximize2,
  Minimize2,
  Radio,
  Square,
  Users,
  Video,
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Card, CardHeader } from "@/components/ui/Card";
import { ProgressBar } from "@/components/ui/ProgressBar";
import { PageHeader } from "@/components/PageHeader";
import { useJobSocket } from "@/hooks/use-job-socket";
import { api } from "@/lib/api";
import { useI18n } from "@/hooks/use-i18n";
import { useAppStore } from "@/stores/app-store";

export function ProcessingPage() {
  const { jobId } = useParams();
  const { job: socketJob, connected } = useJobSocket(jobId);
  const { t, jobStatus, profileName, formatNumber } = useI18n();
  const notificationsEnabled = useAppStore((state) => state.preferences.notifications);
  const previewRef = useRef<HTMLDivElement>(null);
  const notifiedRef = useRef(false);
  const [fullscreen, setFullscreen] = useState(false);
  const jobQuery = useQuery({
    queryKey: ["job", jobId],
    queryFn: () => api.job(jobId as string),
    enabled: Boolean(jobId),
    refetchInterval: socketJob ? false : 2000,
    retry: 1,
  });
  const job = socketJob ?? jobQuery.data ?? null;
  const progress = job?.progress ?? 0;
  const completed = job?.status === "completed";
  const failed = job?.status === "failed";
  const running = job?.status === "running" || job?.status === "queued";

  useEffect(() => {
    const onFullscreenChange = () => setFullscreen(document.fullscreenElement === previewRef.current);
    document.addEventListener("fullscreenchange", onFullscreenChange);
    return () => document.removeEventListener("fullscreenchange", onFullscreenChange);
  }, []);

  useEffect(() => {
    if (!completed || !notificationsEnabled || notifiedRef.current || !("Notification" in window)) return;
    if (Notification.permission === "granted") {
      notifiedRef.current = true;
      new Notification(t("processing.notificationTitle"), {
        body: t("processing.notificationBody", { name: job?.source_name ?? job?.source_path ?? jobId ?? "video" }),
      });
    }
  }, [completed, job?.source_name, job?.source_path, jobId, notificationsEnabled, t]);

  const toggleFullscreen = async () => {
    if (!previewRef.current) return;
    if (document.fullscreenElement) await document.exitFullscreen();
    else await previewRef.current.requestFullscreen();
  };

  const telemetry = useMemo(
    () => [
      { label: "FPS", value: (job?.fps ?? 0).toFixed(1), caption: t("processing.speedCaption") },
      { label: "Inference", value: `${(job?.inference_ms ?? 0).toFixed(1)} ms`, caption: t("processing.inferenceCaption") },
      { label: t("processing.activePeople"), value: formatNumber(job?.active_tracks ?? 0), caption: t("processing.currentFrame") },
      { label: t("processing.uniquePeople"), value: formatNumber(job?.unique_tracks ?? 0), caption: t("processing.sinceStart") },
      { label: "Confidence", value: `${Math.round((job?.mean_confidence ?? 0) * 100)}%`, caption: t("processing.confidenceCaption") },
      { label: "Tile", value: formatNumber(job?.processed_tiles ?? 0), caption: job?.tiling_active ? t("processing.tileCurrent") : t("processing.fullFrame") },
    ],
    [formatNumber, job, t],
  );

  if (!jobId) {
    return (
      <div className="space-y-6">
        <PageHeader title={t("topbar.processing")} description={t("processing.noJobDescription")} />
        <Card className="grid min-h-[420px] place-items-center p-8 text-center"><div><Radio size={40} className="mx-auto text-[#33d3bb]" /><h3 className="mt-5 text-lg font-black">{t("processing.noActiveJob")}</h3><p className="mt-2 text-xs text-[var(--muted)]">{t("processing.chooseVideo")}</p><Link to="/analysis/new"><Button className="mt-6">{t("processing.createNew")}</Button></Link></div></Card>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <PageHeader
        eyebrow={t("processing.eyebrow")}
        title={completed ? t("processing.titleCompleted") : failed ? t("processing.titleFailed") : t("processing.titleLive")}
        description={<span dir="auto">{job?.source_name ?? t("analysis.videoFile")} · <span dir="ltr">Job ID: {jobId}</span></span>}
        actions={
          <>
            <Badge tone={connected ? "green" : "amber"} dot>{connected ? t("processing.websocketConnected") : t("processing.websocketConnecting")}</Badge>
            <Badge tone={job?.profile === "accuracy" ? "amber" : job?.profile === "fast" ? "blue" : "green"}>{profileName(job?.profile)}</Badge>
            <Badge tone={completed ? "green" : failed ? "red" : "gray"}>{jobStatus(job?.status)}</Badge>
          </>
        }
      />

      {failed && job?.error && (
        <div className="flex items-start gap-3 rounded-2xl border border-[#ff6c85]/25 bg-[#ff6c85]/8 p-4 text-xs leading-6 text-[#ff9bad]" role="alert"><CircleAlert className="mt-0.5 shrink-0" size={18} /><div><div className="font-black">{t("processing.engineError")}</div><div className="mt-1" dir="auto">{job.error}</div></div></div>
      )}

      <div className="grid grid-cols-1 gap-4 2xl:grid-cols-[1fr_340px]">
        <Card className="overflow-hidden">
          <div ref={previewRef} className="relative aspect-video min-h-[360px] bg-[#03060a] metric-grid lg:min-h-[520px]">
            {completed && job?.output_video_path ? (
              <video controls className="h-full w-full object-contain" src={api.outputUrl(jobId)} />
            ) : job?.preview_available ? (
              <img
                key={job.frame}
                src={api.previewUrl(jobId, job.frame)}
                alt={t("processing.previewAlt")}
                className="h-full w-full object-contain"
              />
            ) : (
              <div className="absolute inset-0 grid place-items-center p-6"><div className="text-center"><div className="mx-auto grid h-16 w-16 place-items-center rounded-full border border-[#33d3bb]/22 bg-[#33d3bb]/8"><Radio className="animate-pulse text-[#33d3bb]" size={30} /></div><div className="mt-5 text-sm font-bold">{t("processing.waitingFrame")}</div><div className="mt-2 text-xs leading-6 text-[var(--muted-2)]">{t("processing.warmupNote")}</div></div></div>
            )}
            <div className="absolute start-4 top-4 flex gap-2"><Badge tone={running ? "red" : "gray"} dot>{running ? t("processing.live") : completed ? t("processing.done") : t("processing.stopped")}</Badge><Badge tone="gray"><span dir="ltr">{job?.model_name ?? t("processing.modelLoading")}</span></Badge></div>
            <div className="absolute end-4 top-4"><Badge tone={job?.tiling_active ? "green" : "gray"}>{job?.tiling_active ? `ATTI · ${job.processed_tiles} Tile` : t("processing.fullFrame")}</Badge></div>
            <Button variant="ghost" className="absolute bottom-4 start-4 h-10 w-10 bg-black/25 p-0" onClick={() => void toggleFullscreen()} title={fullscreen ? t("processing.exitFullscreen") : t("processing.fullscreen")} aria-label={fullscreen ? t("processing.exitFullscreen") : t("processing.fullscreen")}>{fullscreen ? <Minimize2 size={18} /> : <Maximize2 size={18} />}</Button>
          </div>
          <div className="flex flex-col justify-between gap-3 border-t border-[var(--border)] px-5 py-4 sm:flex-row sm:items-center">
            <div className="flex flex-wrap gap-2">
              {running && <Button variant="danger" onClick={() => void api.cancelJob(jobId)}><Square size={15} /> {t("processing.stop")}</Button>}
              {completed && job?.output_video_path && <a href={api.outputUrl(jobId)} download><Button><Video size={16} /> {t("processing.downloadVideo")}</Button></a>}
              {completed && job?.report_csv_path && <a href={api.csvUrl(jobId)} download><Button variant="secondary"><FileSpreadsheet size={16} /> CSV</Button></a>}
              {completed && job?.report_json_path && <a href={api.jsonUrl(jobId)} download><Button variant="secondary"><FileJson size={16} /> JSON</Button></a>}
            </div>
            <div className="text-xs text-[var(--muted)]" dir="ltr">{t("common.frame")} {formatNumber(job?.frame ?? 0)} / {formatNumber(job?.total_frames ?? 0)}</div>
          </div>
        </Card>

        <div className="grid grid-cols-2 gap-3 2xl:grid-cols-1">
          {telemetry.map((item, index) => (
            <Card key={item.label} className="p-4"><div className="flex items-start justify-between"><div><div className="text-[10px] font-semibold text-[var(--muted-2)]">{item.label}</div><div className="mt-1 text-xl font-black" dir="ltr">{item.value}</div><div className="mt-1 text-[10px] text-[var(--muted-2)]">{item.caption}</div></div>{index >= 2 ? <Users size={18} className="text-[#33d3bb]" /> : <Activity size={18} className="text-[#7d8dff]" />}</div></Card>
          ))}
        </div>
      </div>

      <Card>
        <CardHeader title={t("processing.progress")} description={job?.status ? `${t("common.status")}: ${jobStatus(job.status)}` : t("processing.waitingData")} action={<span className="text-sm font-black" dir="ltr">{progress.toFixed(1)}%</span>} />
        <div className="p-5">
          <ProgressBar value={progress} className="h-2.5" />
          <div className="mt-3 flex justify-between text-[10px] text-[var(--muted-2)]"><span>{t("processing.started")}</span><span>{completed ? t("processing.completed") : failed ? t("processing.failed") : t("processing.running")}</span><span dir="ltr">{(job?.elapsed_seconds ?? 0).toFixed(1)} s</span></div>
        </div>
      </Card>

      {completed && (
        <Card className="p-5"><div className="flex flex-col justify-between gap-4 md:flex-row md:items-center"><div><div className="flex items-center gap-2 text-sm font-black"><Download size={18} className="text-[#33d3bb]" /> {t("processing.outputsReady")}</div><p className="mt-2 text-xs leading-6 text-[var(--muted)]">{t("processing.outputsDescription")}</p></div><Link to="/analysis/new"><Button variant="secondary">{t("processing.analyzeAnother")}</Button></Link></div></Card>
      )}
    </div>
  );
}
