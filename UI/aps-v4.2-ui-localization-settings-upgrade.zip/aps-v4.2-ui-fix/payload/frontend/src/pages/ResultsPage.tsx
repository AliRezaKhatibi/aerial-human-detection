import { Download, Eye, FileBarChart, FileJson, FileVideo2, Search, SlidersHorizontal } from "lucide-react";
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { PageHeader } from "@/components/PageHeader";
import { ProgressBar } from "@/components/ui/ProgressBar";
import { api } from "@/lib/api";
import { useI18n } from "@/hooks/use-i18n";

export function ResultsPage() {
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState("all");
  const { t, jobStatus, profileName, formatNumber } = useI18n();
  const jobsQuery = useQuery({ queryKey: ["jobs-results"], queryFn: api.jobs, refetchInterval: 4000, retry: 1 });
  const jobs = useMemo(() => (jobsQuery.data ?? []).filter((job) => {
    const source = job.source_name ?? job.source_path;
    const matchesQuery = source.toLowerCase().includes(query.toLowerCase()) || job.id.includes(query);
    const matchesStatus = status === "all" || job.status === status;
    return matchesQuery && matchesStatus;
  }), [jobsQuery.data, query, status]);

  return (
    <div className="space-y-6">
      <PageHeader eyebrow={t("results.eyebrow")} title={t("results.title")} description={t("results.description")} actions={<Button variant="secondary" disabled title={t("common.comingSoon")}><Download size={15}/> {t("results.fullExport")}</Button>} />

      <Card>
        <div className="flex flex-col justify-between gap-3 border-b border-[var(--border)] p-4 lg:flex-row lg:items-center">
          <div className="flex min-w-0 flex-1 items-center gap-2 rounded-xl border border-[var(--border)] bg-white/[.025] px-3 py-2.5"><Search size={16} className="text-[var(--muted-2)]"/><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder={t("results.searchPlaceholder")} className="min-w-0 flex-1 bg-transparent text-xs outline-none"/></div>
          <div className="flex gap-2"><label className="flex items-center gap-2 rounded-xl border border-[var(--border)] bg-white/[.025] px-3 py-2.5"><SlidersHorizontal size={15} className="text-[var(--muted-2)]"/><select value={status} onChange={(event) => setStatus(event.target.value)} className="bg-transparent text-xs outline-none"><option value="all">{t("results.allStatuses")}</option><option value="queued">{jobStatus("queued")}</option><option value="running">{jobStatus("running")}</option><option value="completed">{jobStatus("completed")}</option><option value="failed">{jobStatus("failed")}</option><option value="cancelled">{jobStatus("cancelled")}</option></select></label></div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[780px] text-start text-xs">
            <thead className="text-[10px] uppercase tracking-wide text-[var(--muted-2)]"><tr className="border-b border-[var(--border)]"><th className="px-5 py-4 font-semibold">{t("results.source")}</th><th className="px-5 py-4 font-semibold">{t("results.profile")}</th><th className="px-5 py-4 font-semibold">{t("common.status")}</th><th className="px-5 py-4 font-semibold">{t("results.progress")}</th><th className="px-5 py-4 font-semibold">FPS</th><th className="px-5 py-4 font-semibold">{t("results.tracks")}</th><th className="px-5 py-4 font-semibold">{t("results.actions")}</th></tr></thead>
            <tbody className="divide-y divide-[var(--border)]">
              {jobs.map((job) => <tr key={job.id} className="transition hover:bg-white/[.025]"><td className="px-5 py-4"><div className="flex items-center gap-3"><div className="grid h-9 w-9 place-items-center rounded-xl bg-white/[.045]"><FileVideo2 size={17}/></div><div><div className="max-w-[220px] truncate font-bold" dir="auto">{job.source_name ?? job.source_path}</div><div className="mt-1 max-w-[180px] truncate text-[10px] text-[var(--muted-2)]" dir="ltr">{job.id}</div></div></div></td><td className="px-5 py-4"><Badge tone="blue">{profileName(job.profile)}</Badge></td><td className="px-5 py-4"><Badge tone={job.status === "completed" ? "green" : job.status === "running" ? "blue" : job.status === "failed" ? "red" : "gray"} dot>{jobStatus(job.status)}</Badge></td><td className="px-5 py-4"><div className="w-28"><div className="mb-1 text-[10px] text-[var(--muted-2)]" dir="ltr">{job.progress.toFixed(0)}%</div><ProgressBar value={job.progress} className="h-1.5"/></div></td><td className="px-5 py-4 font-bold" dir="ltr">{job.fps.toFixed(1)}</td><td className="px-5 py-4">{formatNumber(job.unique_tracks)}</td><td className="px-5 py-4"><Link to={`/processing/${job.id}`}><Button variant="ghost" className="h-9 px-3"><Eye size={15}/> {t("common.view")}</Button></Link></td></tr>)}
            </tbody>
          </table>
          {jobs.length === 0 && <div className="py-14 text-center text-xs text-[var(--muted)]">{t("results.noResult")}</div>}
        </div>
      </Card>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="p-5"><FileBarChart className="text-[#33d3bb]"/><h3 className="mt-4 text-sm font-black">{t("results.analyticalReport")}</h3><p className="mt-2 text-xs leading-6 text-[var(--muted)]">{t("results.analyticalDescription")}</p><div className="mt-4"><Badge tone="gray">{t("results.modelIntegration")}</Badge></div></Card>
        <Card className="p-5"><FileJson className="text-[#8e9aff]"/><h3 className="mt-4 text-sm font-black">{t("results.structuredData")}</h3><p className="mt-2 text-xs leading-6 text-[var(--muted)]">{t("results.structuredDescription")}</p></Card>
        <Card className="p-5"><FileVideo2 className="text-[#f6bd58]"/><h3 className="mt-4 text-sm font-black">{t("results.annotatedVideo")}</h3><p className="mt-2 text-xs leading-6 text-[var(--muted)]">{t("results.annotatedDescription")}</p></Card>
      </div>
    </div>
  );
}
