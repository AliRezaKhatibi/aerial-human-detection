import { CheckCircle2, Clipboard, RotateCcw, Save, ShieldAlert } from "lucide-react";
import { useMemo, useState } from "react";
import { PageHeader } from "@/components/PageHeader";
import { Card, CardHeader } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Badge } from "@/components/ui/Badge";
import { Toggle } from "@/components/ui/Toggle";
import {
  DEFAULT_PREFERENCES,
  useAppStore,
  type AppPreferences,
  type Locale,
  type Theme,
} from "@/stores/app-store";
import { useI18n } from "@/hooks/use-i18n";
import { translate } from "@/i18n/translations";

type NoticeTone = "success" | "warning" | "neutral";
interface NoticeState { message: string; tone: NoticeTone; }
interface SettingsDraft { locale: Locale; theme: Theme; preferences: AppPreferences; }

const runtimePaths = [
  { key: "settings.outputFolder", value: "runtime/outputs" },
  { key: "settings.reportsFolder", value: "runtime/reports" },
  { key: "settings.modelPath", value: "models/best.pt" },
];

export function SettingsPage() {
  const locale = useAppStore((state) => state.locale);
  const theme = useAppStore((state) => state.theme);
  const preferences = useAppStore((state) => state.preferences);
  const setLocale = useAppStore((state) => state.setLocale);
  const setTheme = useAppStore((state) => state.setTheme);
  const setPreferences = useAppStore((state) => state.setPreferences);
  const { t } = useI18n();
  const [draft, setDraft] = useState<SettingsDraft>({ locale, theme, preferences: { ...preferences } });
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState<NoticeState | null>(null);

  const savedSnapshot = useMemo(() => JSON.stringify({ locale, theme, preferences }), [locale, preferences, theme]);
  const draftSnapshot = useMemo(() => JSON.stringify(draft), [draft]);
  const dirty = savedSnapshot !== draftSnapshot;

  const updatePreference = <K extends keyof AppPreferences>(key: K, value: AppPreferences[K]) => {
    setDraft((current) => ({ ...current, preferences: { ...current.preferences, [key]: value } }));
    setNotice(null);
  };

  const saveSettings = async () => {
    setSaving(true);
    setNotice(null);
    try {
      let nextPreferences = { ...draft.preferences };
      let permissionWarning: string | null = null;

      if (nextPreferences.notifications) {
        if (!("Notification" in window)) {
          nextPreferences.notifications = false;
          permissionWarning = translate(draft.locale, "common.browserUnsupported");
        } else if (Notification.permission === "default") {
          const permission = await Notification.requestPermission();
          if (permission !== "granted") {
            nextPreferences.notifications = false;
            permissionWarning = translate(draft.locale, "common.permissionDenied");
          }
        } else if (Notification.permission === "denied") {
          nextPreferences.notifications = false;
          permissionWarning = translate(draft.locale, "common.permissionDenied");
        }
      }

      setLocale(draft.locale);
      setTheme(draft.theme);
      setPreferences(nextPreferences);
      setDraft({ ...draft, preferences: nextPreferences });
      setNotice(permissionWarning ? { message: permissionWarning, tone: "warning" } : { message: dirty ? translate(draft.locale, "common.settingsSaved") : translate(draft.locale, "common.noChanges"), tone: dirty ? "success" : "neutral" });
    } catch {
      setNotice({ message: t("common.saveFailed"), tone: "warning" });
    } finally {
      setSaving(false);
    }
  };

  const restoreDefaults = () => {
    const defaults: SettingsDraft = { locale: "fa", theme: "dark", preferences: { ...DEFAULT_PREFERENCES } };
    setLocale(defaults.locale);
    setTheme(defaults.theme);
    setPreferences(defaults.preferences);
    setDraft(defaults);
    setNotice({ message: translate("fa", "common.defaultsRestored"), tone: "success" });
  };

  const copyPath = async (path: string) => {
    try {
      await navigator.clipboard.writeText(path);
      setNotice({ message: `${t("common.copied")}: ${path}`, tone: "neutral" });
    } catch {
      setNotice({ message: path, tone: "neutral" });
    }
  };

  const noticeClasses = notice?.tone === "success"
    ? "border-[#49d6a5]/25 bg-[#49d6a5]/8 text-[#72e2b8]"
    : notice?.tone === "warning"
      ? "border-[#f6bd58]/25 bg-[#f6bd58]/8 text-[#f6ca78]"
      : "border-[#7d8dff]/22 bg-[#7d8dff]/8 text-[#aab2ff]";

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow={t("settings.eyebrow")}
        title={t("settings.title")}
        description={t("settings.description")}
        actions={
          <>
            <Button variant="ghost" onClick={restoreDefaults}><RotateCcw size={15}/> {t("settings.reset")}</Button>
            <Button onClick={() => void saveSettings()} loading={saving}><Save size={15}/> {t("settings.save")}</Button>
          </>
        }
      />

      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[var(--border)] bg-white/[.025] px-4 py-3 text-xs">
        <div className="flex items-center gap-2 text-[var(--muted)]">
          {dirty ? <ShieldAlert size={16} className="text-[#f6bd58]" /> : <CheckCircle2 size={16} className="text-[#49d6a5]" />}
          {dirty ? t("settings.unsaved") : t("settings.saved")}
        </div>
        <Badge tone={dirty ? "amber" : "green"}>{dirty ? t("common.status") : t("settings.saved")}</Badge>
      </div>

      {notice && (
        <div role="status" aria-live="polite" className={`rounded-2xl border px-4 py-3 text-xs font-semibold ${noticeClasses}`}>
          {notice.message}
        </div>
      )}

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        <Card>
          <CardHeader title={t("settings.interface")} description={t("settings.interfaceDescription")} />
          <div className="space-y-5 p-5">
            <label className="block" htmlFor="settings-language">
              <div className="mb-2 text-xs font-bold">{t("settings.language")}</div>
              <select
                id="settings-language"
                value={draft.locale}
                onChange={(event) => { setDraft((current) => ({ ...current, locale: event.target.value as Locale })); setNotice(null); }}
                className="focus-ring w-full rounded-xl border border-[var(--border)] bg-[var(--panel-strong)] px-3 py-3 text-xs outline-none"
              >
                <option value="fa">{t("settings.persian")}</option>
                <option value="en">{t("settings.english")}</option>
              </select>
            </label>
            <label className="block" htmlFor="settings-theme">
              <div className="mb-2 text-xs font-bold">{t("settings.theme")}</div>
              <select
                id="settings-theme"
                value={draft.theme}
                onChange={(event) => { setDraft((current) => ({ ...current, theme: event.target.value as Theme })); setNotice(null); }}
                className="focus-ring w-full rounded-xl border border-[var(--border)] bg-[var(--panel-strong)] px-3 py-3 text-xs outline-none"
              >
                <option value="dark">{t("settings.dark")}</option>
                <option value="light">{t("settings.light")}</option>
              </select>
            </label>
            <div className="flex items-center justify-between rounded-xl border border-[var(--border)] bg-white/[.025] p-4">
              <div><div className="text-xs font-bold">{t("settings.completionNotification")}</div><div className="mt-1 text-[10px] text-[var(--muted-2)]">{t("settings.completionNotificationDescription")}</div></div>
              <Toggle checked={draft.preferences.notifications} onChange={(value) => updatePreference("notifications", value)} label={t("settings.completionNotification")} />
            </div>
          </div>
        </Card>

        <Card>
          <CardHeader title={t("settings.defaultAnalysis")} description={t("settings.defaultAnalysisDescription")} />
          <div className="space-y-4 p-5">
            <label className="block rounded-xl border border-[var(--border)] bg-white/[.025] p-4">
              <div className="flex items-center justify-between text-xs"><span className="font-bold">{t("settings.defaultConfidence")}</span><span dir="ltr" className="font-mono text-[#5cdbc8]">{draft.preferences.defaultConfidence.toFixed(2)}</span></div>
              <input type="range" min="0.05" max="0.7" step="0.01" value={draft.preferences.defaultConfidence} onChange={(event) => updatePreference("defaultConfidence", Number(event.target.value))} className="mt-4 w-full accent-[#33d3bb]" />
            </label>
            {[
              ["autoSaveVideo", t("settings.autoSaveVideo"), t("settings.autoSaveVideoDescription")],
              ["showTrackIds", t("settings.showTrackId"), t("settings.showTrackIdDescription")],
              ["showConfidence", t("settings.showConfidence"), t("settings.showConfidenceDescription")],
              ["showTrails", t("settings.showTrails"), t("settings.showTrailsDescription")],
            ].map(([key, title, description]) => (
              <div key={key} className="flex items-center justify-between border-b border-[var(--border)] pb-4 last:border-0 last:pb-0">
                <div><div className="text-xs font-bold">{title}</div><div className="mt-1 text-[10px] text-[var(--muted-2)]">{description}</div></div>
                <Toggle checked={Boolean(draft.preferences[key as keyof AppPreferences])} onChange={(value) => updatePreference(key as "autoSaveVideo" | "showTrackIds" | "showConfidence" | "showTrails", value)} label={title} />
              </div>
            ))}
            <label className="block" htmlFor="settings-report-format">
              <div className="mb-2 text-xs font-bold">{t("settings.reportFormat")}</div>
              <select id="settings-report-format" value={draft.preferences.reportFormat} onChange={(event) => updatePreference("reportFormat", event.target.value as AppPreferences["reportFormat"])} className="focus-ring w-full rounded-xl border border-[var(--border)] bg-[var(--panel-strong)] px-3 py-3 text-xs outline-none">
                <option value="csv-json">{t("settings.csvJson")}</option>
                <option value="csv">{t("settings.csvOnly")}</option>
                <option value="json">{t("settings.jsonOnly")}</option>
              </select>
            </label>
          </div>
        </Card>

        <Card>
          <CardHeader title={t("settings.paths")} description={t("settings.pathsDescription")} action={<Badge tone="gray">{t("settings.runtimeManaged")}</Badge>} />
          <div className="space-y-4 p-5">
            {runtimePaths.map(({ key, value }) => (
              <div key={key}>
                <div className="mb-2 flex items-center justify-between text-xs font-bold"><span>{t(key)}</span><span className="text-[9px] font-normal text-[var(--muted-2)]">{t("common.readOnly")}</span></div>
                <div className="flex gap-2">
                  <input value={value} readOnly dir="ltr" className="min-w-0 flex-1 rounded-xl border border-[var(--border)] bg-white/[.025] px-3 py-3 text-xs outline-none" />
                  <Button variant="secondary" onClick={() => void copyPath(value)} title={t("common.copy")} aria-label={t("common.copy")}><Clipboard size={16}/></Button>
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <CardHeader title={t("settings.encoder")} description={t("settings.encoderDescription")} action={<Badge tone="gray">{t("settings.engineControlled")}</Badge>} />
          <div className="grid grid-cols-1 gap-4 p-5 sm:grid-cols-2">
            <label><div className="mb-2 text-xs font-bold">{t("settings.codec")}</div><select disabled className="w-full rounded-xl border border-[var(--border)] bg-[var(--panel-strong)] px-3 py-3 text-xs opacity-60"><option>Auto (OpenCV)</option></select></label>
            <label><div className="mb-2 text-xs font-bold">{t("settings.quality")}</div><select disabled className="w-full rounded-xl border border-[var(--border)] bg-[var(--panel-strong)] px-3 py-3 text-xs opacity-60"><option>Engine default</option></select></label>
            <label><div className="mb-2 text-xs font-bold">{t("settings.logLevel")}</div><select disabled className="w-full rounded-xl border border-[var(--border)] bg-[var(--panel-strong)] px-3 py-3 text-xs opacity-60"><option>INFO</option></select></label>
          </div>
        </Card>
      </div>
    </div>
  );
}
