import {
  Camera,
  CheckCircle2,
  CircleAlert,
  Cpu,
  FileCheck2,
  FileVideo2,
  FolderOpen,
  Gauge,
  HardDrive,
  Info,
  Radio,
  SlidersHorizontal,
  Sparkles,
  UploadCloud,
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ProfileCard } from "@/components/ProfileCard";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/Button";
import { Card, CardHeader } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Toggle } from "@/components/ui/Toggle";
import { api } from "@/lib/api";
import { useAppStore, type InferenceMode } from "@/stores/app-store";
import { useI18n } from "@/hooks/use-i18n";
import type { VideoMetadata } from "@/types/api";

function formatDuration(seconds: number) {
  const total = Math.max(0, Math.round(seconds));
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const secs = total % 60;
  return [hours, minutes, secs].map((item) => String(item).padStart(2, "0")).join(":");
}

export function NewAnalysisPage() {
  const selectedProfile = useAppStore((state) => state.selectedProfile);
  const setSelectedProfile = useAppStore((state) => state.setSelectedProfile);
  const preferences = useAppStore((state) => state.preferences);
  const { t, formatNumber } = useI18n();
  const [profile, setProfileLocal] = useState<InferenceMode>(selectedProfile);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [metadata, setMetadata] = useState<VideoMetadata | null>(null);
  const [selectedModelId, setSelectedModelId] = useState("");
  const [confidence, setConfidence] = useState(preferences.defaultConfidence);
  const [showTrails, setShowTrails] = useState(preferences.showTrails);
  const [showTrackIds, setShowTrackIds] = useState(preferences.showTrackIds);
  const [showConfidence, setShowConfidence] = useState(preferences.showConfidence);
  const [saveVideo, setSaveVideo] = useState(preferences.autoSaveVideo);
  const [saveCsv, setSaveCsv] = useState(preferences.reportFormat !== "json");
  const [saveJson, setSaveJson] = useState(preferences.reportFormat !== "csv");
  const [uploading, setUploading] = useState(false);
  const [starting, setStarting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  const systemQuery = useQuery({ queryKey: ["system-preflight"], queryFn: api.system, refetchInterval: 5000, retry: 1 });
  const modelsQuery = useQuery({ queryKey: ["models"], queryFn: api.models, refetchInterval: 5000, retry: 1 });
  const system = systemQuery.data;
  const models = modelsQuery.data?.models ?? [];

  const sourceTypes = useMemo(() => [
    { id: "video", icon: FileVideo2, title: t("analysis.videoFile"), description: "MP4, MOV, MKV, AVI, WEBM", state: t("common.active") },
    { id: "camera", icon: Camera, title: t("analysis.localCamera"), description: t("analysis.localCameraDescription"), state: t("common.comingSoon") },
    { id: "rtsp", icon: Radio, title: t("analysis.rtsp"), description: t("analysis.rtspDescription"), state: t("common.comingSoon") },
  ], [t]);

  useEffect(() => {
    if (!selectedModelId && modelsQuery.data?.selected_model?.id) {
      setSelectedModelId(modelsQuery.data.selected_model.id);
    }
  }, [modelsQuery.data, selectedModelId]);

  const setProfile = (next: InferenceMode) => {
    setProfileLocal(next);
    setSelectedProfile(next);
  };

  const handleFile = async (file: File | null) => {
    setSelectedFile(file);
    setMetadata(null);
    setError(null);
    if (!file) return;
    setUploading(true);
    try {
      const result = await api.uploadVideo(file);
      setMetadata(result);
    } catch (uploadError) {
      setError(uploadError instanceof Error ? uploadError.message : t("analysis.uploadFailed"));
    } finally {
      setUploading(false);
    }
  };

  const preflight = useMemo(
    () => [
      {
        label: t("analysis.backendConnection"),
        detail: systemQuery.isSuccess ? t("analysis.apiAvailable") : t("analysis.backendNoResponse"),
        ready: systemQuery.isSuccess,
        icon: Gauge,
      },
      {
        label: t("analysis.aiEngine"),
        detail: system?.ai_dependencies_ready ? t("analysis.aiReady") : t("analysis.runInstallAi"),
        ready: Boolean(system?.ai_dependencies_ready),
        icon: Sparkles,
      },
      {
        label: t("analysis.trainedModel"),
        detail: modelsQuery.data?.selected_model?.name ?? t("analysis.noModel"),
        ready: Boolean(modelsQuery.data?.available && selectedModelId),
        icon: Cpu,
      },
      {
        label: t("analysis.inputVideo"),
        detail: metadata ? `${metadata.width}×${metadata.height} · ${formatNumber(metadata.total_frames)} ${t("common.frames")}` : t("analysis.videoNotReady"),
        ready: Boolean(metadata),
        icon: FileCheck2,
      },
      {
        label: t("analysis.storage"),
        detail: system ? t("analysis.freeSpace", { value: system.storage_free_gb.toFixed(1) }) : t("analysis.checkingStorage"),
        ready: Boolean(system && system.storage_free_gb > 2),
        icon: HardDrive,
      },
    ],
    [formatNumber, metadata, modelsQuery.data, selectedModelId, system, systemQuery.isSuccess, t],
  );

  const ready = preflight.every((item) => item.ready) && !uploading && !starting;

  const startAnalysis = async () => {
    if (!metadata || !selectedModelId) return;
    setStarting(true);
    setError(null);
    try {
      await api.selectModel(selectedModelId);
      await api.loadModel();
      const job = await api.createJob({
        source_type: "video",
        source_path: metadata.stored_path,
        source_name: metadata.filename,
        profile,
        confidence,
        show_trails: showTrails,
        show_track_ids: showTrackIds,
        show_confidence: showConfidence,
        save_video: saveVideo,
        save_csv: saveCsv,
        save_json: saveJson,
        model_id: selectedModelId,
      });
      navigate(`/processing/${job.id}`);
    } catch (startError) {
      setError(startError instanceof Error ? startError.message : t("analysis.startFailed"));
    } finally {
      setStarting(false);
    }
  };

  const optionCards: Array<[string, string, boolean, (value: boolean) => void]> = [
    [t("analysis.showTrackId"), t("analysis.showTrackIdDescription"), showTrackIds, setShowTrackIds],
    [t("analysis.showConfidence"), t("analysis.showConfidenceDescription"), showConfidence, setShowConfidence],
    [t("analysis.showTrails"), t("analysis.showTrailsDescription"), showTrails, setShowTrails],
    [t("analysis.saveVideo"), t("analysis.saveVideoDescription"), saveVideo, setSaveVideo],
    [t("analysis.csvReport"), t("analysis.csvDescription"), saveCsv, setSaveCsv],
    [t("analysis.jsonReport"), t("analysis.jsonDescription"), saveJson, setSaveJson],
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow={t("analysis.eyebrow")}
        title={t("analysis.title")}
        description={t("analysis.description")}
        actions={
          <Badge tone={system?.ai_dependencies_ready && modelsQuery.data?.available ? "green" : "amber"} dot>
            {system?.ai_dependencies_ready && modelsQuery.data?.available ? t("analysis.ready") : t("analysis.prerequisites")}
          </Badge>
        }
      />

      {error && (
        <div className="flex items-start gap-3 rounded-2xl border border-[#ff6c85]/25 bg-[#ff6c85]/8 p-4 text-xs leading-6 text-[#ff9bad]" role="alert">
          <CircleAlert className="mt-0.5 shrink-0" size={18} />
          <div><div className="font-black">{t("analysis.operationFailed")}</div><div className="mt-1" dir="auto">{error}</div></div>
        </div>
      )}

      <div className="grid grid-cols-1 gap-4 2xl:grid-cols-[1.45fr_0.75fr]">
        <Card className="p-5 sm:p-6">
          <input
            ref={inputRef}
            type="file"
            accept="video/mp4,video/quicktime,video/x-matroska,video/x-msvideo,video/webm"
            className="hidden"
            onChange={(event) => void handleFile(event.target.files?.[0] ?? null)}
          />
          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            onDragOver={(event) => event.preventDefault()}
            onDrop={(event) => {
              event.preventDefault();
              void handleFile(event.dataTransfer.files?.[0] ?? null);
            }}
            className="focus-ring metric-grid grid min-h-[330px] w-full place-items-center rounded-2xl border border-dashed border-[#33d3bb]/28 bg-[#33d3bb]/[.03] p-6 text-center transition hover:border-[#33d3bb]/48 hover:bg-[#33d3bb]/[.055]"
          >
            <div className="w-full max-w-3xl">
              <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-[#33d3bb]/10 text-[#57dec9]">
                <UploadCloud size={28} className={uploading ? "animate-bounce" : ""} />
              </div>
              <h3 className="mt-5 font-black" dir="auto">
                {uploading ? t("analysis.uploading") : selectedFile ? selectedFile.name : t("analysis.dropVideo")}
              </h3>
              <p className="mt-2 text-xs leading-6 text-[var(--muted)]">
                {metadata
                  ? <span dir="ltr">{metadata.size_mb.toFixed(1)} MB · {metadata.width}×{metadata.height} · {metadata.fps.toFixed(2)} FPS · {formatDuration(metadata.duration_seconds)}</span>
                  : selectedFile
                    ? t("analysis.localCheck")
                    : t("analysis.privacy")}
              </p>
              <span className="mt-5 inline-flex items-center gap-2 rounded-xl border border-[var(--border)] bg-white/[.055] px-4 py-2.5 text-sm font-bold">
                <FolderOpen size={16} /> {selectedFile ? t("analysis.changeFile") : t("analysis.chooseFile")}
              </span>

              {metadata && (
                <div className="mt-6 grid grid-cols-2 gap-2 text-start sm:grid-cols-3 lg:grid-cols-6">
                  {[
                    [t("analysis.resolution"), `${metadata.width}×${metadata.height}`],
                    [t("analysis.frameRate"), `${metadata.fps.toFixed(2)} FPS`],
                    [t("analysis.duration"), formatDuration(metadata.duration_seconds)],
                    [t("analysis.frameCount"), formatNumber(metadata.total_frames)],
                    ["Codec", metadata.codec],
                    [t("analysis.size"), `${metadata.size_mb.toFixed(1)} MB`],
                  ].map(([label, value]) => (
                    <div key={label} className="rounded-xl border border-[var(--border)] bg-black/10 p-3">
                      <div className="text-[9px] text-[var(--muted-2)]">{label}</div>
                      <div className="mt-1 truncate text-xs font-black" dir="ltr">{value}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </button>
        </Card>

        <div className="space-y-4">
          <Card>
            <CardHeader title={t("analysis.sourceType")} description={t("analysis.sourceDescription")} />
            <div className="space-y-3 p-5">
              {sourceTypes.map(({ id, icon: Icon, title, description, state }) => (
                <div key={id} aria-current={id === "video" ? "true" : undefined} className={`flex w-full items-center justify-between rounded-xl border p-4 text-start ${id === "video" ? "border-[#33d3bb]/20 bg-[#33d3bb]/[.04]" : "border-[var(--border)] bg-white/[.025] opacity-55"}`}>
                  <div className="flex items-center gap-3"><div className="grid h-10 w-10 place-items-center rounded-xl bg-white/[.045]"><Icon size={18} className="text-[#5adcc9]" /></div><div><div className="text-xs font-bold">{title}</div><div className="mt-1 text-[10px] text-[var(--muted-2)]">{description}</div></div></div>
                  <Badge tone={id === "video" ? "green" : "gray"}>{state}</Badge>
                </div>
              ))}
            </div>
          </Card>

          <Card>
            <CardHeader title={t("analysis.inferenceModel")} description={t("analysis.modelDirectory")} action={<Badge tone={models.length ? "green" : "amber"}>{t("analysis.modelCount", { count: formatNumber(models.length) })}</Badge>} />
            <div className="p-5">
              <label className="text-[10px] font-bold text-[var(--muted)]" htmlFor="analysis-model">{t("analysis.selectedModel")}</label>
              <select
                id="analysis-model"
                value={selectedModelId}
                onChange={(event) => setSelectedModelId(event.target.value)}
                className="focus-ring mt-2 w-full rounded-xl border border-[var(--border)] bg-[var(--panel-strong)] px-3 py-3 text-xs outline-none"
              >
                <option value="">{t("analysis.chooseModel")}</option>
                {models.map((model) => <option value={model.id} key={model.id}>{model.name} · {model.format.toUpperCase()} · {model.size_mb.toFixed(1)} MB</option>)}
              </select>
              <div className="mt-3 flex items-center justify-between text-[10px] text-[var(--muted-2)]"><span>{t("common.backend")}</span><span dir="ltr">{modelsQuery.data?.backend ?? "—"}</span></div>
            </div>
          </Card>
        </div>
      </div>

      <section>
        <div className="mb-4"><h3 className="text-base font-black">{t("analysis.processingProfile")}</h3><p className="mt-1 text-xs text-[var(--muted-2)]">{t("analysis.profileDescription")}</p></div>
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3"><ProfileCard kind="fast" selected={profile === "fast"} onClick={() => setProfile("fast")} /><ProfileCard kind="balanced" selected={profile === "balanced"} onClick={() => setProfile("balanced")} /><ProfileCard kind="accuracy" selected={profile === "accuracy"} onClick={() => setProfile("accuracy")} /></div>
      </section>

      <Card>
        <CardHeader title={<span className="flex items-center gap-2"><SlidersHorizontal size={17} className="text-[#33d3bb]" /> {t("analysis.processingOutput")}</span>} description={t("analysis.settingsDirect")} />
        <div className="grid grid-cols-1 gap-4 p-5 md:grid-cols-2 xl:grid-cols-4">
          <label className="rounded-xl border border-[var(--border)] bg-white/[.025] p-4"><div className="flex items-center justify-between text-xs"><span className="font-bold">Confidence</span><span className="font-mono text-[#5cdbc8]" dir="ltr">{confidence.toFixed(2)}</span></div><input type="range" min="0.05" max="0.7" step="0.01" value={confidence} onChange={(event) => setConfidence(Number(event.target.value))} className="mt-4 w-full accent-[#33d3bb]" /><div className="mt-2 text-[10px] text-[var(--muted-2)]">{t("analysis.confidenceThreshold")}</div></label>
          {optionCards.map(([title, description, checked, setter]) => (
            <div key={title} className="flex items-center justify-between rounded-xl border border-[var(--border)] bg-white/[.025] p-4"><div><div className="text-xs font-bold">{title}</div><div className="mt-2 text-[10px] text-[var(--muted-2)]">{description}</div></div><Toggle checked={checked} onChange={setter} label={title} /></div>
          ))}
        </div>
      </Card>

      <Card>
        <CardHeader title={t("analysis.preflight")} description={t("analysis.preflightDescription")} />
        <div className="grid grid-cols-1 gap-3 p-5 sm:grid-cols-2 xl:grid-cols-5">
          {preflight.map(({ label, detail, ready: itemReady, icon: Icon }) => (
            <div key={label} className="rounded-xl border border-[var(--border)] bg-white/[.025] p-4">
              <div className="flex items-center justify-between"><div className={`grid h-9 w-9 place-items-center rounded-xl ${itemReady ? "bg-[#33d3bb]/10 text-[#53dbc7]" : "bg-[#f6bd58]/10 text-[#f6bd58]"}`}><Icon size={17} /></div>{itemReady ? <CheckCircle2 size={18} className="text-[#49d6a5]" /> : <CircleAlert size={18} className="text-[#f6bd58]" />}</div>
              <div className="mt-4 text-xs font-black">{label}</div><div className="mt-2 text-[10px] leading-5 text-[var(--muted-2)]" dir="auto">{detail}</div>
            </div>
          ))}
        </div>
      </Card>

      <div className="flex flex-col-reverse justify-between gap-3 sm:flex-row sm:items-center">
        <p className="flex items-center gap-2 text-[11px] leading-6 text-[var(--muted-2)]"><Info size={14} /> {t("analysis.webCopyNote")}</p>
        <Button onClick={() => void startAnalysis()} disabled={!ready} loading={starting} className="px-8 py-3"><Sparkles size={17} /> {t("analysis.startReal")}</Button>
      </div>
    </div>
  );
}
