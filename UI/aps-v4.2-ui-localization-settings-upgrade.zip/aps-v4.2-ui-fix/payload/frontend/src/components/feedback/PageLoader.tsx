import { BrandMark } from "@/components/BrandMark";
import { useI18n } from "@/hooks/use-i18n";

export function PageLoader() {
  const { t } = useI18n();
  return (
    <div className="grid min-h-screen place-items-center bg-[var(--bg)]">
      <div className="text-center">
        <div className="mx-auto w-fit animate-pulse"><BrandMark /></div>
        <div className="mx-auto mt-5 h-1.5 w-36 overflow-hidden rounded-full bg-white/[.06]">
          <div className="h-full w-1/2 animate-[pulse_1.2s_ease-in-out_infinite] rounded-full bg-[#33d3bb]" />
        </div>
        <p className="mt-3 text-xs text-[var(--muted)]">{t("loader.text")}</p>
      </div>
    </div>
  );
}
