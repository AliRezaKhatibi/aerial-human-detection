import { Check, Gauge, ScanSearch, Zap } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { cn } from "@/lib/cn";
import type { InferenceMode } from "@/stores/app-store";
import { useI18n } from "@/hooks/use-i18n";

const profileIcons = {
  fast: { icon: Zap, tone: "text-[#57dec9]", estimate: "17–28 FPS" },
  balanced: { icon: Gauge, tone: "text-[#a1abff]", estimate: "10–18 FPS" },
  accuracy: { icon: ScanSearch, tone: "text-[#f7ca75]", estimate: "4–9 FPS" },
};

export function ProfileCard({ kind, selected, onClick, compact = false }: { kind: InferenceMode; selected?: boolean; onClick?: () => void; compact?: boolean }) {
  const { t } = useI18n();
  const item = profileIcons[kind];
  const Icon = item.icon;
  const title = t(`profile.${kind}Title`);
  const subtitle = t(`profile.${kind}Subtitle`);
  const body = t(`profile.${kind}Body`);
  const tags = [t(`profile.${kind}Tag1`), t(`profile.${kind}Tag2`)];
  return (
    <Card onClick={onClick} className={cn("panel-hover relative cursor-pointer p-5", selected && "border-[#33d3bb]/38 ring-1 ring-[#33d3bb]/18", compact && "p-4")}>
      {selected && <div className="absolute start-4 top-4 grid h-6 w-6 place-items-center rounded-full bg-[#33d3bb] text-[#06110f]"><Check size={14} strokeWidth={3} /></div>}
      <div className="flex items-start justify-between gap-3">
        <div className="grid h-10 w-10 place-items-center rounded-xl bg-white/[.045]"><Icon className={item.tone} size={22} /></div>
        <span className="text-[10px] font-bold text-[var(--muted-2)]" dir="ltr">{item.estimate}</span>
      </div>
      <div className="mt-4 text-base font-black text-[var(--text)]">{title}</div>
      <div className="mt-1 text-xs font-bold text-[var(--muted)]">{subtitle}</div>
      {!compact && <p className="mt-3 min-h-12 text-xs leading-6 text-[var(--muted-2)]">{body}</p>}
      <div className="mt-4 flex flex-wrap gap-2">{tags.map((tag) => <Badge key={tag} tone={selected ? "green" : "gray"}>{tag}</Badge>)}</div>
    </Card>
  );
}
