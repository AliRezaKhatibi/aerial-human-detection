import { cn } from "@/lib/cn";

export function Toggle({ checked, onChange, label, disabled = false }: { checked: boolean; onChange: (checked: boolean) => void; label?: string; disabled?: boolean }) {
  return (
    <button
      type="button"
      dir="ltr"
      aria-pressed={checked}
      aria-label={label}
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className={cn(
        "focus-ring relative h-7 w-12 rounded-full border transition disabled:cursor-not-allowed disabled:opacity-50",
        checked ? "border-[#33d3bb]/35 bg-[#33d3bb]/22" : "border-[var(--border)] bg-white/[.055]",
      )}
    >
      <span className={cn("absolute left-1 top-1 h-5 w-5 rounded-full bg-white shadow transition-transform", checked ? "translate-x-5" : "translate-x-0")} />
    </button>
  );
}
