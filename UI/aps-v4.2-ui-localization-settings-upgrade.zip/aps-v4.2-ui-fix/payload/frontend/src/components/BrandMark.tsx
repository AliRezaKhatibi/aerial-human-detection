import { ScanLine } from "lucide-react";
import { cn } from "@/lib/cn";
import { useI18n } from "@/hooks/use-i18n";

export function BrandMark({ compact = false }: { compact?: boolean }) {
  const { t } = useI18n();
  return (
    <div className="flex items-center gap-3">
      <div className="relative grid h-11 w-11 shrink-0 place-items-center overflow-hidden rounded-2xl border border-[#33d3bb]/25 bg-gradient-to-br from-[#33d3bb]/18 to-[#7d8dff]/12 shadow-[0_0_38px_rgba(51,211,187,.15)]">
        <ScanLine size={22} className="text-[#65e1cf]" />
        <span className="absolute bottom-1.5 end-1.5 h-1.5 w-1.5 rounded-full bg-[#7d8dff] shadow-[0_0_10px_#7d8dff]" />
      </div>
      <div className={cn("min-w-0 transition-opacity", compact && "hidden")}> 
        <div className="truncate text-sm font-extrabold tracking-tight text-[var(--text)]">{t("common.appName")}</div>
        <div className="mt-0.5 text-[9px] font-semibold uppercase tracking-[.22em] text-[var(--muted-2)]">{t("common.visionPlatform")}</div>
      </div>
    </div>
  );
}
