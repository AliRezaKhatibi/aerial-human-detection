import { Bell, ChevronLeft, ChevronRight, Languages, Menu, Moon, Search, Sun } from "lucide-react";
import { useMemo, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { Badge } from "@/components/ui/Badge";
import { useAppStore } from "@/stores/app-store";
import { useI18n } from "@/hooks/use-i18n";
import { api } from "@/lib/api";

const pageDefinitions = [
  { path: "/", titleKey: "topbar.dashboard", navKey: "nav.dashboard", keywords: ["dashboard", "داشبورد"] },
  { path: "/analysis/new", titleKey: "topbar.newAnalysis", navKey: "nav.newAnalysis", keywords: ["analysis", "video", "تحلیل", "ویدئو"] },
  { path: "/processing", titleKey: "topbar.processing", navKey: "nav.processing", keywords: ["processing", "live", "پردازش", "زنده"] },
  { path: "/results", titleKey: "topbar.results", navKey: "nav.results", keywords: ["results", "reports", "نتایج", "گزارش"] },
  { path: "/profiles", titleKey: "topbar.profiles", navKey: "nav.profiles", keywords: ["profiles", "model", "پروفایل", "مدل"] },
  { path: "/settings", titleKey: "topbar.settings", navKey: "nav.settings", keywords: ["settings", "preferences", "تنظیمات"] },
  { path: "/system", titleKey: "topbar.system", navKey: "nav.system", keywords: ["system", "diagnostics", "سیستم", "وضعیت"] },
];

export function Topbar() {
  const location = useLocation();
  const navigate = useNavigate();
  const toggleSidebar = useAppStore((s) => s.toggleSidebar);
  const setMobileOpen = useAppStore((s) => s.setMobileSidebarOpen);
  const toggleTheme = useAppStore((s) => s.toggleTheme);
  const theme = useAppStore((s) => s.theme);
  const locale = useAppStore((s) => s.locale);
  const setLocale = useAppStore((s) => s.setLocale);
  const [search, setSearch] = useState("");
  const { t, isRtl } = useI18n();
  const health = useQuery({ queryKey: ["health-topbar"], queryFn: api.health, refetchInterval: 8000, retry: 1 });
  const currentDefinition = pageDefinitions.find(({ path }) => path === "/" ? location.pathname === path : location.pathname.startsWith(path));
  const current = t(currentDefinition?.titleKey ?? "common.appName");
  const searchablePages = useMemo(() => pageDefinitions.map((item) => ({ ...item, label: t(item.navKey) })), [t]);

  const submitSearch = () => {
    const term = search.trim().toLocaleLowerCase(locale === "fa" ? "fa" : "en");
    if (!term) return;
    const match = searchablePages.find((item) =>
      item.label.toLocaleLowerCase(locale === "fa" ? "fa" : "en").includes(term)
      || item.keywords.some((keyword) => keyword.toLowerCase().includes(term) || term.includes(keyword.toLowerCase())),
    );
    if (match) {
      navigate(match.path);
      setSearch("");
    }
  };

  return (
    <header className="sticky top-0 z-20 flex h-[74px] items-center justify-between border-b border-[var(--border)] bg-[var(--bg)]/78 px-4 backdrop-blur-xl sm:px-5 lg:px-6">
      <div className="flex min-w-0 items-center gap-3">
        <Button variant="ghost" className="h-10 w-10 p-0 lg:hidden" onClick={() => setMobileOpen(true)} aria-label={t("nav.closeMenu")}><Menu size={19} /></Button>
        <Button variant="ghost" className="hidden h-10 w-10 p-0 lg:inline-flex" onClick={toggleSidebar} aria-label={t("nav.closeMenu")}><Menu size={19} /></Button>
        <div className="min-w-0">
          <h1 className="truncate text-sm font-extrabold text-[var(--text)] sm:text-base">{current}</h1>
          <div className="mt-0.5 hidden items-center gap-1 text-[11px] text-[var(--muted-2)] sm:flex">
            {t("common.studio")} {isRtl ? <ChevronLeft size={12} /> : <ChevronRight size={12} />} {t("common.visionOperations")}
          </div>
        </div>
      </div>
      <div className="flex items-center gap-1.5 sm:gap-2">
        <div className="hidden items-center gap-2 rounded-xl border border-[var(--border)] bg-white/[.03] px-3 py-2 2xl:flex">
          <Search size={16} className="text-[var(--muted-2)]" />
          <input
            list="aps-page-search"
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            onKeyDown={(event) => { if (event.key === "Enter") submitSearch(); }}
            className="w-48 bg-transparent text-xs text-[var(--text)] outline-none"
            placeholder={t("topbar.searchPlaceholder")}
            aria-label={t("topbar.searchLabel")}
          />
          <datalist id="aps-page-search">{searchablePages.map((page) => <option key={page.path} value={page.label} />)}</datalist>
        </div>
        <Badge tone={health.isSuccess ? "green" : health.isError ? "red" : "amber"} dot>
          {health.isSuccess ? t("topbar.backendOnline") : health.isError ? t("topbar.backendOffline") : t("topbar.backendChecking")}
        </Badge>
        <Button variant="ghost" className="hidden h-10 w-10 p-0 sm:inline-flex" onClick={() => setLocale(locale === "fa" ? "en" : "fa")} title={t("topbar.language")} aria-label={t("topbar.language")}><Languages size={18} /></Button>
        <Button variant="ghost" className="h-10 w-10 p-0" onClick={toggleTheme} title={t("topbar.theme")} aria-label={t("topbar.theme")}>{theme === "dark" ? <Moon size={18} /> : <Sun size={18} />}</Button>
        <Button variant="ghost" className="hidden h-10 w-10 p-0 sm:inline-flex" disabled title={t("topbar.noNotifications")} aria-label={t("topbar.noNotifications")}><Bell size={18} /></Button>
        <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-[#33d3bb] to-[#687dff] p-[1px]"><div className="grid h-full w-full place-items-center rounded-[11px] bg-[var(--panel-strong)] text-xs font-black">AP</div></div>
      </div>
    </header>
  );
}
