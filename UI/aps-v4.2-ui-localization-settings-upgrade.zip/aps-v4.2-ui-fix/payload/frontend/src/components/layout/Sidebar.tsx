import { BarChart3, Cpu, FileVideo2, Gauge, LayoutDashboard, Settings, SlidersHorizontal, Sparkles, X } from "lucide-react";
import { NavLink } from "react-router-dom";
import { BrandMark } from "@/components/BrandMark";
import { cn } from "@/lib/cn";
import { useAppStore } from "@/stores/app-store";
import { useI18n } from "@/hooks/use-i18n";

const navItems = [
  { to: "/", key: "nav.dashboard", icon: LayoutDashboard },
  { to: "/analysis/new", key: "nav.newAnalysis", icon: FileVideo2 },
  { to: "/processing", key: "nav.processing", icon: Gauge },
  { to: "/results", key: "nav.results", icon: BarChart3 },
  { to: "/profiles", key: "nav.profiles", icon: SlidersHorizontal },
  { to: "/settings", key: "nav.settings", icon: Settings },
  { to: "/system", key: "nav.system", icon: Cpu },
];

export function Sidebar() {
  const collapsed = useAppStore((state) => state.sidebarCollapsed);
  const mobileOpen = useAppStore((state) => state.mobileSidebarOpen);
  const setMobileOpen = useAppStore((state) => state.setMobileSidebarOpen);
  const locale = useAppStore((state) => state.locale);
  const { t } = useI18n();
  return (
    <aside className={cn(
      "fixed inset-y-0 z-40 border-[var(--border)] bg-[var(--panel-strong)] px-3 py-4 shadow-2xl backdrop-blur-xl transition-all duration-300",
      locale === "fa" ? "right-0 border-l" : "left-0 border-r",
      collapsed ? "lg:w-[84px]" : "lg:w-[272px]",
      mobileOpen ? "translate-x-0 w-[280px]" : locale === "fa" ? "translate-x-full lg:translate-x-0" : "-translate-x-full lg:translate-x-0",
    )}>
      <div className="flex items-center justify-between px-2">
        <BrandMark compact={collapsed && !mobileOpen} />
        <button aria-label={t("nav.closeMenu")} className="focus-ring grid h-9 w-9 place-items-center rounded-xl text-[var(--muted)] hover:bg-white/[.055] lg:hidden" onClick={() => setMobileOpen(false)}><X size={18} /></button>
      </div>
      <nav className="mt-8 space-y-1.5">
        {navItems.map(({ to, key, icon: Icon }) => {
          const label = t(key);
          return (
            <NavLink
              key={to}
              to={to}
              end={to === "/"}
              onClick={() => setMobileOpen(false)}
              title={collapsed ? label : undefined}
              className={({ isActive }) => cn(
                "focus-ring group flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold transition",
                isActive ? "bg-[#33d3bb]/12 text-[#62dfce] ring-1 ring-[#33d3bb]/15" : "text-[var(--muted)] hover:bg-white/[.045] hover:text-[var(--text)]",
              )}
            >
              <Icon size={19} strokeWidth={1.8} className="shrink-0" />
              {(!collapsed || mobileOpen) && <span>{label}</span>}
            </NavLink>
          );
        })}
      </nav>
      <div className="absolute bottom-4 inset-x-3 rounded-2xl border border-[#7d8dff]/15 bg-gradient-to-br from-[#7d8dff]/10 to-[#33d3bb]/5 p-3">
        <div className="flex items-center gap-2 text-xs font-bold text-[var(--text)]"><Sparkles size={15} className="text-[#9aa5ff]" /> {(!collapsed || mobileOpen) && "YOLO26m-P2"}</div>
        {(!collapsed || mobileOpen) && <div className="mt-1 text-[11px] leading-5 text-[var(--muted-2)]">{t("nav.version")}</div>}
      </div>
    </aside>
  );
}
