import { create } from "zustand";
import { persist } from "zustand/middleware";

export type Locale = "fa" | "en";
export type Theme = "dark" | "light";
export type InferenceMode = "fast" | "balanced" | "accuracy";
export type ReportFormat = "csv-json" | "csv" | "json";

export interface AppPreferences {
  notifications: boolean;
  autoSaveVideo: boolean;
  showTrackIds: boolean;
  showConfidence: boolean;
  showTrails: boolean;
  reportFormat: ReportFormat;
  defaultConfidence: number;
}

export const DEFAULT_PREFERENCES: AppPreferences = {
  notifications: true,
  autoSaveVideo: true,
  showTrackIds: true,
  showConfidence: true,
  showTrails: true,
  reportFormat: "csv-json",
  defaultConfidence: 0.2,
};

interface AppState {
  locale: Locale;
  theme: Theme;
  sidebarCollapsed: boolean;
  mobileSidebarOpen: boolean;
  selectedProfile: InferenceMode;
  preferences: AppPreferences;
  setLocale: (locale: Locale) => void;
  setTheme: (theme: Theme) => void;
  toggleTheme: () => void;
  toggleSidebar: () => void;
  setMobileSidebarOpen: (open: boolean) => void;
  setSelectedProfile: (profile: InferenceMode) => void;
  setPreferences: (preferences: AppPreferences) => void;
  resetPreferences: () => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      locale: "fa",
      theme: "dark",
      sidebarCollapsed: false,
      mobileSidebarOpen: false,
      selectedProfile: "balanced",
      preferences: DEFAULT_PREFERENCES,
      setLocale: (locale) => set({ locale }),
      setTheme: (theme) => set({ theme }),
      toggleTheme: () => set((state) => ({ theme: state.theme === "dark" ? "light" : "dark" })),
      toggleSidebar: () => set((state) => ({ sidebarCollapsed: !state.sidebarCollapsed })),
      setMobileSidebarOpen: (mobileSidebarOpen) => set({ mobileSidebarOpen }),
      setSelectedProfile: (selectedProfile) => set({ selectedProfile }),
      setPreferences: (preferences) => set({ preferences }),
      resetPreferences: () => set({ preferences: DEFAULT_PREFERENCES }),
    }),
    {
      name: "aps-ui-settings",
      version: 2,
      migrate: (persistedState) => {
        const state = (persistedState ?? {}) as Partial<AppState>;
        return {
          ...state,
          preferences: {
            ...DEFAULT_PREFERENCES,
            ...(state.preferences ?? {}),
          },
        } as AppState;
      },
      partialize: (state) => ({
        locale: state.locale,
        theme: state.theme,
        sidebarCollapsed: state.sidebarCollapsed,
        selectedProfile: state.selectedProfile,
        preferences: state.preferences,
      }),
    },
  ),
);
