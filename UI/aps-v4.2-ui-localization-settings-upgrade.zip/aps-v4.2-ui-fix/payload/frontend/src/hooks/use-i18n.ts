import { useCallback, useMemo } from "react";
import { translate } from "@/i18n/translations";
import { useAppStore } from "@/stores/app-store";
import type { JobStatus } from "@/types/api";

export function useI18n() {
  const locale = useAppStore((state) => state.locale);
  const t = useCallback(
    (key: string, variables?: Record<string, string | number>) => translate(locale, key, variables),
    [locale],
  );
  const numberFormatter = useMemo(
    () => new Intl.NumberFormat(locale === "fa" ? "fa-IR" : "en-US"),
    [locale],
  );
  const decimalFormatter = useMemo(
    () => new Intl.NumberFormat(locale === "fa" ? "fa-IR" : "en-US", { maximumFractionDigits: 1 }),
    [locale],
  );

  const jobStatus = useCallback((status?: string | JobStatus | null) => {
    if (!status) return t("status.loading");
    return t(`status.${status}`);
  }, [t]);

  const profileName = useCallback((profile?: string | null) => {
    if (profile === "fast") return t("profile.fastTitle");
    if (profile === "accuracy") return t("profile.accuracyTitle");
    return t("profile.balancedTitle");
  }, [t]);

  return {
    locale,
    isRtl: locale === "fa",
    dir: locale === "fa" ? "rtl" as const : "ltr" as const,
    t,
    formatNumber: (value: number) => numberFormatter.format(value),
    formatDecimal: (value: number) => decimalFormatter.format(value),
    jobStatus,
    profileName,
  };
}
