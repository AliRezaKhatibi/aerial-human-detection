param(
    [string]$ProjectPath = "D:\APS\app"
)

$ErrorActionPreference = "Stop"
$ProjectPath = (Resolve-Path $ProjectPath).Path
$SourceRoot = Join-Path $PSScriptRoot "payload"
$TrackerTarget = Join-Path $ProjectPath "backend\app\inference\tracker.py"
$PipelineTarget = Join-Path $ProjectPath "backend\app\inference\pipeline.py"
$Python = Join-Path $ProjectPath "backend\.venv\Scripts\python.exe"

if (-not (Test-Path $TrackerTarget) -or -not (Test-Path $PipelineTarget)) {
    throw "Aerial Person Studio backend files were not found in: $ProjectPath"
}
if (-not (Test-Path $Python)) {
    throw "Backend virtual environment was not found. Run scripts\setup.ps1 first."
}

$Timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$Backup = Join-Path $ProjectPath "tracking-backup-$Timestamp"
New-Item -ItemType Directory -Force $Backup | Out-Null

Write-Host "Backing up tracking files to: $Backup"
Copy-Item $TrackerTarget (Join-Path $Backup "tracker.py") -Force
Copy-Item $PipelineTarget (Join-Path $Backup "pipeline.py") -Force

Write-Host "Applying stable-ID tracking patch..."
Copy-Item (Join-Path $SourceRoot "backend\app\inference\tracker.py") $TrackerTarget -Force
Copy-Item (Join-Path $SourceRoot "backend\app\inference\pipeline.py") $PipelineTarget -Force

Write-Host "Checking Python syntax..."
& $Python -m py_compile $TrackerTarget $PipelineTarget
if ($LASTEXITCODE -ne 0) {
    Copy-Item (Join-Path $Backup "tracker.py") $TrackerTarget -Force
    Copy-Item (Join-Path $Backup "pipeline.py") $PipelineTarget -Force
    throw "Syntax validation failed. Original files were restored."
}

Write-Host "Running backend tests..."
Push-Location (Join-Path $ProjectPath "backend")
try {
    & $Python -m pytest -q
    if ($LASTEXITCODE -ne 0) {
        throw "Backend tests failed."
    }
}
catch {
    Pop-Location
    Copy-Item (Join-Path $Backup "tracker.py") $TrackerTarget -Force
    Copy-Item (Join-Path $Backup "pipeline.py") $PipelineTarget -Force
    throw "Tracking patch validation failed. Original files were restored. $($_.Exception.Message)"
}
Pop-Location

Write-Host ""
Write-Host "Stable-ID tracking patch installed successfully." -ForegroundColor Green
Write-Host "Restart the backend before running a new video."
Write-Host "Backup: $Backup"
