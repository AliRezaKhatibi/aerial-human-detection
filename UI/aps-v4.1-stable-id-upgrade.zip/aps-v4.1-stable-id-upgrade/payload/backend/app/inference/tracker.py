from __future__ import annotations

import math
from dataclasses import dataclass
from types import SimpleNamespace

import numpy as np


@dataclass(slots=True)
class Track:
    x1: float
    y1: float
    x2: float
    y2: float
    track_id: int
    confidence: float
    class_id: int
    raw_track_id: int | None = None


@dataclass(slots=True)
class _StableTrackState:
    stable_id: int
    bbox: tuple[float, float, float, float]
    center: tuple[float, float]
    velocity: tuple[float, float]
    last_seen_frame: int
    raw_track_id: int


class ByteTrackAdapter:
    """Aerial-tuned ByteTrack wrapper.

    The detector may briefly lose tiny people.  Compared with the stock
    defaults, this configuration keeps tracks alive longer, accepts weaker
    continuation detections, and is slightly more tolerant of camera motion.
    """

    def __init__(self, frame_rate: float = 30.0, confidence: float = 0.20) -> None:
        try:
            from ultralytics.trackers.byte_tracker import BYTETracker
        except ImportError as exc:
            raise RuntimeError("Ultralytics tracking components are not installed.") from exc

        source_fps = max(1.0, float(frame_rate))
        high_thresh = max(0.14, min(0.28, float(confidence) * 0.75))
        low_thresh = max(0.03, min(0.08, high_thresh * 0.35))
        new_track_thresh = max(0.18, high_thresh)

        args = SimpleNamespace(
            track_high_thresh=high_thresh,
            track_low_thresh=low_thresh,
            new_track_thresh=new_track_thresh,
            # Preserve a missing person for roughly three seconds of source video.
            track_buffer=min(180, max(60, int(round(source_fps * 3.0)))),
            # BYTETracker uses a distance threshold; a slightly higher value is
            # more permissive for small boxes and modest drone/camera motion.
            match_thresh=0.88,
            fuse_score=True,
        )
        try:
            self._tracker = BYTETracker(args, frame_rate=int(round(source_fps)))
        except TypeError:
            self._tracker = BYTETracker(args)

    def update(self, detections: np.ndarray, frame: np.ndarray) -> list[Track]:
        import torch
        from ultralytics.engine.results import Boxes

        if len(detections) == 0:
            tensor = torch.empty((0, 6), dtype=torch.float32)
        else:
            tensor = torch.as_tensor(detections, dtype=torch.float32)
        boxes = Boxes(tensor, orig_shape=frame.shape[:2])
        tracked = self._tracker.update(boxes, frame)
        if tracked is None or len(tracked) == 0:
            return []

        rows = np.asarray(tracked)
        result: list[Track] = []
        for row in rows:
            if len(row) < 7:
                continue
            raw_id = int(row[4])
            result.append(
                Track(
                    x1=float(row[0]),
                    y1=float(row[1]),
                    x2=float(row[2]),
                    y2=float(row[3]),
                    track_id=raw_id,
                    confidence=float(row[5]),
                    class_id=int(row[6]),
                    raw_track_id=raw_id,
                )
            )
        return result


def _bbox_center(bbox: tuple[float, float, float, float]) -> tuple[float, float]:
    x1, y1, x2, y2 = bbox
    return ((x1 + x2) * 0.5, (y1 + y2) * 0.5)


def _bbox_area(bbox: tuple[float, float, float, float]) -> float:
    x1, y1, x2, y2 = bbox
    return max(1.0, x2 - x1) * max(1.0, y2 - y1)


def _shift_bbox(
    bbox: tuple[float, float, float, float],
    dx: float,
    dy: float,
) -> tuple[float, float, float, float]:
    x1, y1, x2, y2 = bbox
    return (x1 + dx, y1 + dy, x2 + dx, y2 + dy)


def _iou(
    first: tuple[float, float, float, float],
    second: tuple[float, float, float, float],
) -> float:
    ax1, ay1, ax2, ay2 = first
    bx1, by1, bx2, by2 = second
    ix1 = max(ax1, bx1)
    iy1 = max(ay1, by1)
    ix2 = min(ax2, bx2)
    iy2 = min(ay2, by2)
    intersection = max(0.0, ix2 - ix1) * max(0.0, iy2 - iy1)
    if intersection <= 0:
        return 0.0
    union = _bbox_area(first) + _bbox_area(second) - intersection
    return intersection / max(union, 1e-6)


class StableIdReconciler:
    """Maps fragmented raw ByteTrack IDs to longer-lived stable IDs.

    ByteTrack can assign a new raw ID after a brief missed detection or partial
    occlusion.  This layer predicts recently lost track positions and reconnects
    a newly-created raw ID when position, overlap, and box size are compatible.

    It intentionally does not merge two simultaneously active raw tracks.  That
    guard prevents nearby people from being collapsed into one identity.
    """

    def __init__(self, frame_rate: float = 30.0, retention_seconds: float = 2.5) -> None:
        source_fps = max(1.0, float(frame_rate))
        self._max_missing_frames = max(20, int(round(source_fps * retention_seconds)))
        self._next_stable_id = 1
        self._raw_to_stable: dict[int, int] = {}
        self._states: dict[int, _StableTrackState] = {}

    def update(
        self,
        tracks: list[Track],
        frame_index: int,
        frame_shape: tuple[int, ...],
    ) -> list[Track]:
        if not tracks:
            self._prune(frame_index)
            return []

        height, width = frame_shape[:2]
        diagonal = max(1.0, math.hypot(width, height))
        current_raw_ids = {int(track.raw_track_id or track.track_id) for track in tracks}
        assigned_stable_ids: set[int] = set()
        assignments: dict[int, int] = {}
        new_tracks: list[Track] = []

        # Preserve established raw-to-stable mappings first.
        for track in tracks:
            raw_id = int(track.raw_track_id or track.track_id)
            stable_id = self._raw_to_stable.get(raw_id)
            state = self._states.get(stable_id) if stable_id is not None else None
            if (
                state is not None
                and frame_index - state.last_seen_frame <= self._max_missing_frames * 2
                and stable_id not in assigned_stable_ids
            ):
                assignments[raw_id] = stable_id
                assigned_stable_ids.add(stable_id)
            else:
                new_tracks.append(track)

        # Build globally ranked candidates for raw IDs that ByteTrack just created.
        candidates: list[tuple[float, int, int]] = []
        for track in new_tracks:
            raw_id = int(track.raw_track_id or track.track_id)
            bbox = (track.x1, track.y1, track.x2, track.y2)
            center = _bbox_center(bbox)
            area = _bbox_area(bbox)

            for stable_id, state in self._states.items():
                if stable_id in assigned_stable_ids:
                    continue
                if state.raw_track_id in current_raw_ids:
                    # Never merge two raw tracks that are active in the same frame.
                    continue

                gap = frame_index - state.last_seen_frame
                if gap <= 0 or gap > self._max_missing_frames:
                    continue

                dx = state.velocity[0] * gap
                dy = state.velocity[1] * gap
                predicted_bbox = _shift_bbox(state.bbox, dx, dy)
                predicted_center = _bbox_center(predicted_bbox)
                center_distance = math.hypot(
                    center[0] - predicted_center[0],
                    center[1] - predicted_center[1],
                )

                # Gate expands gradually with the number of missing source frames.
                gate = max(24.0, diagonal * (0.025 + min(gap, 40) * 0.0022))
                overlap = _iou(predicted_bbox, bbox)
                area_ratio = area / max(_bbox_area(predicted_bbox), 1.0)

                if not 0.28 <= area_ratio <= 3.6:
                    continue
                if center_distance > gate:
                    continue
                if overlap < 0.015 and center_distance > gate * 0.58:
                    continue

                size_penalty = abs(math.log(max(area_ratio, 1e-6)))
                cost = (
                    center_distance / gate
                    + 0.70 * (1.0 - overlap)
                    + 0.22 * size_penalty
                    + 0.08 * (1.0 - max(0.0, min(1.0, track.confidence)))
                )
                if cost <= 1.75:
                    candidates.append((cost, raw_id, stable_id))

        used_raw_ids: set[int] = set()
        for _, raw_id, stable_id in sorted(candidates, key=lambda item: item[0]):
            if raw_id in used_raw_ids or stable_id in assigned_stable_ids:
                continue
            assignments[raw_id] = stable_id
            used_raw_ids.add(raw_id)
            assigned_stable_ids.add(stable_id)

        # Any unmatched raw ID becomes a genuinely new stable identity.
        for track in new_tracks:
            raw_id = int(track.raw_track_id or track.track_id)
            if raw_id in assignments:
                continue
            stable_id = self._next_stable_id
            self._next_stable_id += 1
            assignments[raw_id] = stable_id
            assigned_stable_ids.add(stable_id)

        stabilized: list[Track] = []
        for track in tracks:
            raw_id = int(track.raw_track_id or track.track_id)
            stable_id = assignments[raw_id]
            bbox = (track.x1, track.y1, track.x2, track.y2)
            center = _bbox_center(bbox)
            previous = self._states.get(stable_id)

            velocity = (0.0, 0.0)
            if previous is not None:
                gap = max(1, frame_index - previous.last_seen_frame)
                measured = (
                    (center[0] - previous.center[0]) / gap,
                    (center[1] - previous.center[1]) / gap,
                )
                velocity = (
                    previous.velocity[0] * 0.65 + measured[0] * 0.35,
                    previous.velocity[1] * 0.65 + measured[1] * 0.35,
                )

            self._states[stable_id] = _StableTrackState(
                stable_id=stable_id,
                bbox=bbox,
                center=center,
                velocity=velocity,
                last_seen_frame=frame_index,
                raw_track_id=raw_id,
            )
            self._raw_to_stable[raw_id] = stable_id
            stabilized.append(
                Track(
                    x1=track.x1,
                    y1=track.y1,
                    x2=track.x2,
                    y2=track.y2,
                    track_id=stable_id,
                    confidence=track.confidence,
                    class_id=track.class_id,
                    raw_track_id=raw_id,
                )
            )

        self._prune(frame_index)
        return stabilized

    def _prune(self, frame_index: int) -> None:
        stale_ids = {
            stable_id
            for stable_id, state in self._states.items()
            if frame_index - state.last_seen_frame > self._max_missing_frames * 4
        }
        if not stale_ids:
            return
        for stable_id in stale_ids:
            self._states.pop(stable_id, None)
        self._raw_to_stable = {
            raw_id: stable_id
            for raw_id, stable_id in self._raw_to_stable.items()
            if stable_id not in stale_ids
        }
