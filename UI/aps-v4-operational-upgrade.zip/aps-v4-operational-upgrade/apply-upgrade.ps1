param(
    [string]$ProjectPath = "D:\A_Senior - Data Science\Projects\UI\aerial-person-studio-v2"
)

$ErrorActionPreference = "Stop"
$UpgradeRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$Payload = Join-Path $UpgradeRoot "payload"
$Timestamp = Get-Date -Format "yyyyMMdd-HHmmss"

Write-Host "Aerial Person Studio - V4 Operational Upgrade" -ForegroundColor Cyan
Write-Host "Target project: $ProjectPath"

if (-not (Test-Path $ProjectPath)) {
    throw "Project path does not exist: $ProjectPath"
}

$Required = @(
    (Join-Path $ProjectPath "frontend\src"),
    (Join-Path $ProjectPath "backend\app"),
    (Join-Path $ProjectPath "scripts")
)
foreach ($Item in $Required) {
    if (-not (Test-Path $Item)) { throw "Required project item is missing: $Item" }
}

$FrontendBackup = Join-Path $ProjectPath "frontend-src-backup-v4-$Timestamp"
$BackendBackup = Join-Path $ProjectPath "backend-app-backup-v4-$Timestamp"
Write-Host "[1/5] Backing up frontend and backend..." -ForegroundColor Yellow
Copy-Item (Join-Path $ProjectPath "frontend\src") $FrontendBackup -Recurse
Copy-Item (Join-Path $ProjectPath "backend\app") $BackendBackup -Recurse
Copy-Item (Join-Path $ProjectPath "backend\pyproject.toml") (Join-Path $ProjectPath "backend\pyproject.v3.$Timestamp.toml")

try {
    Write-Host "[2/5] Applying Backend V4..." -ForegroundColor Yellow
    Remove-Item (Join-Path $ProjectPath "backend\app") -Recurse -Force
    Copy-Item (Join-Path $Payload "backend\app") (Join-Path $ProjectPath "backend\app") -Recurse
    Copy-Item (Join-Path $Payload "backend\pyproject.toml") (Join-Path $ProjectPath "backend\pyproject.toml") -Force
    Copy-Item (Join-Path $Payload "backend\.env.example") (Join-Path $ProjectPath "backend\.env.example") -Force

    Write-Host "[3/5] Applying Frontend V4..." -ForegroundColor Yellow
    Remove-Item (Join-Path $ProjectPath "frontend\src") -Recurse -Force
    Copy-Item (Join-Path $Payload "frontend\src") (Join-Path $ProjectPath "frontend\src") -Recurse
    Copy-Item (Join-Path $Payload "frontend\package.json") (Join-Path $ProjectPath "frontend\package.json") -Force

    Write-Host "[4/5] Installing V4 helper scripts and runtime folders..." -ForegroundColor Yellow
    Copy-Item (Join-Path $Payload "scripts\install-ai.ps1") (Join-Path $ProjectPath "scripts\install-ai.ps1") -Force
    Copy-Item (Join-Path $Payload "scripts\verify-v4.ps1") (Join-Path $ProjectPath "scripts\verify-v4.ps1") -Force
    New-Item -ItemType Directory -Force -Path (Join-Path $ProjectPath "runtime\uploads") | Out-Null
    New-Item -ItemType Directory -Force -Path (Join-Path $ProjectPath "runtime\reports") | Out-Null

    Write-Host "[5/5] Building the upgraded frontend..." -ForegroundColor Yellow
    & npm --prefix (Join-Path $ProjectPath "frontend") run build
    if ($LASTEXITCODE -ne 0) { throw "Frontend V4 build failed." }
}
catch {
    Write-Host "Upgrade failed. Restoring source backups..." -ForegroundColor Red
    if (Test-Path $FrontendBackup) {
        Remove-Item (Join-Path $ProjectPath "frontend\src") -Recurse -Force -ErrorAction SilentlyContinue
        Copy-Item $FrontendBackup (Join-Path $ProjectPath "frontend\src") -Recurse
    }
    if (Test-Path $BackendBackup) {
        Remove-Item (Join-Path $ProjectPath "backend\app") -Recurse -Force -ErrorAction SilentlyContinue
        Copy-Item $BackendBackup (Join-Path $ProjectPath "backend\app") -Recurse
    }
    throw
}

Write-Host ""
Write-Host "V4 operational upgrade completed successfully." -ForegroundColor Green
Write-Host "Frontend backup: $FrontendBackup"
Write-Host "Backend backup:  $BackendBackup"
Write-Host ""
Write-Host "NEXT REQUIRED STEP:" -ForegroundColor Cyan
Write-Host "cd `"$ProjectPath`""
Write-Host ".\scripts\install-ai.ps1"
Write-Host ""
Write-Host "After AI installation, restart Backend and Frontend."
