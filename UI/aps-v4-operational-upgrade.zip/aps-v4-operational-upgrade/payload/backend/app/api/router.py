from fastapi import APIRouter

from app.api.routes import health, jobs, media, models, profiles, system, websocket

api_router = APIRouter()
api_router.include_router(health.router, tags=["health"])
api_router.include_router(system.router, tags=["system"])
api_router.include_router(models.router, tags=["models"])
api_router.include_router(media.router, tags=["media"])
api_router.include_router(profiles.router, tags=["profiles"])
api_router.include_router(jobs.router, prefix="/jobs", tags=["jobs"])
api_router.include_router(websocket.router, prefix="/ws", tags=["websocket"])
