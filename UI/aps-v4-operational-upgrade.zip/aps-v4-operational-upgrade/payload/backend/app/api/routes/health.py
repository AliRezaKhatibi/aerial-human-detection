from fastapi import APIRouter

from app.core.config import settings

router = APIRouter()


@router.get("/health")
async def health() -> dict[str, object]:
    return {
        "status": "ok",
        "service": "aerial-person-studio-api",
        "version": "0.4.0",
        "mock_mode": settings.mock_mode,
    }
