from fastapi import APIRouter, File, HTTPException, UploadFile

from app.schemas.media import VideoMetadata
from app.services.media_service import save_video_upload


router = APIRouter()


@router.post("/media/video", response_model=VideoMetadata, status_code=201)
async def upload_video(file: UploadFile = File(...)) -> VideoMetadata:
    try:
        return await save_video_upload(file)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
