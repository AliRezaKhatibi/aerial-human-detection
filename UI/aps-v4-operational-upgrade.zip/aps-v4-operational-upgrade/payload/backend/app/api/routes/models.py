from fastapi import APIRouter, HTTPException

from app.schemas.model import ModelInfo, ModelStatus, SelectModelRequest
from app.services.model_manager import model_manager


router = APIRouter()


@router.get("/models", response_model=ModelStatus)
def models_status() -> ModelStatus:
    return model_manager.status()


@router.post("/models/select", response_model=ModelInfo)
def select_model(payload: SelectModelRequest) -> ModelInfo:
    try:
        return model_manager.select(payload.model_id)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/models/load", response_model=ModelStatus)
def load_selected_model() -> ModelStatus:
    try:
        model_manager.ensure_loaded()
        return model_manager.status()
    except Exception as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
