from __future__ import annotations

from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


PROJECT_ROOT = Path(__file__).resolve().parents[3]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=PROJECT_ROOT / "backend" / ".env",
        env_prefix="APS_",
        extra="ignore",
    )

    env: str = "development"
    host: str = "127.0.0.1"
    port: int = 8000
    cors_origins: list[str] = [
        "http://127.0.0.1:1420",
        "http://localhost:1420",
        "tauri://localhost",
        "http://tauri.localhost",
    ]

    # When True, jobs use generated telemetry. Set False to use a real model.
    mock_mode: bool = False

    # The model manager automatically scans model_dir. model_path is only a preferred path.
    model_path: Path = PROJECT_ROOT / "models" / "best.pt"
    model_dir: Path = PROJECT_ROOT / "models"

    database_url: str = f"sqlite+aiosqlite:///{PROJECT_ROOT / 'runtime' / 'aerial_person_studio.db'}"
    upload_dir: Path = PROJECT_ROOT / "runtime" / "uploads"
    output_dir: Path = PROJECT_ROOT / "runtime" / "outputs"
    report_dir: Path = PROJECT_ROOT / "runtime" / "reports"
    log_dir: Path = PROJECT_ROOT / "runtime" / "logs"

    device: str = "0"
    half: bool = True
    max_upload_gb: float = 20.0
    preview_interval_frames: int = 8
    telemetry_interval_frames: int = 5
    log_level: str = "INFO"


settings = Settings()


def _resolve_runtime_path(path: Path) -> Path:
    if path.is_absolute():
        return path.resolve()
    # Existing v2/v3 environment files used paths such as ../models/best.pt
    # because the backend process starts inside the backend directory.
    if path.parts and path.parts[0] == "..":
        return (PROJECT_ROOT / "backend" / path).resolve()
    return (PROJECT_ROOT / path).resolve()


settings.model_path = _resolve_runtime_path(settings.model_path)
settings.model_dir = _resolve_runtime_path(settings.model_dir)
settings.upload_dir = _resolve_runtime_path(settings.upload_dir)
settings.output_dir = _resolve_runtime_path(settings.output_dir)
settings.report_dir = _resolve_runtime_path(settings.report_dir)
settings.log_dir = _resolve_runtime_path(settings.log_dir)

for directory in (
    settings.model_dir,
    settings.upload_dir,
    settings.output_dir,
    settings.report_dir,
    settings.log_dir,
):
    directory.mkdir(parents=True, exist_ok=True)
