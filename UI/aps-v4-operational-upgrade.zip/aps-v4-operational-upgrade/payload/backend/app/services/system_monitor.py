from __future__ import annotations

import importlib.util
import platform
import shutil

import psutil

from app.core.config import settings
from app.schemas.system import SystemStatus
from app.services.model_manager import model_manager


def _gpu_info() -> tuple[str | None, float | None, float | None, float | None]:
    try:
        import pynvml

        pynvml.nvmlInit()
        handle = pynvml.nvmlDeviceGetHandleByIndex(0)
        name = pynvml.nvmlDeviceGetName(handle)
        if isinstance(name, bytes):
            name = name.decode("utf-8")
        util = pynvml.nvmlDeviceGetUtilizationRates(handle)
        memory = pynvml.nvmlDeviceGetMemoryInfo(handle)
        return str(name), float(util.gpu), memory.used / 1024**2, memory.total / 1024**2
    except Exception:
        return None, None, None, None


def get_system_status() -> SystemStatus:
    gpu_name, gpu_usage, vram_used, vram_total = _gpu_info()
    model_status = model_manager.status()
    cv_ready = importlib.util.find_spec("cv2") is not None
    ultralytics_ready = importlib.util.find_spec("ultralytics") is not None
    free_space = shutil.disk_usage(settings.output_dir).free / 1024**3

    return SystemStatus(
        platform=f"{platform.system()} {platform.release()}",
        cpu_percent=psutil.cpu_percent(interval=None),
        memory_percent=psutil.virtual_memory().percent,
        gpu_name=gpu_name,
        gpu_usage_percent=gpu_usage,
        vram_used_mb=round(vram_used, 1) if vram_used is not None else None,
        vram_total_mb=round(vram_total, 1) if vram_total is not None else None,
        model_available=model_status.available,
        model_loaded=model_status.loaded,
        model_name=model_status.selected_model.name if model_status.selected_model else None,
        model_error=model_status.error,
        inference_backend=model_status.backend if model_status.available else (
            "Mock" if settings.mock_mode else "Unavailable"
        ),
        storage_free_gb=round(free_space, 2),
        ai_dependencies_ready=ultralytics_ready and cv_ready,
        video_engine_ready=cv_ready,
        tracking_ready=ultralytics_ready,
    )
