from __future__ import annotations

import hashlib
import threading
from pathlib import Path
from typing import Any

from app.core.config import settings
from app.schemas.model import ModelInfo, ModelStatus


SUPPORTED_MODEL_SUFFIXES = {".pt", ".onnx", ".engine", ".plan"}


class ModelManager:
    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._model: Any | None = None
        self._selected_path: Path | None = None
        self._error: str | None = None

    @staticmethod
    def _model_id(path: Path) -> str:
        return hashlib.sha1(str(path.resolve()).encode("utf-8")).hexdigest()[:12]

    def _candidate_paths(self) -> list[Path]:
        candidates = [
            path
            for path in settings.model_dir.rglob("*")
            if path.is_file() and path.suffix.lower() in SUPPORTED_MODEL_SUFFIXES
        ]

        preferred = settings.model_path
        if preferred.exists() and preferred not in candidates:
            candidates.append(preferred)

        suffix_priority = {".engine": 0, ".plan": 0, ".pt": 1, ".onnx": 2}

        def sort_key(path: Path) -> tuple[int, int, str]:
            exact_best = 0 if path.stem.lower() == "best" else 1
            return exact_best, suffix_priority.get(path.suffix.lower(), 9), path.name.lower()

        return sorted(candidates, key=sort_key)

    def list_models(self) -> list[ModelInfo]:
        selected = self.selected_path
        loaded_path = self._selected_path if self._model is not None else None
        result: list[ModelInfo] = []
        for path in self._candidate_paths():
            result.append(
                ModelInfo(
                    id=self._model_id(path),
                    name=path.name,
                    path=str(path.resolve()),
                    format=path.suffix.lower().lstrip("."),
                    size_mb=round(path.stat().st_size / 1024**2, 2),
                    selected=selected is not None and path.resolve() == selected.resolve(),
                    loaded=loaded_path is not None and path.resolve() == loaded_path.resolve(),
                )
            )
        return result

    @property
    def selected_path(self) -> Path | None:
        if self._selected_path and self._selected_path.exists():
            return self._selected_path
        preferred = settings.model_path
        if preferred.exists():
            return preferred.resolve()
        candidates = self._candidate_paths()
        return candidates[0].resolve() if candidates else None

    def select(self, model_id: str) -> ModelInfo:
        for info in self.list_models():
            if info.id == model_id:
                with self._lock:
                    next_path = Path(info.path)
                    if self._selected_path != next_path:
                        self._model = None
                    self._selected_path = next_path
                    self._error = None
                return info.model_copy(update={"selected": True})
        raise FileNotFoundError(f"Model id not found: {model_id}")

    def ensure_loaded(self, model_id: str | None = None) -> Any:
        if model_id:
            self.select(model_id)

        path = self.selected_path
        if path is None:
            raise FileNotFoundError(
                f"No supported model was found in {settings.model_dir}. "
                "Place best.pt, an ONNX model, or a TensorRT engine in the models directory."
            )

        with self._lock:
            if self._model is not None and self._selected_path == path:
                return self._model
            try:
                from ultralytics import YOLO

                self._model = YOLO(str(path), task="detect")
                self._selected_path = path
                self._error = None
                return self._model
            except Exception as exc:
                self._model = None
                self._selected_path = path
                self._error = f"{type(exc).__name__}: {exc}"
                raise RuntimeError(f"Could not load model {path.name}: {exc}") from exc

    def unload(self) -> None:
        with self._lock:
            self._model = None

    def status(self) -> ModelStatus:
        models = self.list_models()
        selected_path = self.selected_path
        selected = next(
            (item for item in models if selected_path and Path(item.path) == selected_path),
            models[0] if models else None,
        )
        if selected and self._model is not None:
            selected = selected.model_copy(update={"loaded": True, "selected": True})

        backend = "Unavailable"
        if selected:
            backend = {
                "engine": "TensorRT",
                "plan": "TensorRT",
                "onnx": "ONNX Runtime / Ultralytics",
                "pt": "PyTorch / Ultralytics",
            }.get(selected.format, selected.format.upper())

        return ModelStatus(
            available=bool(models),
            loaded=self._model is not None,
            selected_model=selected,
            models=models,
            backend=backend,
            error=self._error,
        )


model_manager = ModelManager()
