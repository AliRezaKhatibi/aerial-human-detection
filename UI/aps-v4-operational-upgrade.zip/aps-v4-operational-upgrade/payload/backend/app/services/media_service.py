from __future__ import annotations

import re
from pathlib import Path
from uuid import uuid4

from fastapi import UploadFile

from app.core.config import settings
from app.schemas.media import VideoMetadata


ALLOWED_VIDEO_SUFFIXES = {".mp4", ".mov", ".mkv", ".avi", ".m4v", ".webm"}


def _safe_name(name: str) -> str:
    original = Path(name).name
    stem = re.sub(r"[^A-Za-z0-9._-]+", "_", Path(original).stem).strip("._") or "video"
    suffix = Path(original).suffix.lower()
    return f"{stem}{suffix}"


def inspect_video(path: Path, upload_id: str | None = None) -> VideoMetadata:
    try:
        import cv2
    except ImportError as exc:
        raise RuntimeError(
            "OpenCV is not installed. Run scripts\\install-ai.ps1 and restart the backend."
        ) from exc

    capture = cv2.VideoCapture(str(path))
    if not capture.isOpened():
        raise ValueError(f"Video could not be opened: {path.name}")

    try:
        width = int(capture.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
        height = int(capture.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
        fps = float(capture.get(cv2.CAP_PROP_FPS) or 0.0)
        total_frames = int(capture.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        fourcc_value = int(capture.get(cv2.CAP_PROP_FOURCC) or 0)
        codec = "".join(chr((fourcc_value >> 8 * i) & 0xFF) for i in range(4)).strip() or "Unknown"
    finally:
        capture.release()

    duration = total_frames / fps if fps > 0 else 0.0
    return VideoMetadata(
        upload_id=upload_id or path.stem.split("_", 1)[0],
        filename=path.name.split("_", 1)[-1] if "_" in path.name else path.name,
        stored_path=str(path.resolve()),
        size_mb=round(path.stat().st_size / 1024**2, 2),
        width=width,
        height=height,
        fps=round(fps, 3),
        total_frames=total_frames,
        duration_seconds=round(duration, 3),
        codec=codec,
    )


async def save_video_upload(upload: UploadFile) -> VideoMetadata:
    filename = upload.filename or "video.mp4"
    suffix = Path(filename).suffix.lower()
    if suffix not in ALLOWED_VIDEO_SUFFIXES:
        raise ValueError(
            f"Unsupported video format: {suffix or 'none'}. "
            f"Supported formats: {', '.join(sorted(ALLOWED_VIDEO_SUFFIXES))}"
        )

    upload_id = uuid4().hex[:12]
    destination = settings.upload_dir / f"{upload_id}_{_safe_name(filename)}"
    max_bytes = int(settings.max_upload_gb * 1024**3)
    written = 0

    try:
        with destination.open("wb") as output:
            while chunk := await upload.read(4 * 1024 * 1024):
                written += len(chunk)
                if written > max_bytes:
                    raise ValueError(f"Video exceeds the {settings.max_upload_gb:.1f} GB local limit.")
                output.write(chunk)
    except Exception:
        destination.unlink(missing_ok=True)
        raise
    finally:
        await upload.close()

    return inspect_video(destination, upload_id=upload_id)
