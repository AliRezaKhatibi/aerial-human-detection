from pydantic import BaseModel


class SystemStatus(BaseModel):
    platform: str
    cpu_percent: float
    memory_percent: float
    gpu_name: str | None
    gpu_usage_percent: float | None
    vram_used_mb: float | None
    vram_total_mb: float | None
    model_available: bool
    model_loaded: bool
    model_name: str | None
    model_error: str | None
    inference_backend: str
    storage_free_gb: float
    ai_dependencies_ready: bool
    video_engine_ready: bool
    tracking_ready: bool
