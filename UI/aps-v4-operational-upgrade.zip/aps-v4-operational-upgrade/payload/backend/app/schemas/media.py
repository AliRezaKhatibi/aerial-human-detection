from __future__ import annotations

from pydantic import BaseModel


class VideoMetadata(BaseModel):
    upload_id: str
    filename: str
    stored_path: str
    size_mb: float
    width: int
    height: int
    fps: float
    total_frames: int
    duration_seconds: float
    codec: str
