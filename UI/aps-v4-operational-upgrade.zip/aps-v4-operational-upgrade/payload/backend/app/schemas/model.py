from __future__ import annotations

from pydantic import BaseModel, Field


class ModelInfo(BaseModel):
    id: str
    name: str
    path: str
    format: str
    size_mb: float
    selected: bool = False
    loaded: bool = False


class ModelStatus(BaseModel):
    available: bool
    loaded: bool
    selected_model: ModelInfo | None = None
    models: list[ModelInfo] = Field(default_factory=list)
    backend: str = "Unavailable"
    error: str | None = None


class SelectModelRequest(BaseModel):
    model_id: str
