from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True, slots=True)
class Tile:
    x1: int
    y1: int
    x2: int
    y2: int

    @property
    def width(self) -> int:
        return self.x2 - self.x1

    @property
    def height(self) -> int:
        return self.y2 - self.y1


def generate_tiles(width: int, height: int, tile_size: int = 768, overlap: float = 0.20) -> list[Tile]:
    tile_w = min(tile_size, width)
    tile_h = min(tile_size, height)
    stride_x = max(1, int(tile_w * (1.0 - overlap)))
    stride_y = max(1, int(tile_h * (1.0 - overlap)))

    xs = list(range(0, max(1, width - tile_w + 1), stride_x))
    ys = list(range(0, max(1, height - tile_h + 1), stride_y))
    last_x = max(0, width - tile_w)
    last_y = max(0, height - tile_h)
    if not xs or xs[-1] != last_x:
        xs.append(last_x)
    if not ys or ys[-1] != last_y:
        ys.append(last_y)

    return [Tile(x, y, min(width, x + tile_w), min(height, y + tile_h)) for y in ys for x in xs]


def select_balanced_tiles(
    tiles: list[Tile],
    full_detections: np.ndarray,
    frame_width: int,
    frame_height: int,
    frame_index: int,
    max_tiles: int = 2,
) -> list[Tile]:
    if len(tiles) <= max_tiles:
        return tiles

    if len(full_detections) == 0:
        start = (frame_index // 5 * max_tiles) % len(tiles)
        return [tiles[(start + offset) % len(tiles)] for offset in range(max_tiles)]

    frame_area = max(1.0, float(frame_width * frame_height))
    scored: list[tuple[float, int, Tile]] = []
    for index, tile in enumerate(tiles):
        score = 0.0
        for x1, y1, x2, y2, confidence, _ in full_detections:
            cx = (x1 + x2) / 2.0
            cy = (y1 + y2) / 2.0
            if tile.x1 <= cx <= tile.x2 and tile.y1 <= cy <= tile.y2:
                object_area = max(1.0, float((x2 - x1) * (y2 - y1)))
                smallness = min(5.0, 0.006 * frame_area / object_area)
                uncertainty = max(0.0, 0.55 - float(confidence)) * 3.0
                score += 1.0 + smallness + uncertainty
        scored.append((score, -index, tile))

    scored.sort(reverse=True, key=lambda item: (item[0], item[1]))
    selected = [item[2] for item in scored[:max_tiles] if item[0] > 0]
    if len(selected) < max_tiles:
        for tile in tiles:
            if tile not in selected:
                selected.append(tile)
            if len(selected) >= max_tiles:
                break
    return selected
