from __future__ import annotations

import numpy as np


def _iou_one_to_many(box: np.ndarray, boxes: np.ndarray) -> np.ndarray:
    x1 = np.maximum(box[0], boxes[:, 0])
    y1 = np.maximum(box[1], boxes[:, 1])
    x2 = np.minimum(box[2], boxes[:, 2])
    y2 = np.minimum(box[3], boxes[:, 3])
    intersection = np.maximum(0.0, x2 - x1) * np.maximum(0.0, y2 - y1)
    area_a = max(0.0, float(box[2] - box[0])) * max(0.0, float(box[3] - box[1]))
    area_b = np.maximum(0.0, boxes[:, 2] - boxes[:, 0]) * np.maximum(0.0, boxes[:, 3] - boxes[:, 1])
    return intersection / np.maximum(area_a + area_b - intersection, 1e-6)


def nms_fusion(detections: list[np.ndarray], iou_threshold: float = 0.55) -> np.ndarray:
    valid = [array for array in detections if array is not None and len(array) > 0]
    if not valid:
        return np.empty((0, 6), dtype=np.float32)
    merged = np.concatenate(valid, axis=0).astype(np.float32, copy=False)
    order = np.argsort(-merged[:, 4])
    keep: list[int] = []

    while order.size > 0:
        current = int(order[0])
        keep.append(current)
        if order.size == 1:
            break
        remaining = order[1:]
        ious = _iou_one_to_many(merged[current, :4], merged[remaining, :4])
        class_match = merged[remaining, 5] == merged[current, 5]
        suppress = (ious > iou_threshold) & class_match
        order = remaining[~suppress]

    return merged[np.asarray(keep, dtype=np.int64)]
