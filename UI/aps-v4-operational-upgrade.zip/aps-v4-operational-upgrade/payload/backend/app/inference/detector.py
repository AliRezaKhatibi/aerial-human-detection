from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np

from app.core.config import settings


@dataclass(slots=True)
class DetectionBatch:
    boxes: np.ndarray  # shape (N, 6): x1, y1, x2, y2, confidence, class_id
    inference_ms: float


class Detector:
    def __init__(self, model: Any) -> None:
        self.model = model
        self._device = self._resolve_device()

    @staticmethod
    def _resolve_device() -> str | int:
        try:
            import torch

            if str(settings.device).lower() in {"cpu", "-1"} or not torch.cuda.is_available():
                return "cpu"
            return int(settings.device) if str(settings.device).isdigit() else settings.device
        except Exception:
            return "cpu"

    def infer(self, frame: np.ndarray, imgsz: int, confidence: float) -> DetectionBatch:
        results = self.model.predict(
            source=frame,
            imgsz=imgsz,
            conf=confidence,
            iou=0.70,
            max_det=1000,
            classes=[0],
            single_cls=True,
            device=self._device,
            half=bool(settings.half and self._device != "cpu"),
            verbose=False,
        )
        result = results[0]
        inference_ms = float((result.speed or {}).get("inference", 0.0))
        if result.boxes is None or len(result.boxes) == 0:
            return DetectionBatch(np.empty((0, 6), dtype=np.float32), inference_ms)

        xyxy = result.boxes.xyxy.detach().cpu().numpy().astype(np.float32)
        conf = result.boxes.conf.detach().cpu().numpy().astype(np.float32)[:, None]
        cls = result.boxes.cls.detach().cpu().numpy().astype(np.float32)[:, None]
        return DetectionBatch(np.concatenate([xyxy, conf, cls], axis=1), inference_ms)
