from __future__ import annotations

from dataclasses import dataclass
from types import SimpleNamespace

import numpy as np


@dataclass(slots=True)
class Track:
    x1: float
    y1: float
    x2: float
    y2: float
    track_id: int
    confidence: float
    class_id: int


class ByteTrackAdapter:
    def __init__(self, frame_rate: float = 30.0) -> None:
        try:
            from ultralytics.trackers.byte_tracker import BYTETracker
        except ImportError as exc:
            raise RuntimeError("Ultralytics tracking components are not installed.") from exc

        args = SimpleNamespace(
            track_high_thresh=0.25,
            track_low_thresh=0.05,
            new_track_thresh=0.25,
            track_buffer=max(30, int(round(frame_rate))),
            match_thresh=0.80,
            fuse_score=True,
        )
        try:
            self._tracker = BYTETracker(args, frame_rate=int(max(1, round(frame_rate))))
        except TypeError:
            self._tracker = BYTETracker(args)

    def update(self, detections: np.ndarray, frame: np.ndarray) -> list[Track]:
        import torch
        from ultralytics.engine.results import Boxes

        if len(detections) == 0:
            tensor = torch.empty((0, 6), dtype=torch.float32)
        else:
            tensor = torch.as_tensor(detections, dtype=torch.float32)
        boxes = Boxes(tensor, orig_shape=frame.shape[:2])
        tracked = self._tracker.update(boxes, frame)
        if tracked is None or len(tracked) == 0:
            return []

        rows = np.asarray(tracked)
        result: list[Track] = []
        for row in rows:
            if len(row) < 7:
                continue
            result.append(
                Track(
                    x1=float(row[0]),
                    y1=float(row[1]),
                    x2=float(row[2]),
                    y2=float(row[3]),
                    track_id=int(row[4]),
                    confidence=float(row[5]),
                    class_id=int(row[6]),
                )
            )
        return result
