$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$Python = Join-Path $ProjectRoot "backend\.venv\Scripts\python.exe"

if (-not (Test-Path $Python)) { throw "Backend virtual environment is missing." }

Write-Host "[1/3] Backend tests..." -ForegroundColor Yellow
Push-Location (Join-Path $ProjectRoot "backend")
try {
    & $Python -m pytest -q
    if ($LASTEXITCODE -ne 0) { throw "Backend tests failed." }
}
finally { Pop-Location }

Write-Host "[2/3] Backend imports..." -ForegroundColor Yellow
Push-Location (Join-Path $ProjectRoot "backend")
try {
    & $Python -c "from app.main import app; from app.services.model_manager import model_manager; print(model_manager.status().model_dump_json(indent=2))"
    if ($LASTEXITCODE -ne 0) { throw "Backend import verification failed." }
}
finally { Pop-Location }

Write-Host "[3/3] Frontend production build..." -ForegroundColor Yellow
& npm --prefix (Join-Path $ProjectRoot "frontend") run build
if ($LASTEXITCODE -ne 0) { throw "Frontend build failed." }

Write-Host "V4 verification completed successfully." -ForegroundColor Green
