import { API_BASE_URL } from "./config";
import type {
  CreateJobPayload,
  HealthResponse,
  InferenceProfile,
  Job,
  ModelInfo,
  ModelStatus,
  SystemStatus,
  VideoMetadata,
} from "@/types/api";

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const isFormData = init?.body instanceof FormData;
  const response = await fetch(`${API_BASE_URL}${path}`, {
    ...init,
    headers: isFormData
      ? init?.headers
      : { "Content-Type": "application/json", ...(init?.headers ?? {}) },
  });
  if (!response.ok) {
    let detail = await response.text();
    try {
      const parsed = JSON.parse(detail) as { detail?: string };
      detail = parsed.detail ?? detail;
    } catch {
      // Keep plain response text.
    }
    throw new Error(detail || `API error ${response.status}`);
  }
  return response.json() as Promise<T>;
}

export const api = {
  health: () => request<HealthResponse>("/health"),
  system: () => request<SystemStatus>("/system"),
  models: () => request<ModelStatus>("/models"),
  selectModel: (modelId: string) =>
    request<ModelInfo>("/models/select", {
      method: "POST",
      body: JSON.stringify({ model_id: modelId }),
    }),
  loadModel: () => request<ModelStatus>("/models/load", { method: "POST" }),
  uploadVideo: (file: File) => {
    const form = new FormData();
    form.append("file", file);
    return request<VideoMetadata>("/media/video", { method: "POST", body: form });
  },
  profiles: () => request<InferenceProfile[]>("/profiles"),
  jobs: () => request<Job[]>("/jobs"),
  job: (jobId: string) => request<Job>(`/jobs/${jobId}`),
  createJob: (payload: CreateJobPayload) =>
    request<Job>("/jobs", { method: "POST", body: JSON.stringify(payload) }),
  createMockJob: (profile = "balanced", sourcePath = "demo.mp4") =>
    request<Job>("/jobs", {
      method: "POST",
      body: JSON.stringify({
        source_type: "mock",
        source_path: sourcePath,
        profile,
        confidence: 0.2,
        show_trails: true,
        show_track_ids: true,
        show_confidence: true,
        save_video: false,
        save_csv: false,
        save_json: false,
      }),
    }),
  cancelJob: (jobId: string) => request<Job>(`/jobs/${jobId}/cancel`, { method: "POST" }),
  previewUrl: (jobId: string, version = 0) => `${API_BASE_URL}/jobs/${jobId}/preview?v=${version}`,
  outputUrl: (jobId: string) => `${API_BASE_URL}/jobs/${jobId}/output`,
  csvUrl: (jobId: string) => `${API_BASE_URL}/jobs/${jobId}/report.csv`,
  jsonUrl: (jobId: string) => `${API_BASE_URL}/jobs/${jobId}/report.json`,
};
