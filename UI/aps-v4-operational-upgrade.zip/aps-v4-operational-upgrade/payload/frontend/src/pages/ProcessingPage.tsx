import {
  Activity,
  CircleAlert,
  Download,
  FileJson,
  FileSpreadsheet,
  Maximize2,
  Radio,
  Square,
  Users,
  Video,
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useMemo } from "react";
import { Link, useParams } from "react-router-dom";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Card, CardHeader } from "@/components/ui/Card";
import { ProgressBar } from "@/components/ui/ProgressBar";
import { PageHeader } from "@/components/PageHeader";
import { useJobSocket } from "@/hooks/use-job-socket";
import { api } from "@/lib/api";

export function ProcessingPage() {
  const { jobId } = useParams();
  const { job: socketJob, connected } = useJobSocket(jobId);
  const jobQuery = useQuery({
    queryKey: ["job", jobId],
    queryFn: () => api.job(jobId as string),
    enabled: Boolean(jobId),
    refetchInterval: socketJob ? false : 2000,
    retry: 1,
  });
  const job = socketJob ?? jobQuery.data ?? null;
  const progress = job?.progress ?? 0;
  const completed = job?.status === "completed";
  const failed = job?.status === "failed";
  const running = job?.status === "running" || job?.status === "queued";

  const telemetry = useMemo(
    () => [
      { label: "FPS", value: (job?.fps ?? 0).toFixed(1), caption: "سرعت کل خط لوله" },
      { label: "Inference", value: `${(job?.inference_ms ?? 0).toFixed(1)} ms`, caption: "زمان مدل در فریم اخیر" },
      { label: "افراد فعال", value: String(job?.active_tracks ?? 0), caption: "در فریم جاری" },
      { label: "افراد یکتا", value: String(job?.unique_tracks ?? 0), caption: "از شروع پردازش" },
      { label: "Confidence", value: `${Math.round((job?.mean_confidence ?? 0) * 100)}%`, caption: "میانگین خروجی قابل نمایش" },
      { label: "Tile", value: String(job?.processed_tiles ?? 0), caption: job?.tiling_active ? "در فریم جاری فعال" : "Full-frame" },
    ],
    [job],
  );

  if (!jobId) {
    return (
      <div className="space-y-6">
        <PageHeader title="پردازش زنده" description="برای مشاهده تله‌متری، ابتدا یک تحلیل جدید ایجاد کنید." />
        <Card className="grid min-h-[420px] place-items-center p-8 text-center"><div><Radio size={40} className="mx-auto text-[#33d3bb]" /><h3 className="mt-5 text-lg font-black">Job فعالی انتخاب نشده است</h3><p className="mt-2 text-xs text-[var(--muted)]">از صفحه تحلیل جدید یک ویدئو انتخاب کنید.</p><Link to="/analysis/new"><Button className="mt-6">ایجاد تحلیل جدید</Button></Link></div></Card>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <PageHeader
        eyebrow="Live workspace"
        title={completed ? "پردازش با موفقیت تکمیل شد" : failed ? "پردازش متوقف شد" : "پردازش زنده ویدئو"}
        description={`${job?.source_name ?? "ویدئو"} · Job ID: ${jobId}`}
        actions={
          <>
            <Badge tone={connected ? "green" : "amber"} dot>{connected ? "WebSocket متصل" : "در حال اتصال"}</Badge>
            <Badge tone={job?.profile === "accuracy" ? "amber" : job?.profile === "fast" ? "blue" : "green"}>{job?.profile ?? "balanced"}</Badge>
            <Badge tone={completed ? "green" : failed ? "red" : "gray"}>{job?.status ?? "loading"}</Badge>
          </>
        }
      />

      {failed && job?.error && (
        <div className="flex items-start gap-3 rounded-2xl border border-[#ff6c85]/25 bg-[#ff6c85]/8 p-4 text-xs leading-6 text-[#ff9bad]"><CircleAlert className="mt-0.5 shrink-0" size={18} /><div><div className="font-black">خطای موتور پردازش</div><div className="mt-1" dir="ltr">{job.error}</div></div></div>
      )}

      <div className="grid grid-cols-1 gap-4 2xl:grid-cols-[1fr_340px]">
        <Card className="overflow-hidden">
          <div className="relative aspect-video min-h-[360px] bg-[#03060a] metric-grid lg:min-h-[520px]">
            {completed && job?.output_video_path ? (
              <video controls className="h-full w-full object-contain" src={api.outputUrl(jobId)} />
            ) : job?.preview_available ? (
              <img
                key={job.frame}
                src={api.previewUrl(jobId, job.frame)}
                alt="پیش‌نمایش پردازش"
                className="h-full w-full object-contain"
              />
            ) : (
              <div className="absolute inset-0 grid place-items-center p-6"><div className="text-center"><div className="mx-auto grid h-16 w-16 place-items-center rounded-full border border-[#33d3bb]/22 bg-[#33d3bb]/8"><Radio className="animate-pulse text-[#33d3bb]" size={30} /></div><div className="mt-5 text-sm font-bold">در انتظار اولین فریم پردازش‌شده</div><div className="mt-2 text-xs leading-6 text-[var(--muted-2)]">بارگذاری مدل و Warm-up اولیه ممکن است چند ثانیه طول بکشد.</div></div></div>
            )}
            <div className="absolute left-4 top-4 flex gap-2"><Badge tone={running ? "red" : "gray"} dot>{running ? "LIVE" : completed ? "DONE" : "STOPPED"}</Badge><Badge tone="gray"><span dir="ltr">{job?.model_name ?? "Model loading"}</span></Badge></div>
            <div className="absolute right-4 top-4"><Badge tone={job?.tiling_active ? "green" : "gray"}>{job?.tiling_active ? `ATTI · ${job.processed_tiles} Tile` : "Full-frame"}</Badge></div>
            <Button variant="ghost" className="absolute bottom-4 left-4 h-10 w-10 bg-black/25 p-0"><Maximize2 size={18} /></Button>
          </div>
          <div className="flex flex-col justify-between gap-3 border-t border-[var(--border)] px-5 py-4 sm:flex-row sm:items-center">
            <div className="flex flex-wrap gap-2">
              {running && <Button variant="danger" onClick={() => void api.cancelJob(jobId)}><Square size={15} /> توقف پردازش</Button>}
              {completed && job?.output_video_path && <a href={api.outputUrl(jobId)} download><Button><Video size={16} /> دریافت ویدئو</Button></a>}
              {completed && job?.report_csv_path && <a href={api.csvUrl(jobId)} download><Button variant="secondary"><FileSpreadsheet size={16} /> CSV</Button></a>}
              {completed && job?.report_json_path && <a href={api.jsonUrl(jobId)} download><Button variant="secondary"><FileJson size={16} /> JSON</Button></a>}
            </div>
            <div className="text-xs text-[var(--muted)]" dir="ltr">Frame {(job?.frame ?? 0).toLocaleString()} / {(job?.total_frames ?? 0).toLocaleString()}</div>
          </div>
        </Card>

        <div className="grid grid-cols-2 gap-3 2xl:grid-cols-1">
          {telemetry.map((item, index) => (
            <Card key={item.label} className="p-4"><div className="flex items-start justify-between"><div><div className="text-[10px] font-semibold text-[var(--muted-2)]">{item.label}</div><div className="mt-1 text-xl font-black" dir="ltr">{item.value}</div><div className="mt-1 text-[10px] text-[var(--muted-2)]">{item.caption}</div></div>{index >= 2 ? <Users size={18} className="text-[#33d3bb]" /> : <Activity size={18} className="text-[#7d8dff]" />}</div></Card>
          ))}
        </div>
      </div>

      <Card>
        <CardHeader title="پیشرفت پردازش" description={job?.status ? `وضعیت: ${job.status}` : "در انتظار داده"} action={<span className="text-sm font-black" dir="ltr">{progress.toFixed(1)}%</span>} />
        <div className="p-5">
          <ProgressBar value={progress} className="h-2.5" />
          <div className="mt-3 flex justify-between text-[10px] text-[var(--muted-2)]"><span>شروع</span><span>{completed ? "تکمیل شد" : failed ? "ناموفق" : "در حال پردازش"}</span><span dir="ltr">{(job?.elapsed_seconds ?? 0).toFixed(1)} s</span></div>
        </div>
      </Card>

      {completed && (
        <Card className="p-5"><div className="flex flex-col justify-between gap-4 md:flex-row md:items-center"><div><div className="flex items-center gap-2 text-sm font-black"><Download size={18} className="text-[#33d3bb]" /> خروجی‌ها آماده‌اند</div><p className="mt-2 text-xs leading-6 text-[var(--muted)]">ویدئوی نشانه‌گذاری‌شده و گزارش‌های Track از همین صفحه قابل دریافت‌اند.</p></div><Link to="/analysis/new"><Button variant="secondary">تحلیل ویدئوی دیگر</Button></Link></div></Card>
      )}
    </div>
  );
}
