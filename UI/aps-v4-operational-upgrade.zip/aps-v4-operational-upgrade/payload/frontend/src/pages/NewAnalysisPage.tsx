import {
  Camera,
  CheckCircle2,
  CircleAlert,
  Cpu,
  FileCheck2,
  FileVideo2,
  FolderOpen,
  Gauge,
  HardDrive,
  Info,
  Radio,
  SlidersHorizontal,
  Sparkles,
  UploadCloud,
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ProfileCard } from "@/components/ProfileCard";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/Button";
import { Card, CardHeader } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Toggle } from "@/components/ui/Toggle";
import { api } from "@/lib/api";
import { useAppStore, type InferenceMode } from "@/stores/app-store";
import type { VideoMetadata } from "@/types/api";

const sourceTypes = [
  { id: "video", icon: FileVideo2, title: "فایل ویدئویی", description: "MP4، MOV، MKV، AVI و WEBM", state: "فعال" },
  { id: "camera", icon: Camera, title: "دوربین محلی", description: "وب‌کم یا Capture Card", state: "به‌زودی" },
  { id: "rtsp", icon: Radio, title: "جریان RTSP", description: "دوربین شبکه و پهپاد", state: "به‌زودی" },
];

function formatDuration(seconds: number) {
  const total = Math.max(0, Math.round(seconds));
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const secs = total % 60;
  return [hours, minutes, secs].map((item) => String(item).padStart(2, "0")).join(":");
}

export function NewAnalysisPage() {
  const selectedProfile = useAppStore((state) => state.selectedProfile);
  const setSelectedProfile = useAppStore((state) => state.setSelectedProfile);
  const [profile, setProfileLocal] = useState<InferenceMode>(selectedProfile);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [metadata, setMetadata] = useState<VideoMetadata | null>(null);
  const [selectedModelId, setSelectedModelId] = useState("");
  const [confidence, setConfidence] = useState(0.2);
  const [showTrails, setShowTrails] = useState(true);
  const [showTrackIds, setShowTrackIds] = useState(true);
  const [showConfidence, setShowConfidence] = useState(true);
  const [saveVideo, setSaveVideo] = useState(true);
  const [saveCsv, setSaveCsv] = useState(true);
  const [saveJson, setSaveJson] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [starting, setStarting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  const systemQuery = useQuery({ queryKey: ["system-preflight"], queryFn: api.system, refetchInterval: 5000, retry: 1 });
  const modelsQuery = useQuery({ queryKey: ["models"], queryFn: api.models, refetchInterval: 5000, retry: 1 });
  const system = systemQuery.data;
  const models = modelsQuery.data?.models ?? [];

  useEffect(() => {
    if (!selectedModelId && modelsQuery.data?.selected_model?.id) {
      setSelectedModelId(modelsQuery.data.selected_model.id);
    }
  }, [modelsQuery.data, selectedModelId]);

  const setProfile = (next: InferenceMode) => {
    setProfileLocal(next);
    setSelectedProfile(next);
  };

  const handleFile = async (file: File | null) => {
    setSelectedFile(file);
    setMetadata(null);
    setError(null);
    if (!file) return;
    setUploading(true);
    try {
      const result = await api.uploadVideo(file);
      setMetadata(result);
    } catch (uploadError) {
      setError(uploadError instanceof Error ? uploadError.message : "آپلود ویدئو ناموفق بود.");
    } finally {
      setUploading(false);
    }
  };

  const preflight = useMemo(
    () => [
      {
        label: "اتصال Backend",
        detail: systemQuery.isSuccess ? "API در دسترس است" : "Backend پاسخ نمی‌دهد",
        ready: systemQuery.isSuccess,
        icon: Gauge,
      },
      {
        label: "موتور هوش مصنوعی",
        detail: system?.ai_dependencies_ready ? "Ultralytics و OpenCV نصب‌اند" : "اسکریپت install-ai.ps1 را اجرا کنید",
        ready: Boolean(system?.ai_dependencies_ready),
        icon: Sparkles,
      },
      {
        label: "مدل آموزش‌دیده",
        detail: modelsQuery.data?.selected_model?.name ?? "مدلی در پوشه models پیدا نشد",
        ready: Boolean(modelsQuery.data?.available && selectedModelId),
        icon: Cpu,
      },
      {
        label: "ویدئوی ورودی",
        detail: metadata ? `${metadata.width}×${metadata.height} · ${metadata.total_frames.toLocaleString()} فریم` : "هنوز ویدئو آماده نشده است",
        ready: Boolean(metadata),
        icon: FileCheck2,
      },
      {
        label: "فضای ذخیره‌سازی",
        detail: system ? `${system.storage_free_gb.toFixed(1)} GB فضای آزاد` : "در حال بررسی",
        ready: Boolean(system && system.storage_free_gb > 2),
        icon: HardDrive,
      },
    ],
    [metadata, modelsQuery.data, selectedModelId, system, systemQuery.isSuccess],
  );

  const ready = preflight.every((item) => item.ready) && !uploading && !starting;

  const startAnalysis = async () => {
    if (!metadata || !selectedModelId) return;
    setStarting(true);
    setError(null);
    try {
      await api.selectModel(selectedModelId);
      await api.loadModel();
      const job = await api.createJob({
        source_type: "video",
        source_path: metadata.stored_path,
        source_name: metadata.filename,
        profile,
        confidence,
        show_trails: showTrails,
        show_track_ids: showTrackIds,
        show_confidence: showConfidence,
        save_video: saveVideo,
        save_csv: saveCsv,
        save_json: saveJson,
        model_id: selectedModelId,
      });
      navigate(`/processing/${job.id}`);
    } catch (startError) {
      setError(startError instanceof Error ? startError.message : "شروع تحلیل ناموفق بود.");
    } finally {
      setStarting(false);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="New analysis"
        title="ایجاد تحلیل واقعی ویدئو"
        description="ویدئو را انتخاب کنید، مدل آموزش‌دیده و پروفایل اجرا را بررسی کنید و پردازش GPU را آغاز کنید."
        actions={
          <Badge tone={system?.ai_dependencies_ready && modelsQuery.data?.available ? "green" : "amber"} dot>
            {system?.ai_dependencies_ready && modelsQuery.data?.available ? "آماده پردازش" : "نیازمند تکمیل پیش‌نیاز"}
          </Badge>
        }
      />

      {error && (
        <div className="flex items-start gap-3 rounded-2xl border border-[#ff6c85]/25 bg-[#ff6c85]/8 p-4 text-xs leading-6 text-[#ff9bad]">
          <CircleAlert className="mt-0.5 shrink-0" size={18} />
          <div><div className="font-black">عملیات انجام نشد</div><div className="mt-1" dir="ltr">{error}</div></div>
        </div>
      )}

      <div className="grid grid-cols-1 gap-4 2xl:grid-cols-[1.45fr_0.75fr]">
        <Card className="p-5 sm:p-6">
          <input
            ref={inputRef}
            type="file"
            accept="video/mp4,video/quicktime,video/x-matroska,video/x-msvideo,video/webm"
            className="hidden"
            onChange={(event) => void handleFile(event.target.files?.[0] ?? null)}
          />
          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            onDragOver={(event) => event.preventDefault()}
            onDrop={(event) => {
              event.preventDefault();
              void handleFile(event.dataTransfer.files?.[0] ?? null);
            }}
            className="focus-ring metric-grid grid min-h-[330px] w-full place-items-center rounded-2xl border border-dashed border-[#33d3bb]/28 bg-[#33d3bb]/[.03] p-6 text-center transition hover:border-[#33d3bb]/48 hover:bg-[#33d3bb]/[.055]"
          >
            <div className="w-full max-w-3xl">
              <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-[#33d3bb]/10 text-[#57dec9]">
                <UploadCloud size={28} className={uploading ? "animate-bounce" : ""} />
              </div>
              <h3 className="mt-5 font-black">
                {uploading ? "در حال انتقال و بررسی ویدئو..." : selectedFile ? selectedFile.name : "ویدئو را اینجا رها کنید"}
              </h3>
              <p className="mt-2 text-xs leading-6 text-[var(--muted)]">
                {metadata
                  ? `${metadata.size_mb.toFixed(1)} MB · ${metadata.width}×${metadata.height} · ${metadata.fps.toFixed(2)} FPS · ${formatDuration(metadata.duration_seconds)}`
                  : selectedFile
                    ? "فایل روی Backend محلی بررسی می‌شود"
                    : "پردازش کاملاً روی سیستم شما انجام می‌شود و فایل به اینترنت ارسال نمی‌شود"}
              </p>
              <span className="mt-5 inline-flex items-center gap-2 rounded-xl border border-[var(--border)] bg-white/[.055] px-4 py-2.5 text-sm font-bold">
                <FolderOpen size={16} /> {selectedFile ? "تغییر فایل" : "انتخاب فایل"}
              </span>

              {metadata && (
                <div className="mt-6 grid grid-cols-2 gap-2 text-right sm:grid-cols-3 lg:grid-cols-6">
                  {[
                    ["رزولوشن", `${metadata.width}×${metadata.height}`],
                    ["نرخ فریم", `${metadata.fps.toFixed(2)} FPS`],
                    ["مدت", formatDuration(metadata.duration_seconds)],
                    ["تعداد فریم", metadata.total_frames.toLocaleString()],
                    ["Codec", metadata.codec],
                    ["حجم", `${metadata.size_mb.toFixed(1)} MB`],
                  ].map(([label, value]) => (
                    <div key={label} className="rounded-xl border border-[var(--border)] bg-black/10 p-3">
                      <div className="text-[9px] text-[var(--muted-2)]">{label}</div>
                      <div className="mt-1 truncate text-xs font-black" dir="ltr">{value}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </button>
        </Card>

        <div className="space-y-4">
          <Card>
            <CardHeader title="نوع منبع" description="ورودی موردنظر برای تحلیل" />
            <div className="space-y-3 p-5">
              {sourceTypes.map(({ id, icon: Icon, title, description, state }) => (
                <button key={id} disabled={id !== "video"} className="focus-ring flex w-full items-center justify-between rounded-xl border border-[var(--border)] bg-white/[.025] p-4 text-right transition hover:bg-white/[.05] disabled:cursor-not-allowed disabled:opacity-55">
                  <div className="flex items-center gap-3"><div className="grid h-10 w-10 place-items-center rounded-xl bg-white/[.045]"><Icon size={18} className="text-[#5adcc9]" /></div><div><div className="text-xs font-bold">{title}</div><div className="mt-1 text-[10px] text-[var(--muted-2)]">{description}</div></div></div>
                  <Badge tone={id === "video" ? "green" : "gray"}>{state}</Badge>
                </button>
              ))}
            </div>
          </Card>

          <Card>
            <CardHeader title="مدل استنتاج" description="مدل‌های موجود در پوشه models" action={<Badge tone={models.length ? "green" : "amber"}>{models.length} مدل</Badge>} />
            <div className="p-5">
              <label className="text-[10px] font-bold text-[var(--muted)]">مدل انتخاب‌شده</label>
              <select
                value={selectedModelId}
                onChange={(event) => setSelectedModelId(event.target.value)}
                className="focus-ring mt-2 w-full rounded-xl border border-[var(--border)] bg-[var(--panel-strong)] px-3 py-3 text-xs outline-none"
              >
                <option value="">انتخاب مدل</option>
                {models.map((model) => <option value={model.id} key={model.id}>{model.name} · {model.format.toUpperCase()} · {model.size_mb.toFixed(1)} MB</option>)}
              </select>
              <div className="mt-3 flex items-center justify-between text-[10px] text-[var(--muted-2)]"><span>Backend</span><span dir="ltr">{modelsQuery.data?.backend ?? "—"}</span></div>
            </div>
          </Card>
        </div>
      </div>

      <section>
        <div className="mb-4"><h3 className="text-base font-black">پروفایل پردازش</h3><p className="mt-1 text-xs text-[var(--muted-2)]">Fast فقط Full-frame، Balanced دارای Tiling تطبیقی و Accuracy دارای Tiling گسترده است.</p></div>
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3"><ProfileCard kind="fast" selected={profile === "fast"} onClick={() => setProfile("fast")} /><ProfileCard kind="balanced" selected={profile === "balanced"} onClick={() => setProfile("balanced")} /><ProfileCard kind="accuracy" selected={profile === "accuracy"} onClick={() => setProfile("accuracy")} /></div>
      </section>

      <Card>
        <CardHeader title={<span className="flex items-center gap-2"><SlidersHorizontal size={17} className="text-[#33d3bb]" /> تنظیمات پردازش و خروجی</span>} description="این تنظیمات مستقیماً به موتور استنتاج ارسال می‌شوند" />
        <div className="grid grid-cols-1 gap-4 p-5 md:grid-cols-2 xl:grid-cols-4">
          <label className="rounded-xl border border-[var(--border)] bg-white/[.025] p-4"><div className="flex items-center justify-between text-xs"><span className="font-bold">Confidence</span><span className="font-mono text-[#5cdbc8]">{confidence.toFixed(2)}</span></div><input type="range" min="0.05" max="0.7" step="0.01" value={confidence} onChange={(event) => setConfidence(Number(event.target.value))} className="mt-4 w-full accent-[#33d3bb]" /><div className="mt-2 text-[10px] text-[var(--muted-2)]">آستانه نمایش خروجی‌های نهایی</div></label>
          {[
            ["نمایش Track ID", "شناسه پایدار هر فرد", showTrackIds, setShowTrackIds],
            ["نمایش Confidence", "امتیاز تشخیص روی جعبه", showConfidence, setShowConfidence],
            ["نمایش مسیر حرکت", "رسم Trail برای Trackها", showTrails, setShowTrails],
            ["ذخیره ویدئو", "خروجی MP4 نشانه‌گذاری‌شده", saveVideo, setSaveVideo],
            ["گزارش CSV", "ردیف Trackها و مختصات", saveCsv, setSaveCsv],
            ["گزارش JSON", "خلاصه اجرای تحلیل", saveJson, setSaveJson],
          ].map(([title, description, checked, setter]) => (
            <div key={String(title)} className="flex items-center justify-between rounded-xl border border-[var(--border)] bg-white/[.025] p-4"><div><div className="text-xs font-bold">{String(title)}</div><div className="mt-2 text-[10px] text-[var(--muted-2)]">{String(description)}</div></div><Toggle checked={Boolean(checked)} onChange={setter as (value: boolean) => void} label={String(title)} /></div>
          ))}
        </div>
      </Card>

      <Card>
        <CardHeader title="بررسی آمادگی قبل از اجرا" description="دکمه شروع فقط زمانی فعال می‌شود که همه موارد آماده باشند" />
        <div className="grid grid-cols-1 gap-3 p-5 sm:grid-cols-2 xl:grid-cols-5">
          {preflight.map(({ label, detail, ready: itemReady, icon: Icon }) => (
            <div key={label} className="rounded-xl border border-[var(--border)] bg-white/[.025] p-4">
              <div className="flex items-center justify-between"><div className={`grid h-9 w-9 place-items-center rounded-xl ${itemReady ? "bg-[#33d3bb]/10 text-[#53dbc7]" : "bg-[#f6bd58]/10 text-[#f6bd58]"}`}><Icon size={17} /></div>{itemReady ? <CheckCircle2 size={18} className="text-[#49d6a5]" /> : <CircleAlert size={18} className="text-[#f6bd58]" />}</div>
              <div className="mt-4 text-xs font-black">{label}</div><div className="mt-2 text-[10px] leading-5 text-[var(--muted-2)]" dir={label === "مدل آموزش‌دیده" ? "ltr" : undefined}>{detail}</div>
            </div>
          ))}
        </div>
      </Card>

      <div className="flex flex-col-reverse justify-between gap-3 sm:flex-row sm:items-center">
        <p className="flex items-center gap-2 text-[11px] leading-6 text-[var(--muted-2)]"><Info size={14} /> در اجرای وب، فایل یک‌بار به Backend محلی کپی می‌شود. در نسخه Tauri مسیر فایل مستقیماً استفاده خواهد شد.</p>
        <Button onClick={() => void startAnalysis()} disabled={!ready} loading={starting} className="px-8 py-3"><Sparkles size={17} /> شروع تحلیل واقعی</Button>
      </div>
    </div>
  );
}
