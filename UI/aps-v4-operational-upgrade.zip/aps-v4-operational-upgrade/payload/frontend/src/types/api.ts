export type JobStatus = "queued" | "running" | "paused" | "completed" | "failed" | "cancelled";
export type InferenceMode = "fast" | "balanced" | "accuracy";

export interface HealthResponse {
  status: string;
  service: string;
  version: string;
  mock_mode: boolean;
}

export interface SystemStatus {
  platform: string;
  cpu_percent: number;
  memory_percent: number;
  gpu_name: string | null;
  gpu_usage_percent: number | null;
  vram_used_mb: number | null;
  vram_total_mb: number | null;
  model_available: boolean;
  model_loaded: boolean;
  model_name: string | null;
  model_error: string | null;
  inference_backend: string;
  storage_free_gb: number;
  ai_dependencies_ready: boolean;
  video_engine_ready: boolean;
  tracking_ready: boolean;
}

export interface ModelInfo {
  id: string;
  name: string;
  path: string;
  format: string;
  size_mb: number;
  selected: boolean;
  loaded: boolean;
}

export interface ModelStatus {
  available: boolean;
  loaded: boolean;
  selected_model: ModelInfo | null;
  models: ModelInfo[];
  backend: string;
  error: string | null;
}

export interface VideoMetadata {
  upload_id: string;
  filename: string;
  stored_path: string;
  size_mb: number;
  width: number;
  height: number;
  fps: number;
  total_frames: number;
  duration_seconds: number;
  codec: string;
}

export interface InferenceProfile {
  id: InferenceMode;
  title: string;
  subtitle: string;
  enable_tiling: boolean;
  max_tiles: number;
  refresh_interval: number | null;
  full_imgsz: number;
  tile_imgsz: number;
  recommended: boolean;
}

export interface CreateJobPayload {
  source_type: "video" | "mock";
  source_path: string;
  source_name?: string;
  profile: InferenceMode;
  confidence: number;
  show_trails: boolean;
  show_track_ids: boolean;
  show_confidence: boolean;
  save_video: boolean;
  save_csv: boolean;
  save_json: boolean;
  model_id?: string;
}

export interface Job {
  id: string;
  status: JobStatus;
  source_type: string;
  source_path: string;
  source_name: string | null;
  profile: string;
  confidence: number;
  progress: number;
  frame: number;
  total_frames: number;
  fps: number;
  inference_ms: number;
  elapsed_seconds: number;
  active_tracks: number;
  unique_tracks: number;
  mean_confidence: number;
  tiling_active: boolean;
  processed_tiles: number;
  preview_available: boolean;
  model_name: string | null;
  output_video_path: string | null;
  report_csv_path: string | null;
  report_json_path: string | null;
  error: string | null;
  created_at: string;
  updated_at: string;
}
