ابتدا Backend و Frontend را با Ctrl+C متوقف کنید.

سپس در PowerShell داخل همین پوشه:

Set-ExecutionPolicy -Scope Process Bypass
.\apply-upgrade.ps1 -ProjectPath "D:\A_Senior - Data Science\Projects\UI\aerial-person-studio-v2"

پس از موفقیت ارتقا:

cd "D:\A_Senior - Data Science\Projects\UI\aerial-person-studio-v2"
.\scripts\install-ai.ps1

سپس Backend و Frontend را دوباره اجرا کنید.
راهنمای کامل: UI_V4_OPERATIONAL_GUIDE_FA.md
