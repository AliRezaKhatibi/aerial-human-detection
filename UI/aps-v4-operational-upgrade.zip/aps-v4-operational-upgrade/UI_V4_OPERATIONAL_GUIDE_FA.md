# راهنمای نسخه عملیاتی V4 — Aerial Person Studio

این نسخه مرحله «تحلیل جدید» را از حالت Mock خارج می‌کند و مدل آموزش‌دیده داخل پوشه `models` را به جریان واقعی پردازش ویدئو متصل می‌کند.

## قابلیت‌های عملیاتی‌شده

- شناسایی خودکار فایل‌های `PT`، `ONNX` و `TensorRT Engine` داخل پوشه `models`
- انتخاب و بارگذاری مدل از رابط کاربری
- انتقال محلی ویدئو به Backend و استخراج مشخصات فنی آن
- استنتاج واقعی با Ultralytics
- ردیابی واقعی با ByteTrack داخلی Ultralytics
- سه پروفایل:
  - Fast: فقط Full-frame در اندازه 1280
  - Balanced: Full-frame به‌همراه حداکثر دو Tile تطبیقی در دوره‌های Refresh
  - Accuracy: Full-frame به‌همراه تمام Tileهای هم‌پوشان
- NMS بین خروجی Full-frame و Tileها
- پیش‌نمایش زنده فریم پردازش‌شده
- تله‌متری WebSocket شامل FPS، زمان استنتاج، Trackها و وضعیت Tiling
- خروجی MP4، CSV و JSON
- صف تک‌پردازنده GPU برای جلوگیری از اجرای هم‌زمان چند Job سنگین

## نصب روی پروژه فعلی

1. Backend و Frontend را با `Ctrl + C` متوقف کنید.
2. بسته ارتقا را Extract کنید.
3. داخل پوشه ارتقا اجرا کنید:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\apply-upgrade.ps1 `
  -ProjectPath "D:\A_Senior - Data Science\Projects\UI\aerial-person-studio-v2"
```

4. سپس داخل پروژه اصلی اجرا کنید:

```powershell
cd "D:\A_Senior - Data Science\Projects\UI\aerial-person-studio-v2"
Set-ExecutionPolicy -Scope Process Bypass
.\scripts\install-ai.ps1
```

نصب AI ممکن است چند دقیقه زمان ببرد. نسخه Ultralytics روی `8.4.114` ثابت شده است تا با نسخه‌ای که مدل شما با آن آموزش دیده هماهنگ باشد.

## محل مدل

حداقل یک فایل مدل در این پوشه باشد:

```text
models\best.pt
```

نام فایل می‌تواند متفاوت باشد. Backend همه مدل‌های پشتیبانی‌شده را اسکن می‌کند و فایل با نام `best` را در اولویت قرار می‌دهد.

## اجرای برنامه

PowerShell اول:

```powershell
.\scripts\backend-dev.ps1
```

PowerShell دوم:

```powershell
.\scripts\frontend-dev.ps1
```

سپس:

```text
http://127.0.0.1:1420
```

## اولین تحلیل

1. وارد «تحلیل جدید» شوید.
2. ویدئو را انتخاب کنید.
3. منتظر استخراج Metadata بمانید.
4. مدل را از فهرست انتخاب کنید.
5. پروفایل Balanced را انتخاب کنید.
6. دکمه «شروع تحلیل واقعی» را بزنید.
7. در صفحه پردازش، پیش‌نمایش، FPS و Trackها را مشاهده کنید.
8. پس از پایان، MP4، CSV و JSON را دریافت کنید.

## نکات مهم

- اولین بارگذاری مدل ممکن است 10 تا 60 ثانیه طول بکشد.
- روی GTX 1650، پروفایل Accuracy ممکن است بسیار کند باشد. برای تست اولیه Fast را انتخاب کنید.
- روی RTX 3070، Balanced انتخاب اصلی محصول خواهد بود.
- اجرای وب فایل را یک بار داخل `runtime/uploads` کپی می‌کند. در نسخه نهایی Tauri مسیر فایل مستقیم استفاده خواهد شد.
- برای پاک‌سازی فضای دیسک، فایل‌های قدیمی `runtime/uploads` و `runtime/outputs` را پس از اطمینان از دریافت خروجی حذف کنید.

## اعتبارسنجی

```powershell
.\scripts\verify-v4.ps1
```

این دستور تست Backend، Importها و Build فرانت‌اند را اجرا می‌کند.
